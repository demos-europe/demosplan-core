<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\SlicingTagging\Controller;

use DemosEurope\DemosplanAddon\Contracts\ApiRequest\ApiResourceServiceInterface;
use DemosEurope\DemosplanAddon\Contracts\Config\GlobalConfigInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\SegmentInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\TagInterface;
use DemosEurope\DemosplanAddon\Contracts\Handler\StatementHandlerInterface;
use DemosEurope\DemosplanAddon\Contracts\MessageBagInterface;
use DemosEurope\DemosplanAddon\Contracts\Services\InitializeServiceInterface;
use DemosEurope\DemosplanAddon\Controller\APIController;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\SlicingTagging\Logic\PiSegmentRecognitionErrorManager;
use DemosEurope\DemosplanAddon\DemosPipes\SlicingTagging\Logic\PiSegmentRecognitionRequester;
use DemosEurope\DemosplanAddon\DemosPipes\SlicingTagging\Logic\SegmentedStatementService;
use DemosEurope\DemosplanAddon\Logic\ApiRequest\TopLevel;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use EDT\JsonApi\Validation\FieldsValidator;
use EDT\Wrapping\TypeProviders\PrefilledTypeProvider;
use EDT\Wrapping\Utilities\SchemaPathProcessor;
use Exception;
use InvalidArgumentException;
use DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Logic\PiResourceFetcher;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class SegmentedStatementAPIController extends APIController
{
    private StatementHandlerInterface $statementHandler;

    public function __construct(
        FieldsValidator            $fieldsValidator,
        GlobalConfigInterface      $globalConfig,
        LoggerInterface            $apiLogger,
        LoggerInterface            $logger,
        MessageBagInterface        $messageBag,
        PrefilledTypeProvider      $resourceTypeProvider,
        SchemaPathProcessor        $schemaPathProcessor,
        StatementHandlerInterface  $statementHandler,
        TranslatorInterface        $translator
    ) {
        parent::__construct(
            $apiLogger,
            $resourceTypeProvider,
            $fieldsValidator,
            $translator,
            $logger,
            $globalConfig,
            $messageBag,
            $schemaPathProcessor
        );

        $this->statementHandler = $statementHandler;
    }

    /**
     * @Route("/api/ai/statement/{statementId}/text",
     *        methods={"GET"},
     *        name="dplan_ai_api_statement_text"
     * )
     *
     * @throws Exception
     */
    public function getStatementTextAction(
        InitializeServiceInterface   $initializeService,
        PermissionEvaluatorInterface $permissionEvaluator,
        string                       $statementId
    ): JsonResponse
    {
        $initializeService->initialize([]);
        $permissionEvaluator->requirePermission(Features::feature_ai_generated_draft_segments());

        $statement = $this->statementHandler->getStatementWithCertainty($statementId);

        return JsonResponse::create(['text' => $statement->getText()]);
    }

    /**
     * Action called by PI with a url to retrieve the Statement's text segmentation proposal.
     *
     * The url will be called to get the info and update the Statement draftsInfo with it.
     *
     * @Route(
     *     name="dplan_ai_api_statement_segments_proposal",
     *     methods={"POST"},
     *     path="/api/ai/statement/segments-proposal")
     * )
     *
     * @return Response
     */
    public function segmentsProposalAction(
        ApiResourceServiceInterface  $resourceService,
        InitializeServiceInterface   $initializeService,
        PermissionEvaluatorInterface $permissionEvaluator,
        PiResourceFetcher            $piResourceRequester,
        Request                      $request,
        SegmentedStatementService    $draftSegmentService
    ): Response
    {
        try {
            $initializeService->initialize([]);
            $permissionEvaluator->requirePermission(Features::feature_ai_generated_draft_segments());

            $piResourceInfo = $piResourceRequester->getPiResourceInfo($request);
            if ('' === $piResourceInfo) {
                throw new InvalidArgumentException('No resource info received from PI.');
            }
            $this->setupApiControllerFromRequestContent($resourceService, $piResourceInfo);
            if (!$this->requestData instanceof TopLevel) {
                throw new Exception('Incoming JSON could not be converted.');
            }
            $this->logger->info('PI-Communication-Info: Before updateStatement');
            $draftSegmentService->updateStatement(
                $this->requestData,
                $piResourceRequester->getPiSegmentsProposalResourceUrl($request)
            );
            $this->logger->info('PI-Communication-Info: After updateStatement');

            return $this->createEmptyResponse();
        } catch (Exception $e) {
            return $this->handleApiError($e);
        }
    }

    /**
     * @Route(path="/stellungnahme/{statementId}/aufteilung/error",
     *        methods={"GET"},
     *        name="dplan_api_segmented_statement_create_error"
     * )
     */
    public function errorAction(
        InitializeServiceInterface       $initializeService,
        PermissionEvaluatorInterface     $permissionEvaluator,
        PiSegmentRecognitionErrorManager $errorManager,
        string                           $statementId
    ): Response {
        try {
            $initializeService->initialize([]);
            $permissionEvaluator->requirePermission(Features::feature_ai_generated_draft_segments());

            $statement = $this->statementHandler->getStatementWithCertainty(
                $statementId
            );
            $errorManager->managePiError($statement, $statementId, '');

            return $this->createEmptyResponse();
        } catch (Exception $e) {
            return $this->handleApiError($e);
        }
    }

    /**
     * For a given Statement, returns a json with its text, Segments and Tags for each segment.
     * PI uses this endpoint to compare their proposals with the reviewed version of the
     * segments and train their system.
     *
     * @Route(path="/api/ai/statement/{statementId}/segments",
     *        methods={"GET"},
     *        name="dplan_ai_api_statement_segments"
     * )
     */
    public function listStatementSegmentsAction(
        InitializeServiceInterface   $initializeService,
        PermissionEvaluatorInterface $permissionEvaluator,
        string                       $statementId
    ): JsonResponse
    {
        try {
            $initializeService->initialize([]);
            $permissionEvaluator->requirePermission(Features::feature_ai_generated_draft_segments());

            $statement = $this->statementHandler->getStatementWithCertainty($statementId);
            $segments = $statement->getSegmentsOfStatement();

            $result['statementText'] = $statement->getText();
            $result['statementId'] = $statement->getId();
            $result['procedureId'] = $statement->getProcedure()->getId();
            $result['resourceUrl'] = $statement->getPiSegmentsProposalResourceUrl();
            $result['segments'] = $segments->map(
                function (SegmentInterface $segment) {
                    return [
                        'id' => $segment->getId(),
                        'text' => $segment->getText(),
                        'tags' => $segment->getTags()->map(
                            function (TagInterface $tag) {
                                return [
                                    'title' => $tag->getTitle(),
                                    'topicTitle' => $tag->getTopicTitle(),
                                ];
                            }
                        )->toArray(),
                    ];
                }
            )->toArray();

            return JsonResponse::create($result);
        } catch (Exception $e) {
            $this->logger->error($e->getMessage());

            return $this->handleApiError($e);
        }
    }

    /**
     * @Route(path="/api/ai/statement/{statementId}/segmentation",
     *        methods={"POST"},
     *        name="dplan_ai_api_statement_segmentation"
     * )
     */
    public function requestStatementSegmentation(
        InitializeServiceInterface    $initializeService,
        PermissionEvaluatorInterface  $permissionEvaluator,
        PiSegmentRecognitionRequester $piSegmentRecognitionRequester,
        string                        $statementId
    ) {
        try {
            $initializeService->initialize([]);
            $permissionEvaluator->requirePermission(Features::feature_ai_generated_draft_segments());

            $statement = $this->statementHandler->getStatementWithCertainty($statementId);
            $piSegmentRecognitionRequester->request($statement);

            return $this->createEmptyResponse();
        } catch (Exception $e) {
            $this->logger->error($e->getMessage());

            return $this->handleApiError($e);
        }
    }
}
