<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\SlicingTagging\Logic;

use DemosEurope\DemosplanAddon\Contracts\ApiClientInterface;
use DemosEurope\DemosplanAddon\Contracts\ApiRequest\ApiResourceServiceInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\StatementInterface;
use DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Logic\AiPipelineConfiguration;
use Lexik\Bundle\JWTAuthenticationBundle\Services\JWTTokenManagerInterface;
use DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Logic\PiCommunication;
use Psr\Log\LoggerInterface;
use Symfony\Component\Routing\RouterInterface;

class PiConfirmedSegmentsSender extends PiCommunication
{
    public const PI_PARAMETER_SEGMENT_PROPOSALS_RESOURCE_URL = 'de.demos-deutschland.PersistStatements:0:segmentsProposalUrl';

    protected ApiResourceServiceInterface $resourceService;

    protected AiPipelineConfiguration $aiPipelineConfiguration;

    public function __construct(
        ApiClientInterface              $apiClient,
        AiPipelineConfiguration         $aiPipelineConfiguration,
        ApiResourceServiceInterface     $resourceService,
        LoggerInterface                 $logger,
        JWTTokenManagerInterface        $jwtManager,
        RouterInterface                 $jwtRouter
    )
    {

        parent::__construct($apiClient, $jwtManager, $logger, $jwtRouter, $aiPipelineConfiguration);
        $this->resourceService          = $resourceService;
        $this->aiPipelineConfiguration  = $aiPipelineConfiguration;
    }

    /**
     * @param StatementInterface $statement
     */
    public function getRequestData($statement): array
    {
        $sourceUrl = $this->router->generate(
            'dplan_ai_api_statement_segments',
            [
                'statementId' => $statement->getId(),
            ],
        );
        $aiPipelineId = $this->aiPipelineConfiguration->getPiPipelineConfirmedSegmentsId();
        $pipelineDemosAuthorization = $this->aiPipelineConfiguration->getPipelineDemosAuthorization();
        $resourceUrl = $statement->getPiSegmentsProposalResourceUrl();

        return [
            'data' => [
                'attributes' => [
                    self::PI_ATTRIBUTE_PIPELINE_ID => $aiPipelineId,
                    'parameters' => [
                        self::PI_PARAMETER_SEGMENT_PROPOSALS_RESOURCE_URL => $resourceUrl,
                        self::PI_PARAMETER_SOURCE_URL => $sourceUrl,
                        self::PI_PARAMETER_SOURCE_AUTHORIZATION => $pipelineDemosAuthorization,
                    ],
                ],
            ],
        ];
    }
}

