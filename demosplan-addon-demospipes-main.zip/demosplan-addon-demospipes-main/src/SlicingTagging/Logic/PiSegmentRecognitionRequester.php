<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\SlicingTagging\Logic;

use DemosEurope\DemosplanAddon\Contracts\Entities\StatementInterface;
use DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Logic\PiCommunication;

class PiSegmentRecognitionRequester extends PiCommunication
{
    /**
     * @param StatementInterface $statement
     *
     * @return array<string, mixed>
     */
    public function getRequestData($statement): array
    {
        $sourceUrl = $this->router->generate(
            'dplan_ai_api_statement_text',
            [
                'statementId' => $statement->getId(),
            ],
        );
        $responseUrl = $this->router->generate(
            'dplan_ai_api_statement_segments_proposal',
            [],
        );
        $errorUrl = $this->router->generate(
            'dplan_api_segmented_statement_create_error',
            [
                'statementId' => $statement->getId(),
            ],
        );
        $aiPipelineId = $this->aiPinelineConnection->getPiPipelineSegmentRecognitionId();
        $pipelineDemosAuthorization = $this->aiPinelineConnection->getPipelineDemosAuthorization();

        return [
            'data' => [
                'attributes' => [
                    self::PI_ATTRIBUTE_PIPELINE_ID => $aiPipelineId,
                    'parameters'                   => [
                        // common parameters
                        self::PI_PARAMETER_SOURCE_URL           => $sourceUrl,
                        self::PI_PARAMETER_SOURCE_AUTHORIZATION => $pipelineDemosAuthorization,
                        self::PI_PARAMETER_TARGET_URL           => $responseUrl,
                        self::PI_PARAMETER_TARGET_AUTHORIZATION => $pipelineDemosAuthorization,
                        // request specific parameters
                        'de.demos-deutschland.QuerySemquery:0:procedure_id'         => $statement->getProcedureId(),
                        'de.demos-deutschland.QuerySemquery:0:statement_id'         => $statement->getId(),
                    ],
                    self::PI_ATTRIBUTE_ERROR_URL  => $errorUrl,
                    self::PI_ATTRIBUTE_ERROR_AUTH => $pipelineDemosAuthorization,
                ],
            ],
        ];
    }
}
