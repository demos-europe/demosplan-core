<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\SlicingTagging\Logic;

use DemosEurope\DemosplanAddon\Contracts\Entities\StatementInterface;
use DemosEurope\DemosplanAddon\Contracts\Handler\StatementHandlerInterface;
use DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Logic\PiErrorManagerAbstract;
use Psr\Log\LoggerInterface;

class PiSegmentRecognitionErrorManager extends PiErrorManagerAbstract
{
    /**
     * @var StatementHandlerInterface
     */
    private $statementHandler;

    public function __construct(
        PiSegmentRecognitionRequester   $piCommunication,
        LoggerInterface                 $logger,
        StatementHandlerInterface       $statementHandler,
        int                             $maxPiRetries
    )
    {
        parent::__construct(
            $piCommunication,
            $logger,
            $maxPiRetries
        );
        $this->statementHandler = $statementHandler;
    }

    /**
     * @param StatementInterface $statement
     */
    protected function getNumberOfRetries($statement): int
    {
        return $statement->getSegmentationPiRetries();
    }

    /**
     * @param StatementInterface $statement
     */
    protected function incrementNumberOfRetries($statement): void
    {
        $statement->incrementSegmentationPiRetries();
        $this->statementHandler->updateStatementObject($statement);
    }
}
