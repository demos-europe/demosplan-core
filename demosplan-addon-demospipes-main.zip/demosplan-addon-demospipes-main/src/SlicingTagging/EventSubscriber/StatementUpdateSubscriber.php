<?php

declare(strict_types=1);

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\SlicingTagging\EventSubscriber;

use DemosEurope\DemosplanAddon\Contracts\Entities\StatementInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\AfterResourceUpdateEventInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\AfterSegmentationEventInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\SlicingTagging\Logic\PiConfirmedSegmentsSender;
use DemosEurope\DemosplanAddon\DemosPipes\SlicingTagging\Logic\PiSegmentRecognitionRequester;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class StatementUpdateSubscriber implements EventSubscriberInterface
{
    /**
     * @var PiSegmentRecognitionRequester
     */
    private $piSegmentRecognitionRequester;

    private PiConfirmedSegmentsSender $piConfirmedSegmentsSender;

    private PermissionEvaluatorInterface $permissionEvaluator;

    public function __construct(
        PermissionEvaluatorInterface  $permissionEvaluator,
        PiConfirmedSegmentsSender $piConfirmedSegmentsSender,
        PiSegmentRecognitionRequester $piSegmentRecognitionRequester
    )
    {
        $this->permissionEvaluator = $permissionEvaluator;
        $this->piConfirmedSegmentsSender = $piConfirmedSegmentsSender;
        $this->piSegmentRecognitionRequester = $piSegmentRecognitionRequester;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            'demosplan\DemosPlanCoreBundle\Event\AfterResourceUpdateEvent'          => 'generateDraftSegments',
            'demosplan\DemosPlanCoreBundle\Event\Statement\AfterSegmentationEvent'  => 'sendSegments',
        ];
    }

    public function generateDraftSegments(AfterResourceUpdateEventInterface $event): void
    {
        if ($this->permissionEvaluator->isPermissionEnabled(Features::feature_ai_generated_draft_segments())
            //Todo: add proper statement type check
            && array_key_exists('fullText', $event->getResourceChange()->getRequestProperties())) {
            /** @var StatementInterface $statement */
            $statement = $event->getResourceChange()->getTargetResource();
            $this->piSegmentRecognitionRequester->request($statement);
        }
    }

    public function sendSegments(AfterSegmentationEventInterface $event): void
    {
        $statement = $event->getStatement();
        $this->piConfirmedSegmentsSender->request($statement);
    }
}
