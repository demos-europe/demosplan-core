<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosPipes\Logic\ProductIntelligence;

use DemosEurope\DemosplanAddon\Contracts\Entities\ProcedureInterface;
use DemosEurope\DemosplanAddon\Contracts\Handler\StatementHandlerInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\Exceptions\UserNotFoundException;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\SlicingTagging\PiSegmentRecognitionRequester;
use DemosEurope\DemosplanAddon\Logic\Rpc\RpcErrorGeneratorInterface;
use DemosEurope\DemosplanAddon\Logic\Rpc\RpcMethodAddonSolverInterface;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use DemosEurope\DemosplanAddon\Utilities\AddonPath;
use DemosEurope\DemosplanAddon\Utilities\Json;
use DemosEurope\DemosplanAddon\Validator\JsonSchemaValidator;
use Exception;
use InvalidArgumentException;
use JsonSchema\Exception\InvalidSchemaException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use stdClass;

class RpcStatementSegmentor implements RpcMethodAddonSolverInterface
{
    public const SEGMENT_STATEMENTS_METHOD = 'segment.statement';

    private JsonSchemaValidator $jsonSchemaValidator;

    private StatementHandlerInterface $statementHandler;

    private PiSegmentRecognitionRequester $piSegmentRecognitionRequester;

    private RpcErrorGeneratorInterface $errorGenerator;

    private PermissionEvaluatorInterface $permissionEvaluator;

    public function __construct(
        JsonSchemaValidator           $jsonSchemaValidator,
        PermissionEvaluatorInterface  $permissionEvaluator,
        PiSegmentRecognitionRequester $piSegmentRecognitionRequester,
        RpcErrorGeneratorInterface    $errorGenerator,
        StatementHandlerInterface     $statementHandler
    )
    {
        $this->errorGenerator                   = $errorGenerator;
        $this->jsonSchemaValidator              = $jsonSchemaValidator;
        $this->statementHandler                 = $statementHandler;
        $this->piSegmentRecognitionRequester    = $piSegmentRecognitionRequester;
        $this->permissionEvaluator              = $permissionEvaluator;
    }

    public function supports(string $method): bool
    {
        return self::SEGMENT_STATEMENTS_METHOD === $method;
    }

    public function execute(?ProcedureInterface $procedure, $rpcRequests): array
    {
        $rpcRequests = is_object($rpcRequests)
            ? [$rpcRequests]
            : $rpcRequests;

        $resultResponse = [];

        foreach ($rpcRequests as $rpcRequest) {
            try {
                $this->validateRpcRequest($rpcRequest);

                $statement = $this->statementHandler->getStatementWithCertainty($rpcRequest->params->statementId);
                $this->piSegmentRecognitionRequester->request($statement);

                $resultResponse[] = $this->generateMethodResult($rpcRequest);
            } catch (InvalidArgumentException|InvalidSchemaException $e) {
                $resultResponse[] = $this->errorGenerator->invalidParams($rpcRequest);
            } catch (AccessDeniedException|UserNotFoundException $e) {
                $resultResponse[] = $this->errorGenerator->accessDenied($rpcRequest);
            } catch (Exception $e) {
                $resultResponse[] = $this->errorGenerator->serverError($rpcRequest);
            }
        }

        return $resultResponse;
    }

    public function isTransactional(): bool
    {
        return false;
    }

    public function validateRpcRequest(object $rpcRequest): void
    {
        if (!$this->permissionEvaluator->isPermissionEnabled(Features::feature_ai_generated_draft_segments())) {
            throw new AccessDeniedException();
        }

        $this->jsonSchemaValidator->validate(
            Json::encode($rpcRequest),
            AddonPath::getRootPath('addons/vendor/demos-europe/demosplan-addon-demospipes/config/json-schema/rpc-segment-statement-schema.json')
        );
    }

    public function generateMethodResult(object $rpcRequest): object
    {
        $result = new stdClass();
        $result->jsonrpc = '2.0';
        $result->result = 'ok';
        $result->id = $rpcRequest->id;

        return $result;
    }
}
