<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\Logic\SlicingTagging;

use DemosEurope\DemosplanAddon\Contracts\Entities\StatementInterface;
use DemosEurope\DemosplanAddon\Contracts\Services\StatementServiceInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Exceptions\MisconfiguredException;
use DemosEurope\DemosplanAddon\DemosPipes\Exceptions\StatementNotFoundException;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\PipelineCommunication\AiPipelineConfiguration;
use DemosEurope\DemosplanAddon\Logic\ApiRequest\TopLevel;
use DemosEurope\DemosplanAddon\Utilities\Json;
use Exception;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\Exception\BadRequestException;

class SegmentedStatementService
{
    /** @var StatementServiceInterface */
    private $statementService;

    /** @var ProposalsToDraftsInfoTransformer */
    private $proposalsToDraftsInfoTransformer;

    /**
     * @var AiPipelineConfiguration
     */
    private $aiPipelineConfiguration;

    /**
     * @var LoggerInterface
     */
    private $logger;

    public function __construct(
        StatementServiceInterface $statementService,
        ProposalsToDraftsInfoTransformer $proposalsToDraftsInfoTransformer,
        AiPipelineConfiguration $aiPipelineConfiguration,
        LoggerInterface $logger)
    {
        $this->statementService = $statementService;

        $this->proposalsToDraftsInfoTransformer = $proposalsToDraftsInfoTransformer;

        /** @var AiPipelineConfiguration $aiPipelineConfiguration */
        if ('' === $aiPipelineConfiguration->getAiServiceSalt() || '' === $aiPipelineConfiguration->getAiServicePostUrl()) {
            throw MisconfiguredException::missingParameters();
        }

        $this->aiPipelineConfiguration = $aiPipelineConfiguration;
        $this->logger = $logger;
    }

    public function updateStatement(
        TopLevel $requestData,
        ?string $piSegmentsProposalResourceUrl = null
    ): void {
        $this->logger->info('PI-Communication-Info: Before getObjectToCreate');
        $segmentedStatement = $requestData->getFirst('SegmentedStatement');
        $this->logger->info(Json::encode($segmentedStatement));
        $statementId = $segmentedStatement->get('relationships.statement.data.id');
        $this->logger->info('PI-Communication-Info: Received Statement Id: '.$statementId);
        $statement = $this->statementService->getStatement($statementId);
        if (null === $statement) {
            $this->logger->error('PI-Communication-Error: Statement not found');
            throw new BadRequestException('invalid data in meta field for statement ID', 0, StatementNotFoundException::createFromId($statementId));
        }
        $this->logger->info('PI-Communication-Info: Before transform');
        $draftsInfoJson = $this->proposalsToDraftsInfoTransformer->transform($segmentedStatement);
        $this->logger->info('PI-Communication-Info: After transform');
        $this->logger->info('PI-Communication-Info: Generated Json : '.$draftsInfoJson);
        $this->logger->info('PI-Communication-Info: Before Saving Drafts');
        $statement->setDraftsListJson($draftsInfoJson);
        if (null !== $piSegmentsProposalResourceUrl) {
            $statement->setPiSegmentsProposalResourceUrl($piSegmentsProposalResourceUrl);
        }
        $this->statementService->updateStatementFromObject($statement, true);
        $this->logger->info('PI-Communication-Info: After Saving Drafts');
    }

    /**
     * @throws Exception
     */
    public function isAiRequestTokenValid(StatementInterface $statement, string $token): bool
    {
        $salt = $this->aiPipelineConfiguration->getAiServiceSalt();
        if ('' === $salt) {
            $this->logger->error('PI-Communication-Error: No Salt configured');
            throw new Exception('No salt configured to validate the request received from the AI service');
        }
        $hash = hash('sha256', $salt.$statement->getId());

        if ($hash !== $token) {
            $this->logger->error('PI-Communication-Error: Token not valid');
        }

        return $hash === $token;
    }
}
