<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\Logic\SlicingTagging;

use DemosEurope\DemosplanAddon\Contracts\Entities\StatementInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\PipelineCommunication\PiCommunication;

class PiSegmentRecognitionRequester extends PiCommunication
{
    public const PI_PARAMETER_PROCEDURE_ID = 'de.demos-deutschland.SlicingTagging:0:procedure_id';
    public const PI_PARAMETER_STATEMENT_ID = 'de.demos-deutschland.SlicingTagging:0:statement_id';

    /**
     * @param StatementInterface $statement
     *
     * @return array<string, mixed>
     */
    public function getRequestData($statement): array
    {
        $sourceUrl = $this->router->generate(
            'dplan_ai_api_statement_text',
            [
                'statementId' => $statement->getId(),
            ],
        );
        $responseUrl = $this->router->generate(
            'dplan_ai_api_statement_segments_proposal',
            [],
        );
        $errorUrl = $this->router->generate(
            'dplan_api_segmented_statement_create_error',
            [
                'statementId' => $statement->getId(),
            ],
        );
        $aiPipelineId = $this->aiPinelineConnection->getPiPipelineSegmentRecognitionId();
        $pipelineDemosAuthorization = $this->aiPinelineConnection->getPipelineDemosAuthorization();

        return [
            'data' => [
                'attributes' => [
                    self::PI_ATTRIBUTE_PIPELINE_ID => $aiPipelineId,
                    'parameters'                   => [
                        self::PI_PARAMETER_PROCEDURE_ID         => $statement->getProcedureId(),
                        self::PI_PARAMETER_STATEMENT_ID         => $statement->getId(),
                        self::PI_PARAMETER_SOURCE_URL           => $sourceUrl,
                        self::PI_PARAMETER_SOURCE_AUTHORIZATION => $pipelineDemosAuthorization,
                        self::PI_PARAMETER_TARGET_URL           => $responseUrl,
                        self::PI_PARAMETER_TARGET_AUTHORIZATION => $pipelineDemosAuthorization,
                    ],
                    self::PI_ATTRIBUTE_ERROR_URL  => $errorUrl,
                    self::PI_ATTRIBUTE_ERROR_AUTH => $pipelineDemosAuthorization,
                ],
            ],
        ];
    }
}
