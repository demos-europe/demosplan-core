<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\Logic;

use DemosEurope\DemosplanAddon\Contracts\CurrentContextProviderInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\StatementInterface;
use DemosEurope\DemosplanAddon\Contracts\FileServiceInterface;
use DemosEurope\DemosplanAddon\Contracts\FileUploadServiceInterface;
use DemosEurope\DemosplanAddon\Contracts\Handler\StatementHandlerInterface;
use DemosEurope\DemosplanAddon\Contracts\MessageBagInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\AnnotatedStatementPdf;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use Doctrine\ORM\ORMException;
use Doctrine\ORM\OptimisticLockException;
use Exception;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\RouterInterface;

/**
 * Takes care of actions related to importing a PDF into a Statement.
 */
class PdfToStatementCreator
{
    protected const PARAM_PROCEDURE_ID = 'procedureId';
    protected const PARAM_STATEMENT = 'statement';

    private FileUploadServiceInterface $fileUploadService;

    private FileServiceInterface $fileService;

    private MessageBagInterface $messageBag;

    private StatementHandlerInterface $statementHandler;

    private RouterInterface $router;

    private PermissionEvaluatorInterface $permissionEvaluator;
    private CurrentContextProviderInterface $currentContextProvider;
    private AnnotatedStatementPdfService $annotatedStatementPdfService;

    public function __construct(
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        CurrentContextProviderInterface $currentContextProvider,
        PermissionEvaluatorInterface $permissionEvaluator,
        FileServiceInterface        $fileService,
        FileUploadServiceInterface  $fileUploadService,
        MessageBagInterface         $messageBag,
        StatementHandlerInterface   $statementHandler,
        RouterInterface             $router
    ) {
        $this->permissionEvaluator = $permissionEvaluator;
        $this->messageBag = $messageBag;
        $this->statementHandler = $statementHandler;
        $this->router = $router;
        $this->fileService = $fileService;
        $this->fileUploadService = $fileUploadService;
        $this->currentContextProvider = $currentContextProvider;
        $this->annotatedStatementPdfService = $annotatedStatementPdfService;
    }

    /**
     * Starts statement creation
     */
    public function __invoke(
        Request $request,
        string $procedureId
    ): Response {
        $rParams = $request->request->all();
        $fileUpload = $this->getFileUpload($request);
        if (null !== $fileUpload) {
            $rParams['fileupload'] = $fileUpload;
        }
        $originalFileUpload = $this->getOriginalFileUpload($request);
        if (null !== $originalFileUpload) {
            $rParams['originalAttachments'] = [$originalFileUpload];
        }
        if (array_key_exists('r_tags', $rParams) && is_array($rParams['r_tags'])) {
            $rParams['r_recommendation'] = $this->statementHandler->addBoilerplatesOfTags(
                $rParams['r_tags']
            );
        }
        $statement = $this->statementHandler->newStatement(
            $rParams,
            $this->permissionEvaluator->isPermissionEnabled('feature_statement_data_input_orga')
        );
        $this->handleCreatedStatement($request, $statement);

        return $this->redirectResponse(
            $request,
            [
                self::PARAM_PROCEDURE_ID => $procedureId,
                self::PARAM_STATEMENT    => $statement,
            ]
        );
    }

    /**
     * Returns the PDF as file to attach to the Statement.
     *
     * @return mixed
     *
     * @throws Exception
     */
    protected function getFileUpload(Request $request)
    {
        $fParams = $this->fileUploadService->prepareFilesUpload($request, 'r_upload');
        if (null !== $fParams && '' !== $fParams) {
            return $fParams;
        }

        return null;
    }

    /**
     * @return mixed|null
     *
     * @throws Exception
     */
    protected function getOriginalFileUpload(Request $request)
    {
        $annotatedStatementPdf = $this
            ->annotatedStatementPdfService
            ->findOneById($request->get('r_annotated_statement_pdf_id'));

        return $this->fileService->createFileStringFromFile($annotatedStatementPdf->getFile());
    }

    /**
     * Implements tasks related to the successful import of the PDF into a Statement (changes
     * the Workflow Status of the AnnotatedStatementPDF and sets the Users confirmation
     * message).
     *
     * @throws ORMException
     * @throws OptimisticLockException
     */
    protected function handleCreatedStatement(Request $request, StatementInterface $statement): void
    {
        if (null !== $statement) {
            $annotatedStatementPdf = $this->annotatedStatementPdfService
                ->findOneById($request->get('r_annotated_statement_pdf_id'));
            $annotatedStatementPdf->setStatement($statement);
            $annotatedStatementPdf->setStatus(AnnotatedStatementPdf::CONVERTED);
            $annotatedStatementPdf->setReviewer(null);
            $this->annotatedStatementPdfService->updateObjects([$annotatedStatementPdf]);
            $this->messageBag->add(
                'confirm',
                'confirm.pdf.to.statement.imported',
                ['externId' => $statement->getExternId()]
            );
        }
    }

    /**
     * Selects The route to redirect to depending on whether the pdf import into a Statement
     * has been successful or not.
     *
     * @param array<string, mixed> $params
     */
    protected function redirectResponse(Request $request, array $params): RedirectResponse
    {
        $procedureId = $params[self::PARAM_PROCEDURE_ID];
        $statement = $params[self::PARAM_STATEMENT];
        if ($statement instanceof StatementInterface) {
            $route = 'DemosPlan_procedure_dashboard';
            $paramName = 'procedure';
            if ($this->permissionEvaluator->isPermissionEnabled('area_statement_data_input_orga')) {
                $route = 'DemosPlan_statement_orga_list';
                $paramName = 'procedureId';
            }

            return new RedirectResponse(
                $this->router->generate(
                    $route,
                    [$paramName => $params[self::PARAM_PROCEDURE_ID]]
                )
            );
        }

        return new RedirectResponse(
            $this->router->generate(
                'dplan_convert_annotated_pdf_to_statement',
                [
                    'procedureId' => $procedureId,
                    'documentId'  => $request->get('r_annotated_statement_pdf_id'),
                ]
            )
        );
    }
}
