<?php

declare(strict_types=1);

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\PdfImport\ResourceType;

use DemosEurope\DemosplanAddon\Contracts\Entities\FileInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\ProcedureInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\AddonResourceType;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\CreatableDqlResourceTypeInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\FileResourceTypeInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\ProcedureResourceTypeInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\StatementResourceTypeInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\PdfImport\AnnotatedStatementPdf;
use DemosEurope\DemosplanAddon\Logic\ResourceChange;
use EDT\JsonApi\ResourceTypes\PropertyBuilder;
use EDT\PathBuilding\End;
use EDT\Querying\Contracts\PathsBasedInterface;
use EDT\Wrapping\Contracts\Types\ExposableRelationshipTypeInterface;
use Exception;
use InvalidArgumentException;
use function array_key_exists;

/**
 *
 * @property-read End $status
 * @property-read End $text
 * @property-read End $statementText
 * @property-read AnnotatedStatementPdfPageResourceType $annotatedStatementPdfPages
 * @property-read ProcedureResourceTypeInterface $procedure
 * @property-read StatementResourceTypeInterface $statement
 * @property-read FileResourceTypeInterface $file
 * @property-read End $fileName
 * @property-read End $creationDate
 * @property-read End $created
 */
final class AnnotatedStatementPdfResourceType extends AddonResourceType implements CreatableDqlResourceTypeInterface, ExposableRelationshipTypeInterface
{
    public function getEntityClass(): string
    {
        return AnnotatedStatementPdf::class;
    }

    public static function getName(): string
    {
        return 'AnnotatedStatementPdf';
    }

    public function getAccessCondition(): PathsBasedInterface
    {
        try {
            $procedure = $this->currentContextProvider->getCurrentProcedure();
        } catch (Exception $e) {
            return $this->conditionFactory->false();
        }

        return $this->conditionFactory->propertyHasValue(
            $procedure->getId(),
            $this->procedure->id
        );
    }

    public function isAvailable(): bool
    {
        return $this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_pdf());
    }

    public function isDirectlyAccessible(): bool
    {
        return $this->isAvailable();
    }

    public function isExposedAsPrimaryResource(): bool
    {
        return $this->isAvailable();
    }

    public function isExposedAsRelationship(): bool
    {
        return $this->isAvailable();
    }

    public function isCreatable(): bool
    {
        return $this->isAvailable();
    }

    /**
     * {@inheritdoc}
     *
     * @throws Exception
     */
    public function createObject(array $properties): ResourceChange
    {
        $entity = new AnnotatedStatementPdf();
        $entity->setFile($properties[$this->file->getAsNamesInDotNotation()]);
        $entity->setAnnotatedStatementPdfPages($properties[$this->annotatedStatementPdfPages->getAsNamesInDotNotation()]);
        $entity->setStatus(AnnotatedStatementPdf::PENDING);
        /** @var ProcedureInterface $procedure */
        $procedure = $properties[$this->procedure->getAsNamesInDotNotation()];
        $currentProcedure = $this->currentContextProvider->getCurrentProcedure();
        if (null === $currentProcedure || $procedure->getId() !== $currentProcedure->getId()) {
            throw new InvalidArgumentException('Procedure IDs given in request header and request data do not match');
        }
        $entity->setProcedure($procedure);

        $this->resourceTypeService->validateObject($entity);

        $resourceChange = new ResourceChange($entity, $this, $properties);
        $resourceChange->addEntityToPersist($entity);

        return $resourceChange;
    }

    /**
     * @param array<string, mixed> $parameters
     *
     * @throws Exception
     */
    public function addCreationErrorMessage(array $parameters): void
    {
        if (!array_key_exists('file', $parameters) || !$parameters['file'] instanceof FileInterface){
            $this->messageBag->add('error', 'generic.error');
        } else {
            $file = $parameters['file'];
            $this->messageBag->add(
                'error',
                'error.document.not.saved',
                ['documentName' => $file->getFilename()]
            );
        }
    }

    protected function getProperties(): array
    {
        $properties = [
            $this->createAttribute($this->id)->readable(true)->sortable()->filterable(),
            $this->createAttribute($this->status)->readable(true)->sortable()->filterable(),
            $this->createAttribute($this->text)
                ->readable(true)->sortable()->filterable()->aliasedPath($this->statementText),
            $this->createToOneRelationship($this->file)->readable(true)->sortable()->filterable()
                ->initializable(),
            $this->createToManyRelationship($this->annotatedStatementPdfPages, true)
                ->readable(true)->sortable()->filterable()->initializable(),
            $this->createToOneRelationship($this->procedure, true)
                ->readable(true)->sortable()->filterable()->initializable(),
            $this->createToOneRelationship($this->statement, true)
                ->readable(true)->sortable()->filterable(),
        ];

        if ($this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_pdf())) {
            $properties = $this->addDenormalizedFileName($properties);
            $properties[] = $this->createAttribute($this->creationDate)->readable()
                ->aliasedPath($this->created);
        }

        return $properties;
    }

    /**
     * Denormalized file name to avoid include for better performance in large list.
     *
     * Warning: only readable (no filtering/sorting) due to sanitization in
     * {@link FileInterface::getFileName}.
     *
     * @param array<int, PropertyBuilder> $properties
     *
     * @return array<int, PropertyBuilder>
     */
    private function addDenormalizedFileName(array $properties): array
    {
        $properties[] = $this->createAttribute($this->fileName)->readable()
            ->aliasedPath($this->file->filename);

        return $properties;
    }
}
