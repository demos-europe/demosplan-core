<?php

declare(strict_types=1);

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\PdfImport\ResourceType;

use DemosEurope\DemosplanAddon\Contracts\ResourceType\AddonResourceType;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\UpdatableDqlResourceTypeInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\PdfImport\AnnotatedStatementPdfPage;
use DemosEurope\DemosplanAddon\Logic\ResourceChange;
use DemosEurope\DemosplanAddon\Utilities\Json;
use EDT\JsonApi\ResourceTypes\ResourceTypeInterface;
use EDT\PathBuilding\End;
use EDT\Querying\Contracts\PathsBasedInterface;
use EDT\Querying\Contracts\PropertyPathInterface;
use EDT\Wrapping\Contracts\Types\ExposableRelationshipTypeInterface;
use Exception;
use function collect;

/**
 * @property-read End $url
 * @property-read End $width
 * @property-read End $height
 * @property-read End $geoJson
 * @property-read End $confirmed
 * @property-read AnnotatedStatementPdfResourceType $annotatedStatementPdf
 * @property-read End $pageOrder
 * @property-read End $pageSortIndex
 */
final class AnnotatedStatementPdfPageResourceType extends AddonResourceType implements UpdatableDqlResourceTypeInterface, ExposableRelationshipTypeInterface
{
    public function getEntityClass(): string
    {
        return AnnotatedStatementPdfPage::class;
    }

    public static function getName(): string
    {
        return 'AnnotatedStatementPdfPage';
    }

    public function getAccessCondition(): PathsBasedInterface
    {
        try {
            $procedure = $this->currentContextProvider->getCurrentProcedure();
        } catch (Exception $e) {
            return $this->conditionFactory->false();
        }

        return $this->conditionFactory->propertyHasValue(
            $procedure->getId(),
            $this->annotatedStatementPdf->procedure->id
        );
    }

    public function updateObject(object $object, array $properties): ResourceChange
    {
        $resourceChange = new ResourceChange($object, $this, $properties);

        $this->resourceTypeService->updateObjectNaive($object, $properties);
        $this->resourceTypeService->validateObject($object);

        return $resourceChange;
    }

    /**
     * @return array<string,string|null>
     */
    public function getUpdatableProperties(object $updateTarget): array
    {
        return $this->toProperties(
            $this->geoJson,
            $this->confirmed
        );
    }

    public function isAvailable(): bool
    {
        return $this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_pdf());
    }

    public function isDirectlyAccessible(): bool
    {
        return $this->isAvailable();
    }

    public function isExposedAsPrimaryResource(): bool
    {
        return $this->isAvailable();
    }

    public function isExposedAsRelationship(): bool
    {
        return $this->isAvailable();
    }

    protected function getProperties(): array
    {
        return [
            $this->createAttribute($this->id)
                ->readable(true)->filterable()->sortable(),
            $this->createAttribute($this->url)
                ->readable(true, function (AnnotatedStatementPdfPage $page): string {
                    if ($this->permissionEvaluator->isPermissionEnabled(Features::feature_ai_create_annotated_statement_pdf_pages())) {
                        $url = $page->getUrl();

                        if (null !== $this->globalConfig->getHtaccessUser()) {
                            $user = $this->globalConfig->getHtaccessUser();
                            $pass = $this->globalConfig->getHtaccessPass() ?? '';
                            $url = preg_replace('!://!', '://' . $user . ':' . $pass . '@', $url);
                        }

                        return $url;
                    }

                    return $page->getUrl();
                }),
            $this->createAttribute($this->width)
                ->readable(true)->filterable()->sortable(),
            $this->createAttribute($this->height)
                ->readable(true)->filterable()->sortable(),
            $this->createAttribute($this->geoJson)
                ->readable(true, static function (AnnotatedStatementPdfPage $page): array {
                    return Json::decodeToArray($page->getGeoJson());
                }),
            $this->createAttribute($this->confirmed)
                ->filterable()->sortable(),
            $this->createAttribute($this->pageSortIndex)->sortable()->aliasedPath($this->pageOrder),
            $this->createToOneRelationship($this->annotatedStatementPdf)
                ->readable()->filterable()->sortable(),
        ];
    }

    /**
     * Convert the given array to an array with different mapping.
     *
     * The returned array will map using
     *
     * * as key: the dot notation of the property path
     * * as value: the corresponding {@link ResourceTypeInterface::getName} return value in case of a
     * relationship or `null` in case of an attribute
     *
     * The behavior for multiple given property paths with the same dot notation is undefined.
     *
     * @param PropertyPathInterface ...$propertyPaths
     *
     * @return array<string,string|null>
     */
    protected function toProperties(PropertyPathInterface ...$propertyPaths): array
    {
        return collect($propertyPaths)
            ->mapWithKeys(static function (PropertyPathInterface $propertyPath): array {
                $key = $propertyPath->getAsNamesInDotNotation();
                $value = $propertyPath instanceof ResourceTypeInterface
                    ? $propertyPath::getName()
                    : null;

                return [$key => $value];
            })->all();
    }
}
