<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\PdfImport\Logic;

use DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Logic\AiPipelineConfiguration;
use DemosEurope\DemosplanAddon\Contracts\ApiClientInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\PdfImport\AnnotatedStatementPdf;
use Lexik\Bundle\JWTAuthenticationBundle\Services\JWTTokenManagerInterface;
use DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Logic\PiCommunication;
use Psr\Log\LoggerInterface;
use Symfony\Component\Form\Exception\InvalidConfigurationException;
use Symfony\Component\Routing\RouterInterface;

class PiBoxRecognitionRequester extends PiCommunication
{
    public function __construct(
        LoggerInterface $logger,
        ApiClientInterface $apiClient,
        JWTTokenManagerInterface $jwtManager,
        RouterInterface $jwtRouter,
        AiPipelineConfiguration $aiPinelineConnection
    ) {
        parent::__construct($apiClient, $jwtManager, $logger, $jwtRouter, $aiPinelineConnection);
    }

    /**
     * @param AnnotatedStatementPdf $annotatedStatementPdf
     *
     * @return array<mixed>
     */
    public function getRequestData($annotatedStatementPdf): array
    {
        $sourceUrl = $this->router->generate(
            'core_file',
            ['hash' => $annotatedStatementPdf->getFile()->getHash()],
        );
        $responseUrl = $this->router->generate(
            'dplan_ai_api_annotation_statement_pdf_boxes_proposal',
            [
                'annotatedStatementPdfId' => $annotatedStatementPdf->getId(),
            ],
            RouterInterface::ABSOLUTE_URL
        );
        $errorUrl = $this->router->generate(
            'dplan_ai_api_annotation_statement_pdf_boxes_proposal_error',
            [
                'annotatedStatementPdfId' => $annotatedStatementPdf->getId(),
            ],
            RouterInterface::ABSOLUTE_URL
        );

        $aiPipelineId = $this->aiPinelineConnection->getAiPipelineAnnotatedStatementPdfCreatedId();
        if (null === $aiPipelineId || '' === $aiPipelineId) {
            $this->logger->error('Missing Pipeline Id for new AnnotatedStatementPdf notification.');
            throw new InvalidConfigurationException('Generic error');
        }
        $pipelineDemosAuthorization = $this->aiPinelineConnection->getPipelineDemosAuthorization();
        if (null === $pipelineDemosAuthorization || '' === $pipelineDemosAuthorization) {
            $this->logger->error('Missing Authorization for AI => DPLAN requests.');
            throw new InvalidConfigurationException('Generic error');
        }

        return [
            'data' => [
                'attributes' => [
                    PiBoxRecognitionRequester::PI_ATTRIBUTE_PIPELINE_ID => $aiPipelineId,
                    'parameters'                                        => [
                        PiBoxRecognitionRequester::PI_PARAMETER_SOURCE_AUTHORIZATION => $pipelineDemosAuthorization,
                        PiBoxRecognitionRequester::PI_PARAMETER_SOURCE_URL           => $sourceUrl,
                        PiBoxRecognitionRequester::PI_PARAMETER_TARGET_AUTHORIZATION => $pipelineDemosAuthorization,
                        PiBoxRecognitionRequester::PI_PARAMETER_TARGET_URL           => $responseUrl,
                    ],
                    PiBoxRecognitionRequester::PI_ATTRIBUTE_ERROR_URL  => $errorUrl,
                    PiBoxRecognitionRequester::PI_ATTRIBUTE_ERROR_AUTH => $pipelineDemosAuthorization,
                ],
            ],
        ];
    }
}
