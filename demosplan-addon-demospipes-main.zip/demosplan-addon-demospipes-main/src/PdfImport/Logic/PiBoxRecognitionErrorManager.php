<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\PdfImport\Logic;

use DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Logic\PiErrorManagerAbstract;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\PdfImport\AnnotatedStatementPdf;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Psr\Log\LoggerInterface;

class PiBoxRecognitionErrorManager extends PiErrorManagerAbstract
{
    private AnnotatedStatementPdfService $annotatedStatementPdfService;

    public function __construct(
        PiBoxRecognitionRequester $piCommunication,
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        LoggerInterface $logger,
        int $maxPiRetries
    ) {
        parent::__construct(
            $piCommunication,
            $logger,
            $maxPiRetries
        );
        $this->annotatedStatementPdfService = $annotatedStatementPdfService;
    }

    /**
     * @param AnnotatedStatementPdf $annotatedStatementPdf
     */
    protected function getNumberOfRetries($annotatedStatementPdf): int
    {
        return $annotatedStatementPdf->getBoxRecognitionPiRetries();
    }

    /**
     * @param AnnotatedStatementPdf $annotatedStatementPdf
     *
     * @throws ORMException
     * @throws OptimisticLockException
     */
    protected function incrementNumberOfRetries($annotatedStatementPdf): void
    {
        $annotatedStatementPdf->incrementBoxRecognitionPiRetries();
        $this->annotatedStatementPdfService->updateObjects([$annotatedStatementPdf]);
    }
}
