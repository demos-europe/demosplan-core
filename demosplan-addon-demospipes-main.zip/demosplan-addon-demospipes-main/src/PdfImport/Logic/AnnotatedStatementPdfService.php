<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\PdfImport\Logic;

use DemosEurope\DemosplanAddon\Contracts\CurrentContextProviderInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\ProcedureInterface;
use DemosEurope\DemosplanAddon\Contracts\Factory\PercentageDistributionFactoryInterface;
use DemosEurope\DemosplanAddon\Contracts\MessageBagInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Exceptions\UserNotFoundException;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\PdfImport\AnnotatedStatementPdf;
use DemosEurope\DemosplanAddon\DemosPipes\PdfImport\Repository\AnnotatedStatementPdfRepository;
use DemosEurope\DemosplanAddon\Exception\InvalidStatusTransitionException;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Exception;
use InvalidArgumentException;
use DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Logic\PiResourceFetcher;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Security\Core\User\UserInterface;

class AnnotatedStatementPdfService
{
    /**
     * @var AnnotatedStatementPdfRepository
     */
    private AnnotatedStatementPdfPageToEntityConverter $jsonToEntityConverter;
    private AnnotatedStatementPdfRepository $annotatedStatementPdfRepository;
    private CurrentContextProviderInterface $currentContextProvider;
    private LoggerInterface $logger;
    private MessageBagInterface $messageBag;
    private PercentageDistributionFactoryInterface $percentageDistributionFactoryInterface;
    private PermissionEvaluatorInterface $permissionEvaluator;

    public function __construct(
        AnnotatedStatementPdfPageToEntityConverter $jsonToEntityConverter,
        AnnotatedStatementPdfRepository $annotatedStatementPdfRepository,
        CurrentContextProviderInterface $currentContextProvider,
        LoggerInterface $logger,
        MessageBagInterface $messageBag,
        PercentageDistributionFactoryInterface $percentageDistributionFactoryInterface,
        PermissionEvaluatorInterface $permissionEvaluator
    )
    {
        $this->annotatedStatementPdfRepository = $annotatedStatementPdfRepository;
        $this->currentContextProvider = $currentContextProvider;
        $this->jsonToEntityConverter = $jsonToEntityConverter;
        $this->logger = $logger;
        $this->messageBag = $messageBag;
        $this->percentageDistributionFactoryInterface = $percentageDistributionFactoryInterface;
        $this->permissionEvaluator = $permissionEvaluator;
    }

    /**
     * @return AnnotatedStatementPdf
     */
    public function findById(string $id): ?AnnotatedStatementPdf
    {
        /** @var AnnotatedStatementPdf $annotatedStatementPdf */
        $annotatedStatementPdf = $this->annotatedStatementPdfRepository->find($id);

        return $annotatedStatementPdf;
    }

    public function getPercentageDistribution(ProcedureInterface $procedure): array
    {
        $procedureId = $procedure->getId();
        $pendingCount = $this->annotatedStatementPdfRepository->count([
            'procedure' => $procedureId,
            'status'    => AnnotatedStatementPdf::PENDING,
        ]);
        $readyToReviewCount = $this->annotatedStatementPdfRepository->count([
            'procedure' => $procedureId,
            'status'    => AnnotatedStatementPdf::READY_TO_REVIEW,
        ]);
        $boxesReviewCount = $this->annotatedStatementPdfRepository->count([
            'procedure' => $procedureId,
            'status'    => AnnotatedStatementPdf::BOX_REVIEW,
        ]);
        $reviewedCount = $this->annotatedStatementPdfRepository->count([
            'procedure' => $procedureId,
            'status'    => AnnotatedStatementPdf::REVIEWED,
        ]);
        $readyToConvertCount = $this->annotatedStatementPdfRepository->count([
            'procedure' => $procedureId,
            'status'    => AnnotatedStatementPdf::READY_TO_CONVERT,
        ]);
        $textReviewCount = $this->annotatedStatementPdfRepository->count([
            'procedure' => $procedureId,
            'status'    => AnnotatedStatementPdf::TEXT_REVIEW,
        ]);
        $convertedCount = $this->annotatedStatementPdfRepository->count([
            'procedure' => $procedureId,
            'status'    => AnnotatedStatementPdf::CONVERTED,
        ]);
        $totalCount = $this->annotatedStatementPdfRepository->count([
            'procedure' => $procedureId,
        ]);
        $data = [
            AnnotatedStatementPdf::PENDING => $pendingCount,
            'readyToReview' => $readyToReviewCount,
            AnnotatedStatementPdf::BOX_REVIEW => $boxesReviewCount,
            AnnotatedStatementPdf::REVIEWED => $reviewedCount,
            'readyToConvert' => $readyToConvertCount,
            AnnotatedStatementPdf::TEXT_REVIEW => $textReviewCount,
            AnnotatedStatementPdf::CONVERTED => $convertedCount,
        ];

        return [
            $this->percentageDistributionFactoryInterface->createPercentageDistribution(
                $totalCount,
                $data
            )
        ];
    }

    public function findByOriginalStatementId(string $originalStatementId): ?AnnotatedStatementPdf
    {
        return $this->annotatedStatementPdfRepository->findOneBy([
            'statement' => $originalStatementId,
        ]);
    }

    /**
     * @param AnnotatedStatementPdf[] $annotatedStatementPdfs
     *
     * @return AnnotatedStatementPdf[]
     *
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function updateObjects(array $annotatedStatementPdfs): array
    {
        return
            $this
                ->annotatedStatementPdfRepository
                ->updateObjects($annotatedStatementPdfs);
    }

    /**
     * Sets all AnnotatedStatementPdf in {@link AnnotatedStatementPdf::BOX_REVIEW} status back
     * to {@link AnnotatedStatementPdf::READY_TO_REVIEW} status.
     *
     * @return mixed
     *
     * @throws Exception
     */
    public function rollbackBoxReviewStatus()
    {
        return $this->annotatedStatementPdfRepository->rollbackBoxReviewStatus();
    }

    /**
     * Sets all AnnotatedStatementPdf in {@link AnnotatedStatementPdf::TEXT_REVIEW} status back
     * to {@link AnnotatedStatementPdf::READY_TO_CONVERT} status.
     *
     * @return mixed
     *
     * @throws Exception
     */
    public function rollbackTextReviewStatus()
    {
        return $this->annotatedStatementPdfRepository->rollbackTextReviewStatus();
    }

    /**
     * @return AnnotatedStatementPdf[]
     */
    public function findAll(): array
    {
        return $this->annotatedStatementPdfRepository->findAll();
    }

    /**
     * @return array<int, AnnotatedStatementPdf>
     */
    public function findByStatus(string $status): array
    {
        return $this->annotatedStatementPdfRepository->findByStatus($status);
    }

    public function updateAnnotatedStatementPdf(
        Request           $request,
        PiResourceFetcher $piResourceRequester,
        string            $annotatedStatementPdfId,
        string            $status,
        bool              $updatePages
    ): void
    {
        $piResourceInfo = $piResourceRequester->getPiResourceInfo($request);
        if ('' === $piResourceInfo) {
            throw new InvalidArgumentException('No resource info received from PI.');
        }
        $annotatedStatementPdf = $this
            ->annotatedStatementPdfRepository
            ->findOneById($annotatedStatementPdfId);

        $annotatedStatementPdf = $this
            ->jsonToEntityConverter
            ->convert($annotatedStatementPdf, $piResourceInfo, $updatePages);

        $annotatedStatementPdf->setStatus($status);
        $this->annotatedStatementPdfRepository->updateObjects([$annotatedStatementPdf]);
    }

    /**
     * @throws InvalidArgumentException
     */
    public function findOneById(string $id): AnnotatedStatementPdf
    {
        $annotatedStatementPdf = $this->findById($id);
        if (null === $annotatedStatementPdf) {
            $this->logger->error("No AnnotatedStatementPdf found with id: $id");
            throw new InvalidArgumentException("No AnnotatedStatementPdf found with id: $id");
        }

        return $annotatedStatementPdf;
    }

    /**
     * @throws InvalidStatusTransitionException
     * @throws UserNotFoundException
     * @throws Exception
     */
    public function pauseBoxReviewStatus(AnnotatedStatementPdf $annotatedStatementPdf): void
    {
        if (AnnotatedStatementPdf::BOX_REVIEW !== $annotatedStatementPdf->getStatus()) {
            throw InvalidStatusTransitionException::create($annotatedStatementPdf->getStatus(), AnnotatedStatementPdf::READY_TO_REVIEW);
        }
        $this->updateReviewStatus(
            $annotatedStatementPdf,
            AnnotatedStatementPdf::READY_TO_REVIEW
        );
    }

    /**
     * @throws InvalidStatusTransitionException
     * @throws UserNotFoundException
     * @throws Exception
     */
    public function pauseTextReviewStatus(AnnotatedStatementPdf $annotatedStatementPdf): void
    {
        if (AnnotatedStatementPdf::TEXT_REVIEW !== $annotatedStatementPdf->getStatus()) {
            throw InvalidStatusTransitionException::create($annotatedStatementPdf->getStatus(), AnnotatedStatementPdf::READY_TO_CONVERT);
        }
        $this->updateReviewStatus(
            $annotatedStatementPdf,
            AnnotatedStatementPdf::READY_TO_CONVERT
        );
    }

    /**
     * @throws InvalidStatusTransitionException
     * @throws UserNotFoundException
     * @throws Exception
     */
    public function setBoxReviewStatus(AnnotatedStatementPdf $annotatedStatementPdf): void
    {
        if (AnnotatedStatementPdf::READY_TO_REVIEW !== $annotatedStatementPdf->getStatus()) {
            throw InvalidStatusTransitionException::create($annotatedStatementPdf->getStatus(), AnnotatedStatementPdf::BOX_REVIEW);
        }
        $this->updateReviewStatus(
            $annotatedStatementPdf,
            AnnotatedStatementPdf::BOX_REVIEW,
            $this->currentContextProvider->getCurrentUser()
        );
    }

    /**
     * @throws InvalidStatusTransitionException
     * @throws UserNotFoundException
     * @throws Exception
     */
    public function setTextReviewStatus(AnnotatedStatementPdf $annotatedStatementPdf): void
    {
        if (AnnotatedStatementPdf::READY_TO_CONVERT !== $annotatedStatementPdf->getStatus()) {
            throw InvalidStatusTransitionException::create($annotatedStatementPdf->getStatus(), AnnotatedStatementPdf::TEXT_REVIEW);
        }
        $this->updateReviewStatus(
            $annotatedStatementPdf,
            AnnotatedStatementPdf::TEXT_REVIEW,
            $this->currentContextProvider->getCurrentUser()
        );
    }

    /**
     * @throws UserNotFoundException
     */
    public function validateBoxReview(AnnotatedStatementPdf $annotatedStatementPdf): bool
    {
        switch ($annotatedStatementPdf->getStatus()) {
            case AnnotatedStatementPdf::PENDING:
                $this->messageBag->add(
                    'error',
                    'error.annotated.statement.not.ready.to.review'
                );

                return false;
            case AnnotatedStatementPdf::BOX_REVIEW:
                if (null !== $annotatedStatementPdf->getReviewer()
                    && $this->currentContextProvider->getCurrentUser()->getId() === $annotatedStatementPdf->getReviewer()->getId()) {
                    return true;
                }
                $this->messageBag->add(
                    'error',
                    'error.annotated.statement.boxes.already.being.reviewed',
                    ['%user%' => $annotatedStatementPdf->getReviewer()->getName()]
                );

                return false;
            case AnnotatedStatementPdf::READY_TO_REVIEW:
                if ($annotatedStatementPdf->allPagesReviewed()) {
                    $this->logger->error(
                        'Document with id ' . $annotatedStatementPdf->getId() .
                        ' is set as ready_to_review but has no pages. Please check the' .
                        ' inconsistency in the DB.');
                    $this->messageBag->add(
                        'error', 'error.annotated.statement.already.reviewed'
                    );

                    return false;
                }

                return true;
            default:
                $this->messageBag->add(
                    'error',
                    'error.annotated.statement.already.reviewed'
                );

                return false;
        }
    }

    /**
     * @throws UserNotFoundException
     */
    private function updateReviewStatus(
        AnnotatedStatementPdf $annotatedStatementPdf,
        string                $status,
        ?UserInterface        $user = null
    ): void
    {
        $userInSession = $this->currentContextProvider->getCurrentUser();
        if (!$this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_pdf())) {
            $this->logger->error('The user ' . $userInSession->getId() . ' has no permission to edit AnnotatedStatementPdfs');
            throw new AccessDeniedException();
        }

        $annotatedStatementPdf->setStatus($status);
        $annotatedStatementPdf->setReviewer($user);
        $this->updateObjects([$annotatedStatementPdf]);
    }
}
