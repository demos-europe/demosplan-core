<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosPipes\PdfImport\EventSubscriber;

use DemosEurope\DemosplanAddon\Contracts\Events\GetPropertiesEventInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\StatementResourceTypeInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class ProcedureResourceTypeSubscriber implements EventSubscriberInterface
{
    use ResourceTypeSubscriberTrait;

    private PermissionEvaluatorInterface $permissionEvaluator;

    public function __construct(PermissionEvaluatorInterface $permissionEvaluator)
    {
        $this->permissionEvaluator = $permissionEvaluator;
    }

    public static function getSubscribedEvents()
    {
        return [
            GetPropertiesEventInterface::class => 'exposeProperties',
        ];
    }

    public function exposeProperties(GetPropertiesEventInterface $event)
    {
        $resourceType = $event->getType();
        if (!$resourceType instanceof StatementResourceTypeInterface) {
            return;
        }

        if (!$this->permissionEvaluator->isPermissionEnabled(
            Features::feature_ai_create_annotated_statement_pdf_pages()
        )) {
            return;
        }

        $properties = $event->getProperties();

        // both properties are expected to always being present

        $this->getPropertyBuilder($properties, 'owningOrganisation')
            ->readable()
            ->sortable()
            ->filterable();

        $this->getPropertyBuilder($properties, 'invitedOrganisations')
            ->readable()
            ->sortable()
            ->filterable();
    }
}
