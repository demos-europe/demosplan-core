<?php

declare(strict_types=1);

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\PdfImport\EventSubscriber;

use DemosEurope\DemosplanAddon\Contracts\Events\DailyMaintenanceEventInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\PdfImport\Logic\AnnotatedStatementPdfService;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class DailyMaintenanceSubscriber implements EventSubscriberInterface
{
    private PermissionEvaluatorInterface $permissionEvaluator;
    private AnnotatedStatementPdfService $annotatedStatementPdfService;
    private LoggerInterface $logger;

    public function __construct(
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        LoggerInterface              $logger,
        PermissionEvaluatorInterface $permissionEvaluator
    )
    {
        $this->logger = $logger;
        $this->permissionEvaluator = $permissionEvaluator;
        $this->annotatedStatementPdfService = $annotatedStatementPdfService;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            DailyMaintenanceEventInterface::class => 'handleDailyMaintenance',
        ];
    }

    public function handleDailyMaintenance(DailyMaintenanceEventInterface $dailyMaintenanceEvent): void
    {
        // Rollback AnnotatedStatementPdf in box- or text-review status
        if ($this->permissionEvaluator->isPermissionEnabled(
            Features::feature_annotated_statement_pdf_rollback_review_status(),
        )) {
            $this->logger->info('Maintenance: Bringing all AnnotatedStatementPdf which are in boxes_review status back to ready_to_review');
            $boxReviewCount = $this->annotatedStatementPdfService->rollbackBoxReviewStatus();
            $this->logger->info("Maintenance: $boxReviewCount AnnotatedStatementPdfs in boxes_review status brought back to ready_to_review");

            $this->logger->info('Maintenance: Bringing all AnnotatedStatementPdf which are in text_review status back to ready_to_convert');
            $textReviewCount = $this->annotatedStatementPdfService->rollbackTextReviewStatus();
            $this->logger->info("Maintenance: $textReviewCount AnnotatedStatementPdfs in text_review status brought back to ready_to_convert");
        }
        $this->logger->info('Daily Maintenance Tasks completed');
    }

}
