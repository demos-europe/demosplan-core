<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\PdfImport\Controller;

use DemosEurope\DemosplanAddon\Contracts\Services\InitializeServiceInterface;
use DemosEurope\DemosplanAddon\Controller\APIController;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\PdfImport\Logic\PdfToStatementCreator;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use Exception;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Takes care of actions related to importing a PDF into a Statement.
 */
class DemosPlanPdfToStatementController extends APIController
{
    /**
     * Imports a PDF into a Statement.
     *
     * @Route(
     *     name="dplan_pdf_import_to_statement",
     *     methods={"POST"},
     *     path="/verfahren/{procedureId}/pdf-to-stellungnahme",
     *     options={"expose": true}
     * )
     *
     * @throws Exception
     */
    public function importPdfToStatementAction(
        InitializeServiceInterface   $initializeService,
        PdfToStatementCreator        $statementCreator,
        PermissionEvaluatorInterface $permissionEvaluator,
        Request                      $request,
        string                       $procedureId
    ): Response {
        $initializeService->initialize([]);
        $permissionEvaluator->requirePermission(Features::feature_import_statement_pdf());

        return $statementCreator($request, $procedureId);
    }
}
