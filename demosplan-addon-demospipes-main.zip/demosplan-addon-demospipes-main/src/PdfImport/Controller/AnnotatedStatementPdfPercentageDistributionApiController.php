<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\PdfImport\Controller;

use DemosEurope\DemosplanAddon\Contracts\ApiRequest\ApiResourceServiceInterface;
use DemosEurope\DemosplanAddon\Contracts\CurrentContextProviderInterface;
use DemosEurope\DemosplanAddon\Contracts\PercentageDistributionTransformerInterface;
use DemosEurope\DemosplanAddon\Contracts\Services\InitializeServiceInterface;
use DemosEurope\DemosplanAddon\Controller\APIController;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\PdfImport\Logic\AnnotatedStatementPdfService;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use DemosEurope\DemosplanAddon\Response\APIResponse;
use Exception;
use Symfony\Component\Routing\Annotation\Route;


class AnnotatedStatementPdfPercentageDistributionApiController extends APIController
{
    /**
     * @Route(path="/api/1.0/AnnotatedStatementPdfPercentageDistribution/",
     *        methods={"GET"},
     *        name="dplan_api_list_percentage_distribution",
     *        options={"expose": true})
     *
     * @throws Exception
     */
    public function getStatusPercentageDistribution(
        AnnotatedStatementPdfService                $annotatedStatementPdfService,
        ApiResourceServiceInterface                 $apiResourceService,
        CurrentContextProviderInterface             $currentContextProvider,
        PercentageDistributionTransformerInterface  $percentageDistributionTransformer,
        PermissionEvaluatorInterface                $permissionEvaluator,
        InitializeServiceInterface                  $initializeService
    ): APIResponse {
        $initializeService->initialize([]);
        $permissionEvaluator->requirePermission(Features::feature_import_statement_pdf());

        $procedure = $currentContextProvider->getCurrentProcedure();
        $status = $annotatedStatementPdfService->getPercentageDistribution($procedure);
        $collection = $apiResourceService->makeAddonCollection(
            $status,
            $percentageDistributionTransformer,
            'AnnotatedStatementPdfPercentageDistribution'
        );

        return $this->renderResource($collection);
    }
}
