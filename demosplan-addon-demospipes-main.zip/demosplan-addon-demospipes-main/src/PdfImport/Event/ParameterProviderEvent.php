<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosPipes\PdfImport\Event;

use DemosEurope\DemosplanAddon\Contracts\Events\ParameterProviderEventInterface;
use Symfony\Contracts\EventDispatcher\Event;

class ParameterProviderEvent extends Event implements ParameterProviderEventInterface
{
    private string $view;

    private array $parameters;

    public function __construct(string $view, array $parameters = [])
    {
        $this->view         = $view;
        $this->parameters   = $parameters;
    }

    public function getView(): string
    {
        return $this->view;
    }

    public function getParameters(): array
    {
        return $this->parameters;
    }

    public function setParameters(array $parameters): void
    {
        $this->parameters = $parameters;
    }
}
