<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\Validator;

use DemosEurope\DemosplanAddon\DemosPipes\Constraint\NonEmptyAnnotatedStatementPdfConstraint;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\AnnotatedStatementPdf;
use InvalidArgumentException;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

class NonEmptyAnnotatedStatementPdfConstraintValidator extends ConstraintValidator
{
    public function validate($value, Constraint $constraint): void
    {
        if (!$value instanceof AnnotatedStatementPdf) {
            $class = AnnotatedStatementPdf::class;
            throw new InvalidArgumentException("Given value must be of type {$class}");
        }

        if (!$constraint instanceof NonEmptyAnnotatedStatementPdfConstraint) {
            $class = NonEmptyAnnotatedStatementPdfConstraint::class;
            throw new InvalidArgumentException("Given constraint must be of type {$class}");
        }

        if (null !== $value->getStatement() && $value->getAnnotatedStatementPdfPages()->isEmpty()) {
            $this->context->buildViolation($constraint->message)
                ->setParameter('{annotatedStatementPdf}', $value->getId())
                ->addViolation();
        }
    }
}
