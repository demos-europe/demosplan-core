<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\EventSubscriber;

use DateTime;
use DemosEurope\DemosplanAddon\Contracts\CurrentContextProviderInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\AfterResourceCreationEventInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\AfterResourceUpdateEventInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\AnnotatedStatementPdf;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\AnnotatedStatementPdfPage;
use DemosEurope\DemosplanAddon\DemosPipes\Exceptions\UserNotFoundException;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\AnnotatedStatementPdfService;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\PiBoxRecognitionRequester;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\PiTextRecognitionRequester;
use DemosEurope\DemosplanAddon\DemosPipes\ResourceType\AnnotatedStatementPdfPageResourceType;
use DemosEurope\DemosplanAddon\DemosPipes\ResourceType\AnnotatedStatementPdfResourceType;
use DemosEurope\DemosplanAddon\Exception\ConcurrentEditionException;
use DemosEurope\DemosplanAddon\Exception\InvalidStatusTransitionException;
use Doctrine\ORM\ORMException;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class AnnotatedStatementPdfEventSubscriber implements EventSubscriberInterface
{
    /**
     * @var AnnotatedStatementPdfService
     */
    private $annotatedStatementPdfService;

    /**
     * @var CurrentContextProviderInterface
     */
    private $currentContextProvider;

    /**
     * @var PiBoxRecognitionRequester
     */
    private $piBoxRecognitionRequester;

    /**
     * @var PiTextRecognitionRequester
     */
    private $piTextRecognitionRequester;

    /**
     * @var \Doctrine\Persistence\ManagerRegistry
     */
    private $managerRegistry;

    public function __construct(
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        CurrentContextProviderInterface $currentContextProvider,
        ManagerRegistry              $managerRegistry,
        PiBoxRecognitionRequester    $piBoxRecognitionRequester,
        PiTextRecognitionRequester   $piTextRecognitionRequester
    )
    {
        $this->annotatedStatementPdfService = $annotatedStatementPdfService;
        $this->currentContextProvider = $currentContextProvider;
        $this->managerRegistry = $managerRegistry;
        $this->piBoxRecognitionRequester = $piBoxRecognitionRequester;
        $this->piTextRecognitionRequester = $piTextRecognitionRequester;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            AfterResourceCreationEventInterface::class => 'piBoxRecognitionRequest',
            AfterResourceUpdateEventInterface::class => 'checkAnnotatedStatementPdfReviewed',
        ];
    }

    /**
     * Requests PI for box recognition in the AnnotatedStatementPdf.
     */
    public function piBoxRecognitionRequest(AfterResourceCreationEventInterface $event): void
    {
        $targetResourceType = $event->getResourceChange()->getTargetResourceType();
        if (!$targetResourceType instanceof AnnotatedStatementPdfResourceType) {
            return;
        }
        /** @var AnnotatedStatementPdf $annotatedStatementPdf */
        $annotatedStatementPdf = $event->getResourceChange()->getTargetResource();
        $this->piBoxRecognitionRequester->request($annotatedStatementPdf);
    }

    /**
     * Checks if with this Page's update the whole Document is reviewed.
     * If so requests PI for text recognition based on the reviewed boxes.
     *
     * @throws ORMException
     * @throws OptimisticLockException
     * @throws InvalidStatusTransitionException
     * @throws UserNotFoundException
     * @throws ConcurrentEditionException
     */
    public function checkAnnotatedStatementPdfReviewed(AfterResourceUpdateEventInterface $event): void
    {
        $targetResourceType = $event->getResourceChange()->getTargetResourceType();
        if (!$targetResourceType instanceof AnnotatedStatementPdfPageResourceType) {
            return;
        }

        /** @var AnnotatedStatementPdfPage $annotatedStatementPdfPage */
        $annotatedStatementPdfPage = $event->getResourceChange()->getTargetResource();
        $annotatedStatementPdf = $annotatedStatementPdfPage->getAnnotatedStatementPdf();
        if (AnnotatedStatementPdf::BOX_REVIEW !== $annotatedStatementPdf->getStatus()
            || null == $annotatedStatementPdf->getReviewer()
        ) {
            $this->annotatedStatementPdfService->setBoxReviewStatus($annotatedStatementPdf);
        }
        if ($annotatedStatementPdf->getReviewer()->getId() !== $this->currentContextProvider->getCurrentUser()->getId()) {
            throw new ConcurrentEditionException();
        }
        if ($annotatedStatementPdf->allPagesReviewed()) {
            $annotatedStatementPdf->setReviewedDate(new DateTime());
            $annotatedStatementPdf->setStatus(AnnotatedStatementPdf::REVIEWED);
            $annotatedStatementPdf->setReviewer(null);
            $this->managerRegistry->getManager()->flush();

            $this->piTextRecognitionRequester->request($annotatedStatementPdf);
        }
    }
}
