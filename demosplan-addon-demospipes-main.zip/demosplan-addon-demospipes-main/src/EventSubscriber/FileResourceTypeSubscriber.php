<?php

declare(strict_types=1);

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\EventSubscriber;

use Carbon\Carbon;
use DemosEurope\DemosplanAddon\Contracts\Entities\FileInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\GetPropertiesEventInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\IsFileAvailableEventInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\IsFileDirectlyAccessibleEventInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\FileResourceTypeInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use EDT\JsonApi\ResourceTypes\PropertyBuilder;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class FileResourceTypeSubscriber implements EventSubscriberInterface
{
    use ResourceTypeSubscriberTrait;

    private PermissionEvaluatorInterface $permissionEvaluator;

    public function __construct(PermissionEvaluatorInterface $permissionEvaluator)
    {
        $this->permissionEvaluator = $permissionEvaluator;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            IsFileAvailableEventInterface::class            => 'isFileAvailable',
            IsFileDirectlyAccessibleEventInterface::class   => 'isFileDirectlyAccessible',
            GetPropertiesEventInterface::class              => 'getFileProperties',
        ];
    }

    public function isFileAvailable(IsFileAvailableEventInterface $event): void
    {
        if ($this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_pdf())) {
            $event->setIsFileAvailable(true);
        }
    }

    public function isFileDirectlyAccessible(IsFileDirectlyAccessibleEventInterface $event): void
    {
        if ($this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_pdf())) {
            $event->setIsDirectlyAccessible(true);
        }
    }

    public function getFileProperties(GetPropertiesEventInterface $event): void
    {
        $resourceType = $event->getType();
        if (!$resourceType instanceof FileResourceTypeInterface) {
            return;
        }

        if (!$this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_pdf())) {
            return;
        }

        $properties = $event->getProperties();
        $idPropertyBuilder = $this->getPropertyBuilder($properties, $resourceType->id->getAsNamesInDotNotation());
        if (null === $idPropertyBuilder) {
            $idPropertyBuilder = new PropertyBuilder($resourceType->id, $resourceType->getEntityClass());
            $properties[] = $idPropertyBuilder;
        }
        $idPropertyBuilder->filterable()->sortable();

        $hashPropertyBuilder = $this->getPropertyBuilder($properties, $resourceType->hash->getAsNamesInDotNotation());
        if (null === $hashPropertyBuilder) {
            $hashPropertyBuilder = new PropertyBuilder($resourceType->hash, $resourceType->getEntityClass());
            $properties[] = $hashPropertyBuilder;
        }
        $hashPropertyBuilder->readable(true)->filterable()->sortable();

        $filenamePropertyBuilder = $this->getPropertyBuilder($properties, $resourceType->filename->getAsNamesInDotNotation());
        if (null === $filenamePropertyBuilder) {
            $filenamePropertyBuilder = new PropertyBuilder($resourceType->filename, $resourceType->getEntityClass());
            $properties[] = $filenamePropertyBuilder;
        }
        $filenamePropertyBuilder->readable(true, [self::class, 'getFileName']);

        $createdPropertyBuilder = $this->getPropertyBuilder($properties, $resourceType->created->getAsNamesInDotNotation());
        if (null === $createdPropertyBuilder) {
            $createdPropertyBuilder = new PropertyBuilder($resourceType->created, $resourceType->getEntityClass());
            $properties[] = $createdPropertyBuilder;
        }
        $createdPropertyBuilder->readable(true, [$this, 'getCreated']);

        $event->setProperties($properties);
    }

    public static function getFileName(FileInterface $file): string
    {
        return $file->getFilename();
    }

    public function getCreated(FileInterface $file): string
    {
        return Carbon::instance($file->getCreated())->toIso8601String();
    }
}
