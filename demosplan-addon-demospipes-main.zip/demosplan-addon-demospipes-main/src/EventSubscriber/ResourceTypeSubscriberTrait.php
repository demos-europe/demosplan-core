<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosPipes\EventSubscriber;

use EDT\JsonApi\ResourceTypes\PropertyBuilder;

trait ResourceTypeSubscriberTrait
{
    /**
     * @param list<PropertyBuilder> $propertyBuilders
     * @param non-empty-string      $propertyName
     *
     * @return PropertyBuilder
     */
    protected function getPropertyBuilder(array $propertyBuilders, string $propertyName): ?PropertyBuilder
    {
        foreach ($propertyBuilders as $propertyBuilder) {
            if ($propertyBuilder->getName() === $propertyName) {
                return $propertyBuilder;
            }
        }

        return null;
    }
}
