<?php

namespace DemosEurope\DemosplanAddon\DemosPipes\Exceptions;

use Exception;

class UserNotFoundException extends Exception
{
    /**
     * @var string|null
     */
    private $userLogin;

    public static function createFromId(string $userId): self
    {
        return new self("Could not find User with ID {$userId}");
    }

    public static function createFromLogin(string $login): self
    {
        $self = new self("Could not find User with Login {$login}");
        $self->userLogin = $login;

        return $self;
    }

    public function getUserLogin(): ?string
    {
        return $this->userLogin;
    }

    /**
     * @return static
     */
    public static function createResourceNotFoundException(string $typeName, string $id): self
    {
        return new self("No resource available for the type {$typeName} and ID {$id}");
    }

}
