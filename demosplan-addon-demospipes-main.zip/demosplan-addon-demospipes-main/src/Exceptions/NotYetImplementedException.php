<?php

namespace DemosEurope\DemosplanAddon\DemosPipes\Exceptions;

use LogicException;

class NotYetImplementedException extends LogicException
{
    public static function wip()
    {
        return new self('This method is a work in progress');
    }
}
