<?php

namespace DemosEurope\DemosplanAddon\DemosPipes\Exceptions;

use Exception;

class StatementNotFoundException extends Exception
{
    public static function createFromId(string $id): StatementNotFoundException
    {
        return new self("Statement with ID {$id} was not found.");
    }

    public static function createFromNonOriginalId(string $id): StatementNotFoundException
    {
        return new self("The original statement with the ID {$id} was not found.");
    }
}

