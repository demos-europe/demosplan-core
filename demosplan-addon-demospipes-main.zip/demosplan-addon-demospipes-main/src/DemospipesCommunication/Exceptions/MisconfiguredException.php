<?php

namespace DemosEurope\DemosplanAddon\DemosPipes\DemospipesCommunication\Exceptions;

class MisconfiguredException extends \RuntimeException
{
    public static function missingParameters(): self
    {
        return new self('This plugin only works with ai_service_salt and ai_service_post_url configured.');
    }
}

