<?php

declare(strict_types=1);


/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\Command;

use DemosEurope\DemosplanAddon\DemosPipes\Logic\AnnotatedStatementPdfService;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\PiBoxRecognitionRequester;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Routing\RouterInterface;

class RestartPdfImportCommand extends Command
{
    protected static $defaultName = 'dplan:import:restart-job';
    protected static $defaultDescription = 'Restart a pipeline job for an AnnotatedStatementPdf id';

    /**
     * @var PiBoxRecognitionRequester
     */
    private $boxRecognitionRequester;

    /**
     * @var RouterInterface
     */
    private $router;
    private AnnotatedStatementPdfService $annotatedStatementPdfService;

    public function __construct(
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        PiBoxRecognitionRequester    $boxRecognitionRequester,
        RouterInterface              $router,
        string                       $name = null
    )
    {
        parent::__construct($name);
        $this->boxRecognitionRequester = $boxRecognitionRequester;
        $this->router = $router;
        $this->annotatedStatementPdfService = $annotatedStatementPdfService;
    }

    protected function configure(): void
    {
        $this->addArgument('id', InputArgument::REQUIRED, 'AnnotatedStatementPdf id');
        $this->addOption('host', '', InputOption::VALUE_REQUIRED);
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $this->resetHost($input->getOption('host'));

        $annotatedStatementPdfId = $input->getArgument('id');

        try {
            $annotatedStatementPdf = $this->annotatedStatementPdfService->findOneById(
                $annotatedStatementPdfId
            );
        } catch (\InvalidArgumentException $e) {
            $output->writeln(
                'Matching entity not found for id ' . $annotatedStatementPdfId,
                OutputInterface::VERBOSITY_VERBOSE
            );

            return 1;
        }

        $this->boxRecognitionRequester->request($annotatedStatementPdf);

        return 0;
    }

    protected function resetHost(?string $host): void
    {
        if (is_string($host) && '' !== $host) {
            $parsedHost = parse_url($host);

            $context = $this->router->getContext();

            $context->setHost($parsedHost['host']);
            $context->setScheme($parsedHost['scheme']);
        }
    }
}
