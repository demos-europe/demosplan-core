<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions;

use DemosEurope\DemosplanAddon\Permission\AbstractPermissionMeta;
use DemosEurope\DemosplanAddon\DemosPipes\DemosPipesAddon;

class Features extends AbstractPermissionMeta
{
    /**
     * Access to bring AnnotatedStatementPDfs from box- and text-review back to their previous statuses.
     *
     * Allows running the task to bring all AnnotatedStatements which are in `BOX_REVIEW` status back to
     * `READY_TO_REVIEW` and those in TEXT_REVIEW back to `READY_TO_CONVERT`.
     */
    // #[Exposed(false)]
    public static function feature_annotated_statement_pdf_rollback_review_status(): self
    {
        return new self('feature_annotated_statement_pdf_rollback_review_status');
    }

    /**
     * Allow artificial intelligence generated draft segments.
     *
     * Without AI support users can already split a statement text into segments (if the
     * corresponding permissions are enabled. With this permission the statement text is
     * automatically send to a different server to be processed for an unknown time. When
     * the processing is finished an ID to get the generated draft segments is send
     * to the application. The draft segments are then fetched from that server and
     * stored and provided to the user as initial suggested state when the manual
     * segmentation of the statement begins.
     */
    // #[Exposed(true)]
    // #[Parent('area_statement_segmentation')]
    public static function feature_ai_generated_draft_segments(): self
    {
        return new self('feature_ai_generated_draft_segments');
    }

    /**
     * Allows creating pages for an annotated statement pdf (after info provided by PI).
     *
     * At some point in the workflow to create a Statement from a PDF, we expect PI to send us info
     * related to the sections in every page from the PDF document. This permission grants the creation
     * of such info as AnnotatedStatementPdfPage entities.
     */
    // #[Exposed(false)]
    public static function feature_ai_create_annotated_statement_pdf_pages(): self
    {
        return new self('feature_ai_create_annotated_statement_pdf_pages');
    }

    /**
     * Upload and annotate PDF files to create statements from it.
     *
     * When enabled users are able to upload PDF files which are then automatically processed to annotate
     * relevant information in the pages. After the processing is done the user can review and adjust the
     * annotations. When the review is done a statement can be created from the data annotated in the PDF
     * file with the PDF file attached to the statement.
     */
    // #[Exposed(true)]
    public static function feature_import_statement_pdf()
    {
        return new self('feature_import_statement_pdf');
    }

    public function getAddonIdentifier(): ?string
    {
        return DemosPipesAddon::ADDON_NAME;
    }
}
