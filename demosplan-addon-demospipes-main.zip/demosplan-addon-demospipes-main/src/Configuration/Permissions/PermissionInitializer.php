<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions;

use DemosEurope\DemosplanAddon\Contracts\Config\GlobalConfigInterface;
use DemosEurope\DemosplanAddon\Permission\PermissionConditionBuilder;
use DemosEurope\DemosplanAddon\Permission\PermissionInitializerInterface;
use DemosEurope\DemosplanAddon\Permission\ResolvablePermissionCollectionInterface;

class PermissionInitializer implements PermissionInitializerInterface
{
    private bool $restrictedAccess;

    public function __construct(GlobalConfigInterface $globalConfig)
    {
        $this->restrictedAccess = $globalConfig->hasProcedureUserRestrictedAccess();
    }

    public function configurePermissions(ResolvablePermissionCollectionInterface $permissionCollection): void
    {
        $permissionCollection->configurePermissionInstance(
            Features::feature_annotated_statement_pdf_rollback_review_status(),
            PermissionConditionBuilder::start()
                ->enableAlways()
        );

        $permissionCollection->configurePermissionInstance(
            Features::feature_ai_generated_draft_segments(),
            PermissionConditionBuilder::start()
                ->enableIfUserHasRole('RAICOM')
                ->enableIfProcedureOwnedViaOrganisation(['RMOPSA', 'RMOPSD', 'RMOPPO'], $this->restrictedAccess)
                ->enableIfProcedureOwnedViaPlanningAgency(['RMOPSA', 'RMOPSD', 'RMOPPO'])
        );

        $permissionCollection->configurePermissionInstance(
            Features::feature_ai_create_annotated_statement_pdf_pages(),
            PermissionConditionBuilder::start()
                ->enableIfUserHasRole('RAICOM'),
        );

        $permissionCollection->configurePermissionInstance(
            Features::feature_import_statement_pdf(),
            PermissionConditionBuilder::start()
                ->enableIfUserHasRole('RAICOM')
                ->enableIfAllowedAsDataInputOrga()
                ->enableIfProcedureOwnedViaOrganisation(['RMOPSA', 'RMOPSD', 'RMOPHA', 'RMOHAW'], $this->restrictedAccess)
                ->enableIfProcedureOwnedViaPlanningAgency(['RMOPSA', 'RMOPSD', 'RMOPHA', 'RMOHAW'])
        );
    }
}
