<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\Repository;

use DemosEurope\DemosplanAddon\Contracts\Entities\CoreEntityInterface;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\AnnotatedStatementPdf;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\Persistence\ManagerRegistry;
use Exception;
use Psr\Log\LoggerInterface;

class AnnotatedStatementPdfRepository extends ServiceEntityRepository
{
    private LoggerInterface $logger;

    public function __construct(ManagerRegistry $registry, string $entityClass, LoggerInterface $logger)
    {
        parent::__construct($registry, $entityClass);
        $this->logger = $logger;
    }

    /**
     * @return mixed
     *
     * @throws Exception
     */
    public function rollbackBoxReviewStatus()
    {
        try {
            $em = $this->getEntityManager();

            $query = $em->createQueryBuilder()
                ->update(AnnotatedStatementPdf::class, 'a')
                ->set('a.status', ':newStatus')
                ->set('a.reviewer', ':reviewer')
                ->where('a.status = :currentStatus')
                ->setParameter('newStatus', AnnotatedStatementPdf::READY_TO_REVIEW)
                ->setParameter('reviewer', null)
                ->setParameter('currentStatus', AnnotatedStatementPdf::BOX_REVIEW)
                ->getQuery();

            return $query->execute();
        } catch (Exception $e) {
            $this->logger->error(
                'Error when rolling back Text Review Status in AnnotatedStatementPdfs',
                [$e]
            );
            throw $e;
        }
    }

    /**
     * @return mixed
     *
     * @throws Exception
     */
    public function rollbackTextReviewStatus()
    {
        try {
            $em = $this->getEntityManager();

            $query = $em->createQueryBuilder()
                ->update(AnnotatedStatementPdf::class, 'a')
                ->set('a.status', ':newStatus')
                ->set('a.reviewer', ':reviewer')
                ->where('a.status = :currentStatus')
                ->setParameter('newStatus', AnnotatedStatementPdf::READY_TO_CONVERT)
                ->setParameter('reviewer', null)
                ->setParameter('currentStatus', AnnotatedStatementPdf::TEXT_REVIEW)
                ->getQuery();

            return $query->execute();
        } catch (Exception $e) {
            $this->logger->error(
                'Error when rolling back Text Review Status in AnnotatedStatementPdfs',
                [$e]
            );
            throw $e;
        }
    }

    /**
     * Returns those AnnotatedStatementPdfs which are in Reviewed status and not blocked,
     * filtered by Procedure id.
     *
     * @return array<int, AnnotatedStatementPdf>
     */
    public function findByStatus(string $status): array
    {
        return $this->createQueryBuilder('pdf')
            ->where('pdf.status = :status')
            ->setParameter('status', $status)
            ->getQuery()
            ->getResult();
    }

    /**
     * Will use an implicit transaction, meaning in case of an failure in a later entity all previous
     * changes are reverted.
     *
     * @param CoreEntityInterface[] $entities
     *
     * @return CoreEntityInterface[]
     *
     */
    public function updateObjects($entities)
    {
        $em = $this->getEntityManager();
        foreach ($entities as $entity) {
            $em->persist($entity);
        }
        $em->flush();

        return $entities;
    }

    /**
     * Returns next AnnotatedStatementPdf to be reviewed.
     *
     * @return string
     */
    public function getNextAnnotatedStatementPdfToReview(string $procedureId): ?string
    {
        return 0 < $this->getAnnotatedStatementPdfsByStatusCount(AnnotatedStatementPdf::READY_TO_REVIEW, $procedureId)
            ? $this
                ->getAnnotatedStatementPdfsByStatus(AnnotatedStatementPdf::READY_TO_REVIEW, $procedureId)
                ->current()
                ->getId()
            : null;
    }

    public function getAnnotatedStatementPdfsByStatusCount(string $status, $procedureId): int
    {
        return $this->getAnnotatedStatementPdfsByStatus($status, $procedureId)->count();
    }

    public function getAnnotatedStatementPdfsByStatus(string $status, $procedureId): Collection
    {
        return $this->getAnnotatedStatementPdfsByProcedureId($procedureId)->filter(
            function (AnnotatedStatementPdf $annotatedStatementPdf) use ($status) {
                return $status === $annotatedStatementPdf->getStatus();
            }
        );
    }

    /**
     * @return Collection<int, AnnotatedStatementPdf>
     */
    public function getAnnotatedStatementPdfsByProcedureId(string $procedureId): Collection
    {
        $result = $this->createQueryBuilder('pdf')
            ->where('pdf.procedure = :procedure')
            ->setParameter('procedure', $procedureId)
            ->getQuery()
            ->getResult();

        return null !== $result
            ? new ArrayCollection($result)
            : new ArrayCollection();
    }

    /**
     * Returns next AnnotatedStatementPdf ready to be converted to a Statement.
     *
     * @return string
     */
    public function getNextAnnotatedStatementPdfsReadyToConvert(string $procedureId): ?string
    {
        return 0 < $this->getAnnotatedStatementPdfsByStatusCount(AnnotatedStatementPdf::READY_TO_CONVERT, $procedureId)
            ? $this
                ->getAnnotatedStatementPdfsByStatus(AnnotatedStatementPdf::READY_TO_CONVERT, $procedureId)
                ->current()
                ->getId()
            : null;
    }


}
