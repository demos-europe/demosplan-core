<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\Controller;

use DemosEurope\DemosplanAddon\Contracts\CurrentContextProviderInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\ParameterProviderEventInterface;
use DemosEurope\DemosplanAddon\Contracts\Handler\ProcedureHandlerInterface;
use DemosEurope\DemosplanAddon\Contracts\Services\InitializeServiceInterface;
use DemosEurope\DemosplanAddon\Contracts\Services\ProcedureServiceInterface;
use DemosEurope\DemosplanAddon\Contracts\Services\StatementServiceInterface;
use DemosEurope\DemosplanAddon\Controller\APIController;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\AnnotatedStatementPdf;
use DemosEurope\DemosplanAddon\DemosPipes\Event\ParameterProviderEvent;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\AnnotatedStatementPdfService;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\PipelineCommunication\AiPipelineConfiguration;
use DemosEurope\DemosplanAddon\DemosPipes\Repository\AnnotatedStatementPdfRepository;
use DemosEurope\DemosplanAddon\Exception\InvalidStatusTransitionException;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use DemosEurope\DemosplanAddon\Response\APIResponse;
use Exception;
use Psr\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class DemosPlanAnnotatedStatementPdfController extends APIController
{
    /**
     * @Route(
     *     name="dplan_annotated_statement_pdf_review",
     *     methods={"GET"},
     *     path="/verfahren/{procedureId}/annotatedStatementPdf/{documentId}/review",
     *     options={"expose": true})
     *
     * @throws InvalidStatusTransitionException
     * @throws Exception
     */
    public function reviewAction(
        AiPipelineConfiguration      $aiPipelineConfiguration,
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        EventDispatcherInterface     $eventDispatcher,
        InitializeServiceInterface   $initializeService,
        PermissionEvaluatorInterface $permissionEvaluator,
        string                       $procedureId,
        string                       $documentId
    ): Response
    {
        $initializeService->initialize([]);
        $permissionEvaluator->requirePermission(Features::feature_import_statement_pdf());

        $annotatedStatementPdf = $annotatedStatementPdfService->findOneById($documentId);
        if (!$annotatedStatementPdfService->validateBoxReview($annotatedStatementPdf)) {
            return new RedirectResponse(
                $this->generateUrl(
                    'DemosPlan_procedure_dashboard',
                    ['procedure' => $procedureId]
                )
            );
        }

        // Access these action while the AnnotatedStatementPdf is already
        // in review by the current user, is a valid case.
        // But setting the status form BOX_REVIEW to BOX_REVIEW is not allowed.
        if (AnnotatedStatementPdf::BOX_REVIEW !== $annotatedStatementPdf->getStatus()) {
            $annotatedStatementPdfService->setBoxReviewStatus($annotatedStatementPdf);
        }

        $templateVars = [
            'documentId' => $documentId,
            'aiPipelineLabels' => $aiPipelineConfiguration->getAiPipelineLabels(),
        ];
        $event = new ParameterProviderEvent('@DemosPlanProcedure/DemosPlanProcedure/administration_annotate.html.twig',
                                                        [
                                                            'templateVars' => $templateVars,
                                                            'procedure' => $procedureId,
                                                            'title' => 'statements.uploaded.recheck',
                                                        ]);
        $eventDispatcher->dispatch($event, ParameterProviderEventInterface::class);
        $parameters = $event->getParameters();

        return $this->render('@DemosPlanProcedure/DemosPlanProcedure/administration_annotate.html.twig',
                            $parameters);
    }

    /**
     * @Route(
     *     name="dplan_next_annotated_statement_pdf_to_review",
     *     methods={"GET"},
     *     path="/verfahren/{procedureId}/next-annotated-statement-to-review/{documentId}",
     *     options={"expose": true})
     *
     * @throws Exception
     */
    public function nextAnnotatedStatementPdfToReviewAction(
        InitializeServiceInterface      $initializeService,
        PermissionEvaluatorInterface    $permissionEvaluator,
        ProcedureHandlerInterface       $procedureHandler,
        AnnotatedStatementPdfRepository $annotatedStatementPdfRepository,
        string                          $procedureId
    ): Response {
        $initializeService->initialize([]);
        $permissionEvaluator->requirePermission(Features::feature_import_statement_pdf());

        $result = [
            'documentId' => $annotatedStatementPdfRepository->getNextAnnotatedStatementPdfToReview($procedureId),
        ];

        return APIResponse::create($result, 200);
    }

    /**
     * @Route(
     *     name="dplan_convert_annotated_pdf_to_statement",
     *     methods={"GET"},
     *     path="/verfahren/{procedureId}/annotatedStatementPdf/{documentId}/umwandeln",
     *     options={"expose": true})
     *
     * @throws Exception
     */
    public function convertToStatementAction(
        AiPipelineConfiguration         $aiPipelineConfiguration,
        AnnotatedStatementPdfService    $annotatedStatementPdfService,
        CurrentContextProviderInterface $currentContextProvider,
        EventDispatcherInterface        $eventDispatcher,
        InitializeServiceInterface      $initializeService,
        PermissionEvaluatorInterface    $permissionEvaluator,
        ProcedureServiceInterface       $procedureService,
        StatementServiceInterface       $statementService,
        string                          $procedureId,
        string                          $documentId
    ): Response {
        $initializeService->initialize([]);
        $permissionEvaluator->requirePermission(Features::feature_import_statement_pdf());

        $annotatedStatementPdf = $annotatedStatementPdfService->findOneById($documentId);
        if (!$this->validateTextReview($annotatedStatementPdf)) {
            return new RedirectResponse(
                $this->generateUrl(
                    'DemosPlan_procedure_dashboard',
                    ['procedure' => $procedureId]
                )
            );
        }
        $annotatedStatementPdfService->setTextReviewStatus($annotatedStatementPdf);

        $templateVars = [
            'documentId' => $documentId,
            'newestInternalId' => $statementService->getNewestInternId($procedureId),
            'usedInternIds' => $statementService->getInternIdsFromProcedure($procedureId),
            'aiPipelineLabels' => $aiPipelineConfiguration->getAiPipelineLabels(),
            'submitter' => $annotatedStatementPdf->getSubmitterJson(),
            'currentProcedurePhase' => $currentContextProvider->getCurrentProcedure()->getPhase(),
        ];
        if ($permissionEvaluator->isPermissionEnabled('feature_statements_tag')) {
            $templateVars['availableTopics'] = $procedureService->getTopics($procedureId);
        }

        $event = new ParameterProviderEvent('@DemosPlanProcedure/DemosPlanProcedure/administration_convert_annotated_pdf.html.twig',
            [
                'templateVars' => $templateVars,
                'procedure' => $procedureId,
                'title' => 'statements.uploaded.confirm',
            ]);
        $eventDispatcher->dispatch($event, ParameterProviderEventInterface::class);
        $parameters = $event->getParameters();

        return $this->render('@DemosPlanProcedure/DemosPlanProcedure/administration_convert_annotated_pdf.html.twig',
            $parameters);
    }

    /**
     * @throws Exception
     */
    private function validateTextReview(
        AnnotatedStatementPdf $annotatedStatementPdf
    ): bool
    {
        if (AnnotatedStatementPdf::TEXT_REVIEW === $annotatedStatementPdf->getStatus()) {
            $this->messageBag->add(
                'error',
                'error.annotated.statement.text.already.being.reviewed',
                ['user' => $annotatedStatementPdf->getReviewer()->getName()]
            );

            return false;
        }
        if (AnnotatedStatementPdf::READY_TO_CONVERT !== $annotatedStatementPdf->getStatus()) {
            $this->messageBag->add(
                'error',
                'error.annotated.statement.not.ready.to.confirm',
                ['user' => $annotatedStatementPdf->getReviewer()->getName()]
            );

            return false;
        }

        return true;
    }
}
