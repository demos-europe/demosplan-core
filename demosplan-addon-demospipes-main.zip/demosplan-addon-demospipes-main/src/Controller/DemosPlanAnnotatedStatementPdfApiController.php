<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\DemosPipes\Controller;

use DemosEurope\DemosplanAddon\Contracts\CurrentProcedureServiceInterface;
use DemosEurope\DemosplanAddon\Contracts\Handler\ProcedureHandlerInterface;
use DemosEurope\DemosplanAddon\Contracts\Services\InitializeServiceInterface;
use DemosEurope\DemosplanAddon\Controller\APIController;
use DemosEurope\DemosplanAddon\DemosPipes\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosPipes\Entity\AnnotatedStatementPdf;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\AnnotatedStatementPdfService;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\PiBoxRecognitionErrorManager;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\PiTextRecognitionErrorManager;
use DemosEurope\DemosplanAddon\DemosPipes\Logic\PipelineCommunication\PiResourceFetcher;
use DemosEurope\DemosplanAddon\DemosPipes\Repository\AnnotatedStatementPdfRepository;
use DemosEurope\DemosplanAddon\DemosPipes\ResourceType\AnnotatedStatementPdfResourceType;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use DemosEurope\DemosplanAddon\Response\APIResponse;
use Exception;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


class DemosPlanAnnotatedStatementPdfApiController extends APIController
{
    /**
     * Action called by PI with a url to retrieve the pages (with their corresponding
     * sections/boxes) for the AnnotatedStatementPdf.
     *
     * The url will be called to get the info, generate the AnnotatedStatementPdfPage entities
     * and update AnnotatedStatementPdf.
     *
     * @Route(
     *     name="dplan_ai_api_annotation_statement_pdf_boxes_proposal",
     *     methods={"POST"},
     *     path="/api/ai/annotated-statement-pdf/boxes-proposal/{annotatedStatementPdfId}")
     * )
     *
     * @return APIResponse
     */
    public function boxesProposalAction(
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        InitializeServiceInterface   $initializeService,
        PermissionEvaluatorInterface $permissionEvaluator,
        PiResourceFetcher            $piResourceFetcher,
        Request                      $request,
        string                       $annotatedStatementPdfId
    ): Response {
        try {
            $initializeService->initialize([]);
            $permissionEvaluator->requirePermission(Features::feature_ai_create_annotated_statement_pdf_pages());

            $this->logger->info('Try to update AnnotatedStatementPdf on boxes proposal from PI for AnnotatedStatementPdf: ' . $annotatedStatementPdfId);

            $annotatedStatementPdfService->updateAnnotatedStatementPdf(
                $request,
                $piResourceFetcher,
                $annotatedStatementPdfId,
                AnnotatedStatementPdf::READY_TO_REVIEW,
                true
            );

            return $this->createEmptyResponse();
        } catch (Exception $e) {
            return $this->handleApiError($e);
        }
    }

    /**
     * Action called by PI when error while doing the pdf boxes recognition.
     *
     * @Route(
     *     name="dplan_ai_api_annotation_statement_pdf_boxes_proposal_error",
     *     methods={"POST"},
     *     path="/api/ai/annotated-statement-pdf/boxes-proposal-error/{annotatedStatementPdfId}")
     * )
     *
     * @return APIResponse
     */
    public function boxesProposalErrorAction(
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        InitializeServiceInterface   $initializeService,
        PermissionEvaluatorInterface $permissionEvaluator,
        PiBoxRecognitionErrorManager $errorManager,
        PiResourceFetcher            $piResourceRequester,
        Request                      $request,
        string                       $annotatedStatementPdfId
    ): Response
    {
        try {
            $initializeService->initialize([]);
            $permissionEvaluator->requirePermission(Features::feature_ai_create_annotated_statement_pdf_pages());

            $piErrorInfo = $piResourceRequester->getPiResourceInfo($request);
            $annotatedStatementPdf = $annotatedStatementPdfService->findOneById(
                $annotatedStatementPdfId
            );
            $errorManager->managePiError(
                $annotatedStatementPdf,
                $annotatedStatementPdfId,
                $piErrorInfo
            );

            return $this->createEmptyResponse();
        } catch (Exception $e) {
            return $this->handleApiError($e);
        }
    }

    /**
     * Action called by PI with a url to retrieve the Statement Text Proposal for the
     * AnnotatedStatementPdf.
     *
     * The url will be called to get the text and update the entity accordingly.
     *
     * @Route(
     *     name="dplan_ai_api_annotation_statement_pdf_text_proposal",
     *     methods={"POST"},
     *     path="/api/ai/annotated-statement-pdf/text-proposal/{annotatedStatementPdfId}")
     * )
     *
     * @return APIResponse
     */
    public function textProposalAction(
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        InitializeServiceInterface   $initializeService,
        PermissionEvaluatorInterface $permissionEvaluator,
        PiResourceFetcher            $piResourceFetcher,
        Request                      $request,
        string                       $annotatedStatementPdfId
    ): Response {
        try {
            $initializeService->initialize([]);
            $permissionEvaluator->requirePermission(Features::feature_ai_create_annotated_statement_pdf_pages());

            $annotatedStatementPdfService->updateAnnotatedStatementPdf(
                $request,
                $piResourceFetcher,
                $annotatedStatementPdfId,
                AnnotatedStatementPdf::READY_TO_CONVERT,
                false
            );

            return $this->createEmptyResponse();
        } catch (Exception $e) {
            return $this->handleApiError($e);
        }
    }

    /**
     * Action called by PI when error while doing the text recognition from a pdf.
     *
     * @Route(
     *     name="dplan_ai_api_annotation_statement_pdf_text_proposal_error",
     *     methods={"POST"},
     *     path="/api/ai/annotated-statement-pdf/text-proposal-error/{annotatedStatementPdfId}"
     * )
     *
     * @return APIResponse
     */
    public function textProposalErrorAction(
        AnnotatedStatementPdfService  $annotatedStatementPdfService,
        InitializeServiceInterface    $initializeService,
        PermissionEvaluatorInterface  $permissionEvaluator,
        PiResourceFetcher             $piResourceRequester,
        PiTextRecognitionErrorManager $errorManager,
        Request                       $request,
        string                        $annotatedStatementPdfId
    ): Response
    {
        try {
            $initializeService->initialize([]);
            $permissionEvaluator->requirePermission(Features::feature_ai_create_annotated_statement_pdf_pages());

            $piErrorInfo = $piResourceRequester->getPiResourceInfo($request);
            $annotatedStatementPdf = $annotatedStatementPdfService->findOneById(
                $annotatedStatementPdfId
            );
            $errorManager->managePiError(
                $annotatedStatementPdf,
                $annotatedStatementPdfId,
                $piErrorInfo
            );

            return $this->createEmptyResponse();
        } catch (Exception $e) {
            return $this->handleApiError($e);
        }
    }

    /**
     * @Route(
     *     name="dplan_ai_api_get_annotation_statement_pdf",
     *     methods={"GET"},
     *     path="/api/ai/procedure/{procedureId}/annotated-statement-pdf/{annotatedStatementPdfId}")
     *
     * @return APIResponse
     *
     * @throws Exception
     */
    public function getAnnotatedStatementPdfAction(
        AnnotatedStatementPdfService     $annotatedStatementPdfService,
        InitializeServiceInterface       $initializeService,
        PermissionEvaluatorInterface     $permissionEvaluator,
        string                           $annotatedStatementPdfId
    ): Response {
        $initializeService->initialize([]);
        $permissionEvaluator->requirePermission(Features::feature_ai_create_annotated_statement_pdf_pages());
        $annotatedStatement = $annotatedStatementPdfService->findOneById($annotatedStatementPdfId);

        $resource = $this->resourceService->makeItemOfResource(
            $annotatedStatement,
            AnnotatedStatementPdfResourceType::getName()
        );

        return $this->renderResource($resource);
    }

    /**
     * @Route(
     *     name="dplan_next_annotated_pdf",
     *     methods={"GET"},
     *     path="/verfahren/{procedureId}/nextAnnotatedStatementPdf/{documentId}",
     *     options={"expose": true})
     *
     * @throws Exception
     */
    public function nextAnnotatedStatementPdfAction(
        InitializeServiceInterface   $initializeService,
        PermissionEvaluatorInterface $permissionEvaluator,
        ProcedureHandlerInterface    $procedureHandler,
        AnnotatedStatementPdfRepository $annotatedStatementPdfRepository,
        string                       $procedureId
    ): Response {
        $initializeService->initialize([]);
        $permissionEvaluator->requirePermission(Features::feature_import_statement_pdf());

        $result = [
            'documentId' => $annotatedStatementPdfRepository->getNextAnnotatedStatementPdfToReview($procedureId),
        ];

        return APIResponse::create($result, 200);
    }

    /**
     * @Route(
     *     name="dplan_annotated_statement_pdf_pause_box_review",
     *     methods={"POST"},
     *     path="/verfahren/{procedureId}/annotatedStatementPdf/{documentId}/box-review/pause",
     *     options={"expose": true})
     */
    public function pauseBoxReviewAction(
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        PermissionEvaluatorInterface $permissionEvaluator,
        InitializeServiceInterface   $initializeService,
        string                       $documentId
    ): Response
    {
        try {
            $initializeService->initialize([]);
            $permissionEvaluator->requirePermission(Features::feature_import_statement_pdf());

            $annotatedStatementPdf = $annotatedStatementPdfService->findOneById($documentId);
            if (AnnotatedStatementPdf::BOX_REVIEW !== $annotatedStatementPdf->getStatus()) {
                return $this->createInvalidStatusTransitionResponse();
            }
            $annotatedStatementPdfService->pauseBoxReviewStatus($annotatedStatementPdf);

            return $this->createResponse([], 200);
        } catch (Exception $e) {
            return $this->handleApiError();
        }
    }

    /**
     * @Route(
     *     name="dplan_annotated_statement_pdf_pause_text_review",
     *     methods={"POST"},
     *     path="/verfahren/{procedureId}/annotatedStatementPdf/{documentId}/text-review/pause",
     *     options={"expose": true})
     */
    public function pauseTextReviewAction(
        AnnotatedStatementPdfService $annotatedStatementPdfService,
        InitializeServiceInterface   $initializeService,
        PermissionEvaluatorInterface $permissionEvaluator,
        string                       $documentId
    ): Response
    {
        try {
            $initializeService->initialize([]);
            $permissionEvaluator->requirePermission(Features::feature_import_statement_pdf());

            $annotatedStatementPdf = $annotatedStatementPdfService->findOneById($documentId);
            if (AnnotatedStatementPdf::TEXT_REVIEW !== $annotatedStatementPdf->getStatus()) {
                return $this->createInvalidStatusTransitionResponse();
            }
            $annotatedStatementPdfService->pauseTextReviewStatus($annotatedStatementPdf);

            return $this->createResponse([], 200);
        } catch (Exception $e) {
            return $this->handleApiError();
        }
    }

    private function createInvalidStatusTransitionResponse(): JsonResponse
    {
        $data = [
            'errors' => [
                [
                    'status' => 422,
                ],
            ],
        ];

        return new JsonResponse($data);
    }
}
