# CHANGELOG

## UNRELEASED

**Fixes**

- Update parameters

## v1.0 - 01-06-2023

- First release of the addon packaged demospipes integration.

