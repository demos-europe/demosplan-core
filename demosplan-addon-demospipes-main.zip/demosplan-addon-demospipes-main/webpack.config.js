const DemosPlanAddon = require('@demos-europe/demosplan-addon')

const config = DemosPlanAddon.build(
    'demosplan-addon-demospipes',
    {
        'TagRecommendationTab': DemosPlanAddon.resolve(
            'client/addons/TagRecommendationTab/TagRecommendationTab.vue'
        ),
        'SplitStatementView': DemosPlanAddon.resolve(
            'client/addons/SplitStatementView/SplitStatementView.vue'
        ),
        'StatementPdfImport': DemosPlanAddon.resolve(
            'client/addons/StatementPdfImport/StatementPdfImport.vue'
        ),
        'StatementPdfImportStatusChart': DemosPlanAddon.resolve(
            'client/addons/StatementPdfImportStatusChart/StatementPdfImportStatusChart.vue'
        )
    }
)

module.exports = config
