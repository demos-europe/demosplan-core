# Split statement view

**Template:** `administration_split_statement.html.twig`  
**Components:** `SplitStatementView`, `CardPane`, `Card`, `TextEditor`, `BottomBar`, `BubbleMenu`, `TextSegment`  
**Store:** `SplitStatementStore`  
**Tiptap plugins:** `segmentMark`

![Split statement view](assets/split_statement_view.png)

Possible actions on each segment: confirm PI proposal, edit segment (tag & position in text), remove segment/remove draft segment, add new segment.

## SplitStatementView component
This is a wrapper for smaller components. It is responsible for:
- setting initial data in the store
- fetching data
- firing the save action
- triggering the edit mode of a segment (by toggling the bottom bar, setting editingSegment in store and adding selection handles in the text editor)
- handling segment addition/deletion
- handling bubbleMenu behaviour (controls bubble position and show/hide).

## SplitStatementStore
Most data is stored in SplitStatementStore, as it needs to be accessed from different components (text editor, tags pane, bubble menu and bottom bar). The store should be a single source of truth in the workflow, and the prosemirror state (text editor) should always be in-sync with the store. The store also has the info about currently hovered segment and edit mode state (on/off).

### Recalculate positions of segments for prosemirror on load (`recalculatePositionsInText` mutation)
In the beginning, we receive the positions of the segments (charStart and charEnd for each segment, not its text content) from PI calculated for a string with html tags. However, because in the text editor the segments are marked based on the prosemirror character positioning, we have to recalculate the PI-positions to match the counting of prosemirror. It happens after the initial data is fetched, but before it is displayed for the first time. Here is how prosemirror counts positions in text: https://prosemirror.net/docs/guide/ -> indexing.

To map the positions, we iterate through the whole HTML-string, letter by letter. If we encounter a HTML-tag, we increment the prosemirror position by 1 (because prosemirror counts each tag as 1 character) and then wait until the tag is closed without further incrementation. Outside the html-tags we count each sign/letter as one prosemirror-position. By each iteration (by every letter) it has to be checked, whether any segment starts or ends at the current iterator index and if so, the number is replaced by mapped prosemirror-position value. It doesn't work perfectly and there are plans to replace the html-string format with json format when interacting with PI.

## Text editor
The text editor is where the whole logic regarding segment spans manipulation takes place. It is a wrapper for the displayed statement text and it ensures that segments are shown in correct places and that they can be edited. Text editor is a wrapper for a readonly tiptap instance.

### PreventDrop and PreventKeyboardInput
These two Tiptap plugins are used to disable text input and text manipulation in the editor if `editable` prop is set to `false`. In this case it should be impossible to move parts of the text or to add/remove characters.

### setMarks function
Setting segmentMarks in the text is done in two steps. First, all existing marks are removed (`removeAllMarks` function) and then for each segment, text between charStart and charEnd is selected and segmentMark is toggled. That means that even if only one segment is edited, all visible segment marks have to be removed first and all segments have to be set again. This is unfortunately suboptimal and inefficient for longer texts.

### Segments adjustments and Decoration.js plugin
#### 1. adding selection handles
To edit a segment span, edit mode has to be active. After triggering the edit mode, the `addSelectionHandles` function is called in `SplitStatementView` component, in `enableEditMode` function. This function invokes `setHandle` in Text editor twice, once for every handle (1x at the beginning and 1x at the end of the segment). Then a prosemirror transaction to add **placeholderPlugin** (`Decoration.js`) is dispatched. In `TextEditor` we watch for editModeActive property and if it is set to true, we assume that handles have been added and the event listeners on handles are added (`addMousedownListenersForHandles`).

**It looks more or less like this:**  
edit mode triggered -> enableEditMode in SplitStatementView -> addSelectionHandles in SplitStatementView -> setHandle in TextEditor -> transaction to add placeholderPlugin dispatched -> watcher in TextEditor receives info about triggered edit mode and in `nextTick` addMousedownListenersForHandles is called.

#### 2. moving the handles
When clicking on a handle, a `startSegmentRangeChange` function is called. When moving the handle, the text selection is set between the initial handle position and the resolved new mouse position. The transaction is dispatched, and these kinds of transactions are filtered in the onTransaction editor hook, in order to set the placeholderPlugin (handles) in a new position (the handle should move along with the mouse). 

Then the event listener on mouseup is added to the handle.

#### 3. setting new segment mark on handle release
On mouseup, the `applySegmentRangeChange` function is called. First it has to be checked, if the new segment range intersects with other segments (`getSegmentsIntersections` and `recalculateSegmentBoundaries`) and if so, these segments are shortened (as parts of them now belong to the edited segment). Secondly, the new marks are set using `setMarks` function (see above). At the end, the `recalculate-tags-position` event is emitted, to tell cardPane to adjust positions of the tagsContainers to new segments.

![Selection handles](assets/selection_handles.png)

## Text segment and segment mark
Segments in text are rendered as Vue components - `TextSegment`. The prosemirror mark with its schema and commands is defined in `segmentMark.js`. The `TextSegment` component renders a span with attributes such as id (segment id) and classes, with background color for different highlight states.

### Extract segment HTML
When the splitting is finished, FE sends an object with segments data to BE in order to create segment entities based on that data. To make sure that the text of each segment is extracted correctly from the HTML string (same problem with counting as on load of segment drafts would occur), we do it in FE and send it together with the rest of infos to BE.

In `SplitStatementView` on finishAndSave the `extractSegmentHTML` function for each segment component is invoked. The function looks for all spans in text with the id of the segment and concatenates their innerHTML.

### Edit mode
As a preparation for the statement-split-edit Workflow (<Ticket>T20501</Ticket>) a property `editable` was introduced (in SplitStatementView component). It allows the user to edit the content of the text editor. If it is set to `true`, the tiptap-plugins for disabling input are deactivated.

On each editor content update it is checked if the content was changed (`checkForUserInput`) and if so, the `recalculateSegmentsPositions` is fired and new charStart and charEnd for each segment are saved to store.

### Remove ghost instances
Tiptap adds several fake instances of an existing component on each transaction (bug). To prevent instantiating too many of them, we check (in the created hook of the component) if a TextSegment with exactly the same segment id already exists and if so, the mounting of the component is prevented (component is destroyed).

## Bubble menu
This component is a contextual menu for segments. It is displayed in 2 cases:
- segment/tag hover - 3 buttons are shown:
  1. confirm segment proposal (if the segment was proposed by the AI-service)
  2. edit segment (only shown if edit mode is off)
  3. delete segment/delete draft segment
- on selection hover - if some text in the editor is selected, on hover the bubble displays one button to create a new segment from the selection

The position of the bubble is controlled by the parent-component (`SplitStatementView`) - the component listens to emits froom its children and the bubble position and visibility are updated accordingly.

The bubble will only be shown on hover, if the user is not selecting text and if the edit mode is not active.

![Bubble menu](assets/bubble_menu.png)

## Bottom bar
The bottom bar has two main functionalities:
- editing segment tags
- triggering save segment/finish splitting

![Bottom bar](assets/bottom_bar.png)

### Edit segment tags
When edit mode is activated, the bottom bar displays tags of the currently edited segment. There are 3 components there:
1. `SearchSelect` - makes it possible to search through all defined tags
2. `TagSelect` - shows which tags are currently selected and allows users to unselect them
3. `DpCreateTag` - gives a possibility to create new tags and topics on the fly  

### Save segment
On click on the save button, the current state will be saved in the database. No segments will be created, just the json with the segment info (charStart, charEnd, tags) will be saved so that the user will later be able to recreate the current segmentation state to finish it. The action in store is `saveSegmentsDrafts`.

### Save segments and finish segmentation
On click on the save and finish button, first the text of each segment is extracted (in `saveAndFinish` method in SplitStatementView, using `extractSegmentHTML` method of TextSegment component). Then, a request is sent to BE to create segments as entities in database from the FE data.
 
 At this point we also extract editor's currentValue and send it to BE as statementText property. The plan is that in the future this text will be initially loaded into the editor to enable statement text edit.
 
 But at the moment it is not possible to load the same statement into the split view again after it has been saved. The user will see the next ready-to-split statement.


## Card pane with Tag Containers
Each segment in the statement text has a corresponding tag container. The pane is a wrapper for containers.
On Card mount the position of tag is calculated (they are positioned absolute on the pane) - the offset of the segment is searched and the tag is positioned with the same offset as segment, so they should always align (`calculateCardPosition` method in Card). If there are more containers with the same offset, they are grouped and stacked onto each other (`positionTags` in cardPane). If that's the case, the tags will only be visible on Card hover/segment hover.

The Card should always stay in viewport (sticky), as long as a corresponding segment is visible.

![Cards](assets/tags.png)

## Plans for development
Segment-split-editing: <Ticket>T18914</Ticket>, <Ticket>T20501</Ticket>
