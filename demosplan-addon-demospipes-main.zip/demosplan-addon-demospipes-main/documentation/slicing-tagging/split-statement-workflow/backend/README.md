
# Segmentation workflow backend

Backend keeps track of the status in the segmentation process and communicates with frontend and PI for them to act accordingly.

## 1. Send new Statement text to PI
When a new Statement is created (manually or from some other workflow) backend will send the text to PI for it to be split into segments.
 - Class: `StatementHandler`
 - Method: `newStatement` (`$this->piSegmentRecognitionRequester->request($copyOfStatement);`)
 - Permission: `feature_ai_generated_draft_segments`
 - URL:  `/api/v1/statements/SegmentedStatement` (parameter `ai_service_post_url`)
 - Request Body: 
 
 `
{
    "data": {
        "attributes": {
        "pipeline_id": "{parameter: pi.pipeline.segment.recognition.id}",
        "parameters": {
            "de.demos-deutschland.SlicingTagging:0:procedure_id": "{procedureId}",
            "de.demos-deutschland.SlicingTagging:0:statement_id": "{statementId}",
            "de.demos-deutschland.URLSource:0:URL": "{route_name: dplan_ai_api_statement_text}}",
            "de.demos-deutschland.URLSource:0:authorization": "{parameter: pipeline.demos.authorization}",
            "de.demos-deutschland.URLTarget:0:URL": "{route_name: dplan_ai_api_statement_segments_proposal}",
            "de.demos-deutschland.URLTarget:0:authorization": "{parameter: pipeline.demos.authorization}"
        },
        "error_url": "{route_name: dplan_api_segmented_statement_create_error}",
        "error_auth": "{parameter: pipeline.demos.authorization}"
        }
    }
}
`

 - Response
	 - Success 202, the Statement status will be set to *pendingSegmentation* 
## 2. Handle segment proposals sent by PI
**Route Information**
 - Controller: `SegmentedStatementAPIController`
 - Route name: `dplan_api_segmented_statement_create`
 - Permission:  `feature_ai_generated_draft_segments`
 - Body example:

_
 
  


    {
    	    "data": {
    		    "type": "SegmentedStatement",
    		    "id": "UUIDv4 aus URL-Pfad",
    		    "attributes": {
    		    	"text": "Text der Stellungnahme"
    		    },
    		    "relationships": {
    		    	"tags": [
    	    			{ "data": { "id": "1", "type": "Tag" } },
    	    			{ "data": { "id": "2", "type": "Tag" } }
    		    	],
    		    	"draftsList": [
    	    			{ "data": { "id": "1", "type": "DraftSegment" } },
    	    			{ "data": { "id": "2", "type": "DraftSegment" } }
    		    	]
    		    }
    	    },
    	    "included": [
    		    {
    			    "id": "1",
    			    "type": "Tag",
    			    "attributes": { "title": "Gewerbe"},
    			    "relationships": {
    			    	"tagTopic": [ { "data": { "id": "1", "type": "TagTopic" } } ]
    			    }
    		    },
    		    {
    		    "id": "2",
    	    		"type": "Tag",
    				"attributes": { "title": "Verkehr" },
    	    		"relationships": {
    	   				"topic": [ { "data": { "id": "1", "type": "TagTopic" } } ]
    			    }
    		    },
    		    {
    			    "id": "1",
    			    "type": "TagTopic",
    			    "attributes": { "title": "Sonstiges"}
    		    },
    		    {
    			    "type": "DraftSegment",
    			    "id": "1",
    			    "attributes": {
    			    	"tag": { "1": 0.21694, "4": 0.81057 },
    			    	"score": null,
    			    	"position": { "start": 0, "stop": 591 },
    				    "segmentStatus": "proposed"
    			    }
    		    },
    		    {
    			    "type": "DraftSegment",
    			    "id": "2",
    			    "attributes": {
    				    "tag": { "3": 0.74871 },
    				    "score": null,
    				    "position": { "start": 592, "stop": 720 },
    				    "segmentStatus": "proposed"
    			    }
    		    }
    	    ]
        }

  
> To make it more readable ids are written as integers instead of the actually used UUIDv4.
  
**Actions**
 - Sets the received body to the property **draftsListJson** of **Statement**.

## 3. Reviews in FE
### 3.1 Show the Info in FE
#### 3.1.1 Twig Template
**Route Information**
 - Controller: `DraftsInfoController`
 - Route name: `dplan_drafts_list_claim`
 - Permission:  `area_statement_segmentation`

**Actions**
- Render the Twig template passing the Statement ID and Procedure ID

#### 3.1.2 Ajax Json API
**Route Information** 
 - Controller: `DraftsInfoApiController`
 - Route name: `dplan_drafts_list_edit_ajax`
 - Permission:  `area_statement_segmentation`

**Actions**
- Returns the drafts info json stored for the statement.

### 3.2 Save the info from FE

**Route Information** 
 - Controller: `DraftsInfoController`
 - Route name: `dplan_drafts_list_save`
 - Permission:  `area_statement_segmentation`

**Actions**
- Update the property **draftsListJson** of **Statement** with the received Json from frontend.

## 4. Convert the drafts into Segments
Once the segments have been fully reviewed by the user, they can confirm the process and finish the segmentation.

**Route Information** 
 - Controller: `DraftsInfoController`
 - Route name: `dplan_drafts_list_confirm`
 - Permission:  `area_statement_segmentation`

**Actions**
- Transform every element in the draftsInfoList to a Segment entity (just a type of Statement).
- Connect the Segments to the Statement they are originally coming from (bidirectional relationship)

## DATABASE DETAILS
Table ***_statement*** is used to store both ***Statements*** and ***Segments***. We need some new columns to store ***Segment*** specific content as well as to allow us to differentiate when a register in this table represents a **_Statement_** and when a ***Segment***.

 - ***drafts_info_json***
	Used only by _**Statements**_, this columns stores the Drafts Info Json.
	
 - ***segment_statement_fk***
	Used only by ***Segments***, this column stores the foreign key that points to the ***Statement*** where the _**Segment**_ comes from .
	
 - ***entity_type***
Use by both _**Statements**_ and _**Segments**_ to discriminate which type every register in the database belongs to.
