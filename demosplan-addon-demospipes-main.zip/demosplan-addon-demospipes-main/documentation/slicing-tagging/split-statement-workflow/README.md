---
sidebarTitle: Split statement workflow
---

# Split statement workflow
The split statement workflow is used to divide statements into smaller parts called segments, which are coherent in terms of content. 

The whole process is supported by the AI-service, that proposes a division of the text and tags each draft segment with keywords regarding its content. Draft segments are then loaded in the interface and a user can accept or edit them, remove incorrect segments and add new ones with tags.

It is possible to save partial progress while splitting, but once the segmentation is confirmed, the segments will be extracted and the next statement will be loaded.

## Naming conventions
In this documentation as well as in the code, some naming conventions will be used to refer to the different elements involved in the process.

**DraftsInfo**: Full Json string returned by PI when processing the text of a  Statement.

**DraftsList**: The **DraftsInfo** contains an array of **Drafts** (also referred to as (segment) **Proposals**) representing individual pieces of text that can potentially be converted to independent entities.

**Tags**: Every **Draft** contains a list of **Tags** which are keywords to identify the topic/s the drafts are about.

**Segments**: At the end of the workflow every **Draft** will be converted to a new entity called Segment, which will be treated as a type of Statement.

## Entry points
The entry points for the workflow are defined in two places:
- in **Procedure Overview** there is a new tile with a starting button. In this case the next "ready-to-split" statement in the database will be displayed.  
![Split statement entry point in dashboard](assets/split_statement_dashboard.png)
- in the **list of statements**, where users can choose which statement should be split next.  
![Split statement entry point in statement list](assets/statement_list_split.png)
