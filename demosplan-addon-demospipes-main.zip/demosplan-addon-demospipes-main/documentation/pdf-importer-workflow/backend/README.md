# PDF Importer in backend

Main task for backend in this workflow is keeping track of the changes in the status of the documents and communicating such events to frontend and PI for them to react accordingly.
Documents in backend are handled as **AnnotatedStatementPdf** entities which, at some point of the process will contain the pages in the doc as  **AnnotatedStatementPdfPage** entities.
**GenericApiController** has been extensively used to take care of queries, inserts and updates of such entities.

## 1. File upload

### 1.1. Show the form for the user to upload the PDF
@TODO rewrite this
**Route Information**
 - Controller: `DemosPlanAnnotatedStatementPdfController`
 - Route name: `dplan_statement_pdf_upload`
 - Permission:  `feature_import_statement_pdf`

### 1.2. Save uploaded PDF

**Route Information**
 - Controller: `GenericApiController`
 - Route name: `api_resource_create`
 - Permissions:  `feature_json_api_create`, `feature_import_statement_pdf`

**Actions**
 - Create new entity **AnnotatedStatementPdf** with status *pending*.
 - Communication with PI to request the **Box Recognition** for the uploaded document. 
    - Pipeline Id Parameter `pipeline.ai.annotated.statement.pdf.created.id`
    - Info sent:
	    - PDF File.
	    - Url to request back to, once the box recognition is over (*2.1*). 
	    - Url to request back to, if there was any error in the process (*2.2*)

**Note**: Check [Pi Communication](../../pi-communication/README.md) for more details.
 
## 2. Handle PI Request (Box Proposal)
### 2.1 On success
PI sends a list of PNG files, each one of them representing a page in the document. Each PNG comes with geoJson info  to place labeled boxes in the PNG and identify sections of info relevant for the Statement.

**Route Information**
 - Controller: `DemosPlanAnnotatedStatementPdfApiController`
 - Route name: `dplan_ai_api_annotation_statement_pdf_boxes_proposal`
 - Permission:  `feature_ai_create_annotated_statement_pdf_pages`

**Actions**
 - Convert the received PNG + geoJson into **AnnotatedStatementPdfPage** entities and add them to the **AnnotatedStatementPdf**.
 - Change the status of the **AnnotatedStatementPdf** to *ready_to_review*.

This change in the status will be used by frontend to allow the user to do the manual review process.
### 2.2 On error
**Route Information**
 - Controller: `DemosPlanAnnotatedStatementPdfApiController`
 - Route name: `dplan_ai_api_annotation_statement_pdf_boxes_proposal_error`
 - Permission:  `feature_ai_create_annotated_statement_pdf_pages`

**Actions**
 - Logs the error.
 - Checks how many errors there's previously been when processing the box recognition for this document (**boxRecognitionPiRetries** property in **AnnotatedStatementPfd**). If lower than what is set in config property **max_pi_retries** then increments **boxRecognitionPiRetries** and repeats the request to PI for a new attempt for box recognition. Otherwise, logs that this document couldn't be processed and gives up.

## 3. Handle Document review
### 3.1. Confirm a page
The pages in the document will be reviewed one by one, meaning the user needs to confirm a page before reviewing the next. 

**Route Information**
 - Controller: `GenericApiController`
 - Route name: `api_resource_update`
 - Permissions:  `feature_json_api_update`, `feature_import_statement_pdf`

**Actions**
 - Set the **AnnotatedStatementPdfPage** *confirmed* boolean field to true.
 - Check whether the document has more pages to be reviewed. If it does will do nothing else and FE will ask for the next page to be reviewed (*3.2*). Otherwise the whole document will be confirmed (*3.3*).

### 3.2. Next page to review
**Route Information**
 - Controller: `GenericApiController`
 - Route name: `api_resource_list`
 - Permissions:  `feature_json_api_list`, `feature_import_statement_pdf`

Using the **GenericApiController** and a filter to get an **AnnotatedStatementPdfPage** filtered by **AnnotatedStatementPdf** and *confirmed = false*, it will get the next page to be treated or null if no more.

### 3.3. Confirm the document
 **Route Information**
 - Controller: `GenericApiController`
 - Route name: `api_resource_update`
 - Permissions:  `feature_json_api_update`, `feature_import_statement_pdf`

**Actions**
 - Set the status of the document to *reviewed*.
 - Communication with PI to request the **Text Recognition** for the confirmed document.
    - Pipeline Id Parameter `pipeline.ai.annotated.statement.pdf.reviewed.id` 
    - Info sent:
	    - Reviewed info. 
	    - Url to request back to, once the text recognition is over (*4.1*). 
        - Url to request back to, if there was any error in the process (*4.2*).
        
**Note**: Check [Pi Communication](../../pi-communication/README.md) for more details.

## 4. Handle PI Request with text and submitter's info (Text proposal)
 ### 4.1 On Success
 **Route Information**
 - Controller: `DemosPlanAnnotatedStatementPdfApiController`
 - Route name: `dplan_ai_api_annotation_statement_pdf_text_proposal`
 - Permissions:  `feature_ai_create_annotated_statement_pdf_pages`

**Actions**
 - Updates text of **AnnotatedStatementPdf** and submitter's info.
 - Set the document status to *ready_to_confirm*.
 ### 4.2 On error
**Route Information**
 - Controller: `DemosPlanAnnotatedStatementPdfApiController`
 - Route name: `dplan_ai_api_annotation_statement_pdf_text_proposal_error`
 - Permission:  `feature_ai_create_annotated_statement_pdf_pages`

**Actions**
 - Logs the error.
 - Checks how many errors there's previously been when processing the text recognition for this document (**textRecognitionPiRetries**). If lower than what is set in config property **max_pi_retries** then increments **textRecognitionPiRetries** and repeats the request to PI for a new attempt for text recognition. Otherwise, logs that this document couldn't be processed and gives up.

## 5. Convert the AnnotatedStatementPdf into a Statement
### 5.1. Show form
 **Route Information**
 - Controller: `DemosPlanAnnotatedStatementPdfController`
 - Route name: `dplan_convert_annotated_pdf_to_statement`
 - Permissions:  `feature_import_statement_pdf`, `feature_statements_tag`
 
**Actions**
 - Prepares the info needed by frontend to show the form (a simplified version of the create manual statement form)
### 5.2. Submit the info
 **Route Information**
 - Controller: `DemosPlanPdfToStatementController`
 - Route name: `dplan_pdf_import_to_statement`
 - Permissions:  `feature_import_statement_pdf`
 
**Actions**
 - Uses the info in the **AnnotatedStatementPdf** to create a new **Statement**.
 - Sets the relationship between them (unidirectional **AnnotatedStatementPdf** => **Statement**).
 - Adds the PDF as an attachment in the **Statement**.
 - Sets the status of the **AnnotatedStatementPdf** to *converted*.
 - Communication with PI to notify a new Statement's creation and start the [Split Statement Workflow](../../split-statement-workflow/README.md).
