---
sidebarTitle: PDF Importer Workflow
---

# PDF Importer workflow
The PDF Import Workflow provides a way to convert PDFs into Statements. PI, Frontend and Backend communicate with each other and take care of different aspects:
* PI identifies relevant sections in the document which will be used to generate the Statement.
* Frontend provides tools for the Planners to review, modify and confirm such sections.
* Backend keeps track of the different statuses the documents go through in the workflow.

## Entry points
The entry points for the workflow are defined in two places:
- in **Procedure Overview** there is a new card with statistics and 3 buttons to jump into the right import-step. In this case the next "ready-to-edit" document in the database will be displayed.
![Pdf Importer entry point in dashboard](./assets/pdf_import_dashboard.png)
- in the list of uploaded files (first step of import), where each file has a link to the next step, so that the user can choose which file should be edited next.
![Pdf Importer entry point in uploaded list](./assets/uploaded-pdf-list.png)

## Phases in the Workflow
The document will go through 5 statuses until it's converted into a statement.

Step | Status after the step | Page in the interface
:---: | :---: | :---: |
Upload the PDF | Pending | Dateien hochladen (upload)
Box recognition | Ready to review | - 
Box check | Reviewed | Überprüfen (image annotator)
Text recognition | Ready to convert | -
Confirmation | Converted | Import bestätigen (convert PDF)

### Upload the PDF
In the **Procedure Overview** there is a link to get started with the process. This initial view provides the user with an interface to upload one or more documents. Once they upload it and submit the form, backend will store it and start the communication with PI for the next step. This is an asynchronous process so BE will just set the document in a _**Pending**_ status while PI is analysing it.
### Box recognition
Backend will send the document to PI so they can go through it and identify and label different sections. Once PI is done with the box recognition, they will send the labeled sections to BE where the info will be stored and the document's status changed to _**Ready to review**_.
### Box check
In the Procedure Overview the Planner can review the documents in such status. The review process consists of convenient Frontend tools with which the Planner can add, remove or modify the sections (labeled boxes in the document localising the areas where the relevant info is found). The user will confirm page by page their corrections until the whole document is reviewed. Once fully reviewed Backend will send the new sections info to PI for Text recognition. Also this is an asynchronous request and the Document will stay in _**Reviewed**_ status while PI is processing it.     
### Text recognition
PI will process the new info in order to generate the Statement's text and submitter details. When done Backend will be informed and the Document's status set to _**Ready to confirm**_ and can go to the last step.
### Confirmation
In the Confirmation step the planner will get a form with the info gathered during the process, together with the original Document so they can go through it and make any corrections if necessary. Once the form is submitted the new Statement will be created and the final status _**Confirmed**_ set. In this moment the next Workflow to split the statement into segment will take place.

## Debugging PDF import workflow locally    

PI can't access our local containers so the steps in the workflow that will ask PI for some process (that is Box and Text Recognition ) and expect some request back from them can not be debugged locally. However, connecting our container to Dev DB and following the next steps we will be able to test our local code for the rest of the workflow:
* Upload and save the PDF from Dev. 
Because we are connected to Dev DB, all changes in there will be visible for us locally, so in our local Overview, we will see this new document:

![Recently uploaded document shows as "In Verarbeitung (Boxen-Erkennung)"](./assets/box-recognition.png)

We will just wait for PI to send the Request with the results of the box recognition process and once refreshing the Overview we will see how it has been moved to "Bereit zu Überprüfung"

![Document ready to review](./assets/ready-to-review.png)

* Pages in the PDF can be reviewed locally (and therefore frontend and backend local code debugged) as long as we make sure to review the last one in Dev as it will be then when the communication with PI will take place.
* Confirm the PDF Review in Dev.

After that, both in dev and locally we will see the document moved to next status

![Document ready to confirm](./assets/text-recognition.png)

Again after PI sends the Request to Dev, the Overview will show the "Bereit für Bestätigung" status

![Recently reviewed document shows as "In Verarbeitung (Text-Erkennung)"](./assets/ready-to-confirm.png)

* Because the confirmation and final import of the Document doesn't need any communication with PI, this step can be fully done locally.

