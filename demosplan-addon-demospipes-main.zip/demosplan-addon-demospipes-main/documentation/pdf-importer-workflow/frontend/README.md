# PDF Importer in interface

There are three steps in the interface, in which users can interact with the PDF-Importer:
1. file upload
2. check of recognized sections
3. final text confirmation

## 1. File upload (Dateien hochladen)
**Template:** `administration_statement_upload.html.twig`  @TODO rewrite this
**Components:** `DpStatementPdfUpload` (with plupload), `DpUploadedStatementsList`  
**Tickets:** <Ticket>T18234</Ticket>  

![Pdf upload page](./assets/pdf_upload_page.png)

The page has two main elements: the upload area, where the user can select and upload pdfs (multiple at once) with plupload and the list of already uploaded pdfs, where the date of upload and current status are displayed. Each file that has not yet been converted into a statement links to its next edit step. 

Possible status icons:
- `fa-hourglass-half` - for status _pending_ and _reviewed_
- `fa-check-circle color--grey` - for status _ready_to_review_ and _ready_to_convert_
- `fa-check-circle color--grey` - for status _converted_

On file upload the list will automatically be updated to display new files as well. Beside that, the fetch request is fired every 5 seconds on `DpUploadedStatementsList` component mount to check for status updates.

**Improvements ideas:** 
- plupload should be replaced by a new upload library called uppy. FE part is already done, but to make it work BE also needs to be adjusted.

## 2. Recognized boxes check (Überprüfen)
**Template:** `administration_annotate.html.twig`  
**Components:** `DpImageAnnotator`, `DpLabelModal`  
**Tickets:** <Ticket>T18236</Ticket>, <Ticket>T17801</Ticket>, <Ticket>T18459</Ticket>    

![Pdf upload page](./assets/box_check_page.png)

In this view the areas of text in the pdf are displayed as boxes over each pdf page, and the user can modify the boxes so that their extent fits the actual content areas of the page.

On page load the first not-yet-confirmed page of the first not-confirmed PDF (BE decides) will be displayed. The check is performed page-by-page. 

After saving, either the next page of the document or the next document (if it was the last page) will be requested. If there are no further documents ready for box adjustment, the user will be redirected back to the dashboard.

The annotator is built with openlayers, as the data we receive from PI is stored in geoJSON format, with coordinates for each box (each box is a polygon). The pdf is rendered as a static image layer and its boundaries are used as an extent for the map view. This way it is impossible to pan the image out of the view. The boxes are rendered onto a vector layer. Each box has a different styling, depending on its label type. The labels and colors associated with them are defined in `parameters_default_project.yml`.

### Interactions
This view enables 3 kinds of changes: 
- modification of the existing box and its label
- box deletion
- addition of a new box.

There are 4 openlayers interactions in use: **select**, **modify**, **draw**, **snap**. The configuration of each interaction takes place in the `initInteractions` method and the logic for toggling interactions can be found in the `setInteraction` method. 

The user can toggle only between two: select and draw. Modify interaction is added to the map together with select, and receives the selected feature as a parameter, so that only one feature at a time can be edited. The same happens with the snap interaction (snapping makes it easier to grab the vertices of the  selected box). Interactions are bound to the vue component (this), to make it easier to remove/add them to the OL instance. 

There are also keyboard shortcuts to edit a selected feature: on `backspace` or `delete` the selected feature will be removed, on `escape` the selection will be reset. 

All changes to the features in openlayers have to be in sync with the geoJSON, as this is what will be sent back to server on save.

### Box modification
The biggest part of the component is the logic regarding box modification. As openlayers enable polygon modification without preserving shape, we have to take care of it and ensure, that on vertex-drag the box stays rectangular-shaped.

On vertex drag (`modifystart`) the function `applyFeatureUpdate` will be invoked. The function first checks, which coordinate pair was changed (a.k.a. which vertex was moved - each feature has 5 vertices, where 0 and 4th vertex coordinates are the same, because it is always a closed polygon. The check happens in the `getChangedCoordinates` function). Then, based on the position of the moved vertex, new coordinates for neighbouring vertices are calculated (`calculateSquaredCoordinates`), so that it stays rectangular. At the end we check, if the extent of the box after calculations is within the image extent and if so, the changes are applied to the feature. If it outside of the extent, the previous coordinates are used, as it is not allowed to drag a vertex outside of the image layer extent.

## 3. Text confirmation (Import bestätigen)
**Template:** `administration_convert_annotated_pdf.html.twig`  
**Components:** `DpConvertAnnotatedPdf`, `DpSimplifiedNewStatementForm`  
**Tickets:** <Ticket>T18914</Ticket>  

![Pdf upload page](./assets/confirm_page.png)

The view enables a final check of the data extracted by PI services, before the pdf will be converted to a statement in <demosplan/>. 

On the left, all pdf-pages are displayed, one after another, as images in a scrollable div. On the right, the statement form component is rendered. The component holds only the ewm-relevant fields and is also used on a new manual statement page. The form is pre-filled with data extracted by PI (for now only submitter data and statement text). All fields are editable, so that users can correct the input if there are any mistakes.

Both columns can be resized by dragging the resize handle situated between them.

On save a new statement will be created.
