<template>
  <div class="box-shadow-1 space-inset-m space-stack-s">
    <dp-loading v-if="isLoading" />
    <template v-else>
      <h4
        class="weight--bold"
        v-text="Translator.trans('import.statements.fromPdf')" />

      <template v-if="annotatedStatementPdfCount > 0">
        <p v-text="pdfInfoText" />
        <p
          v-if="manualReviewCount > 0"
          v-text="manualReviewCountText" />
        <dp-contextual-help
          class="float--right u-mt-0_125"
          :text="Translator.trans('statements.import.hint')">
        </dp-contextual-help>

        <table class="text--center">
          <tr class="font-size-large">
            <td class="c-chart__flow c-chart__flow-color-6-2 width-20p">{{ pendingCount }}</td>
            <td class="c-chart__flow c-chart__flow-color-6-3 width-20p">{{ readyToReviewCount }}</td>
            <td class="c-chart__flow c-chart__flow-color-6-4 width-20p">{{ reviewedCount }}</td>
            <td class="c-chart__flow c-chart__flow-color-6-5 width-20p">{{ readyToConvertCount }}</td>
            <td class="c-chart__flow c-chart__flow-color-6-6 width-20p color--white">{{ convertedCount }}</td>
          </tr>
          <tr class="u-valign--top">
            <td
              class="u-pt-0_25"
              v-text="Translator.trans('import.process.running')"/>
            <td
              class="u-pt-0_25"
              v-text="Translator.trans('import.process.ready.for.review')"/>
            <td
              class="u-pt-0_25"
              v-text="Translator.trans('import.process.generating.text')"/>
            <td
              class="u-pt-0_25"
              v-text="Translator.trans('import.process.ready.for.approval')"/>
            <td
              class="u-pt-0_25"
              v-text="Translator.trans('import.process.finished')"/>
          </tr>
        </table>

        <div class="flex flex-content-end space-inline-xs">
          <dp-button
            data-cy="filesUpload"
            :href="Routing.generate('DemosPlan_procedure_import', { procedureId: procedureId, _fragment: 'StatementPdfImport' })"
            :text="Translator.trans('files.upload')" />

          <dp-button
            :class="`${readyToReviewCount === 0 || nextAnnotatedStatementToReviewId === '' ? 'pointer-events-none opacity-7' : ''}`"
            data-cy="recheck"
            :disabled="!isPdfReadyToReview"
            :href="Routing.generate('dplan_annotated_statement_pdf_review', { procedureId: procedureId, documentId: nextAnnotatedStatementToReviewId })"
            :text="`${ Translator.trans('recheck') } (${ readyToReviewCount })`"
            variant="outline" />


          <dp-button
            :class="`${readyToConvertCount === 0 || nextAnnotatedStatementToConvertId === '' ? 'pointer-events-none opacity-7' : ''}`"
            data-cy="importConfirm"
            :href="Routing.generate('dplan_convert_annotated_pdf_to_statement', { procedureId: procedureId, documentId: nextAnnotatedStatementToConvertId })"
            :text="`${ Translator.trans('import.confirm') } (${ readyToConvertCount })`"
            variant="outline" />
        </div>
      </template>

      <template v-else>
        <p v-text="Translator.trans('statements.imported.none')" />
      </template>
    </template>
  </div>
</template>

<script>
import { dpApi } from '@demos-europe/demosplan-utils'
import { DpButton, DpContextualHelp, DpLoading }from '@demos-europe/demosplan-ui'

export default {
  name: 'StatementPdfImportStatusChart',

  components: {
    DpButton,
    DpContextualHelp,
    DpLoading
  },

  props: {
    procedureId: {
      type: String,
      required: true,
      default: ''
    }
  },

  data () {
    return {
      annotatedStatementPdfCount: 0,
      convertedCount: 0,
      isLoading: false,
      manualReviewCount: 0,
      nextAnnotatedStatementToReviewId: '',
      nextAnnotatedStatementToConvertId: '',
      pendingCount: 0,
      readyToConvertCount: 0,
      readyToReviewCount: 0,
      reviewedCount: 0
    }
  },

  methods: {
    fetchNextAnnotatedStatementData () {
      dpApi.get(Routing.generate('api_resource_list', { procedureId: this.procedureId, resourceType: 'AnnotatedStatementPdf' }))
        .then(response => {
          const objKeys = Object.keys(response.data.data)
          const responseObj = response.data.data

          /**
           * Use only the first id of a statement which has the status 'ready_to_review' or 'ready_to_convert'.
           */
          for (const key in objKeys) {
            if (responseObj[key].attributes.status === 'ready_to_review' && this.nextAnnotatedStatementToReviewId === '') {
                this.nextAnnotatedStatementToReviewId = responseObj[key].id
            }
            if (responseObj[key].attributes.status === 'ready_to_convert' && this.nextAnnotatedStatementToConvertId === '') {
                this.nextAnnotatedStatementToConvertId = responseObj[key].id
            }
          }
        })
    },

    fetchAnnotatedStatementData () {
      dpApi.get(Routing.generate('dplan_api_list_percentage_distribution'))
        .then(response => {
          const responseObject = response.data?.data[0]?.attributes || null

          if (!responseObject) {
            return
          }

          this.annotatedStatementPdfCount = responseObject.total || 0
          this.convertedCount = responseObject.absolutes.converted || 0
          this.manualReviewCount = responseObject.absolutes.reviewed || 0
          this.pendingCount = responseObject.absolutes.pending || 0
          this.readyToConvertCount = responseObject.absolutes.readyToConvert || 0
          this.readyToReviewCount = responseObject.absolutes.readyToReview || 0
          this.reviewedCount = responseObject.absolutes.reviewed || 0
        })
        .then(() => {
            this.fetchNextAnnotatedStatementData()
            if (this.pendingCount > 0 || this.reviewedCount > 0) {
                this.updateAnnotatedStatementData()
            }
        })
        .finally(() => {
            this.isLoading = false
        })
    },

    updateAnnotatedStatementData () {
      window.setTimeout(this.fetchAnnotatedStatementData, 5000)
    }
  },

  computed: {
    pdfInfoText () {
      return `${this.annotatedStatementPdfCount} ${this.annotatedStatementPdfCount === 1 ? Translator.trans('uploaded.file') : Translator.trans('uploaded.files')}`
    },

    manualReviewCountText () {
      return `${this.manualReviewCount === 1 ? this.manualReviewCount + ' ' + Translator.trans('file') : this.manualReviewCount + ' ' + Translator.trans('files')}` + ' ' + Translator.trans('processing')
    },

    isPdfReadyToReview () {
      return this.readyToConvertCount === 0
    }
  },

  mounted () {
    this.fetchAnnotatedStatementData()
  }
}
</script>

<style lang="scss">
.c-chart__flow {
  position: relative;
  height: $dp-space-16;

  &::after {
    content: ' ';
    position: absolute;
    z-index: 1;
    left: 100%;
    top: 0;

    border-color: transparent;
    border-width:
        $dp-space-8
        0
        $dp-space-8 20px;
    border-style: solid;
  }

  &:last-child::after {
    border: none;
  }

  &-color-6-1 {
    background-color: $dp-color-6-1;

    &::after {
      border-left-color: $dp-color-6-1;
    }
  }

  &-color-6-2 {
    background-color: $dp-color-6-2;

    &::after {
      border-left-color: $dp-color-6-2;
    }
  }

  &-color-6-3 {
    background-color: $dp-color-6-3;

    &::after {
      border-left-color: $dp-color-6-3;
    }
  }

  &-color-6-4 {
    background-color: $dp-color-6-4;

    &::after {
      border-left-color: $dp-color-6-4;
    }
  }

  &-color-6-5 {
    background-color: $dp-color-6-5;

    &::after {
      border-left-color: $dp-color-6-5;
    }
  }

  &-color-6-6 {
    background-color: $dp-color-6-6;

    &::after {
      border-left-color: $dp-color-6-6;
    }
  }
}
</style>
