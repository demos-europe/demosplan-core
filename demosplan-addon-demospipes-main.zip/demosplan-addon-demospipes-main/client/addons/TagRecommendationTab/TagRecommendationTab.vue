<license>
(c) 2010-present DEMOS plan GmbH.

This file is part of the package demosplan,
for more information see the license file.

All rights reserved
</license>

<template>
  <div>
    <div class="layout u-mb u-mt-0_5">
      <div class="layout__item u-1-of-3">
        <dp-label
          :text="Translator.trans('search.text')"
          for="searchField" />
        <dp-search-field
          @search="setSearchTerm"
          @reset="setSearchTerm('')"
          class="width--100p"
          :placeholder="Translator.trans('search')" />
      </div>
      <div class="layout__item u-1-of-3">
        <span class="display--block weight--bold">
          {{ Translator.trans('segment.tags') }}
        </span>
      <div class="bg-color--grey-light-2 u-p-0_25">
          <span
            :key="id"
            v-for="(id, idx) in tagIds">
            {{ getTagTitle(id, idx) }}
          </span>
        </div>
      </div>
    </div>

    <dp-loading v-if="isLoading" />

    <template v-else>
      <ul
        v-if="similarRecommendations.length > 0"
        class="o-list space-stack-m height-50vh overflow-auto">
        <dp-insertable-recommendation
          v-for="recommendation in similarRecommendations"
          :key="recommendation.id"
          class="o-list__item"
          :from-other-procedure="recommendation.fromOtherProcedure"
          :procedure-name="recommendation.procedureName"
          :recommendation="recommendation.attributes.recommendation"
          :search-term="searchTerm"
          @recommendation:insert="toggleInsert(recommendation.attributes.recommendation)" />
      </ul>
      <div
        v-else
        class="u-pt-0_5 border--top">
        {{ Translator.trans('statement.list.empty') }}
      </div>
    </template>
  </div>
</template>

<script>
import { dpApi, DpLabel, DpLoading, DpSearchField } from '@demos-europe/demosplan-ui'
import { mapMutations, mapState } from 'vuex'
import DpInsertableRecommendation from '../../components/DpInsertableRecommendation/DpInsertableRecommendation'

export default {
  name: 'TagRecommendationTab',

  components: {
    DpInsertableRecommendation,
    DpLabel,
    DpLoading,
    DpSearchField
  },

  // Array of procedureIds recommendations should be searched in.
  inject: ['recommendationProcedureIds'],

  props: {
    procedureId: {
      type: String,
      required: false,
      default: ''
    },

    segmentId: {
      type: String,
      required: true
    }
  },

  data () {
    return {
      isLoading: true,
      searchTerm: '',
      similarRecommendations: []
    }
  },

  computed: {
    ...mapState('statementSegment', {
      segments: 'items'
    }),

    ...mapState('tag', {
      tags: 'items'
    }),

    segment () {
      return this.segments[this.segmentId]
    },

    tagIds () {
      return this.segment.hasRelationship('tags')
        ? this.segment.relationships.tags.data.map(tag => tag.id)
        : []
    },

    tagTitles () {
      return this.segment.hasRelationship('tags')
        ? this.segment.relationships.tags.data.map(tag => this.tags[tag.id].attributes.title)
        : []
    }
  },

  methods: {
    ...mapMutations('statementSegment', ['setItem']),

    getRecommendationProcedureName (recommendation, included) {
      const recommendationProcedureId = this.getRecommendationProcedureId(recommendation, included)
      const procedure = included.find(item => item.id === recommendationProcedureId)

      return procedure.attributes.name
    },

    getRecommendationProcedureId (recommendation, included) {
      const parentStatementId = recommendation.relationships?.parentStatement.data?.id || null
      const parentStatement = included.find(item => item.id === parentStatementId)

      return parentStatement.relationships.procedure.data.id
    },

    getTagTitle (id, idx) {
      return (this.tags[id] && this.tags[id].attributes.title) + ((idx < this.tagIds.length - 1 && ',') || '')
    },

    isRecommendationFromOtherProcedure (recommendation, included) {
      const recommendationProcedureId = this.getRecommendationProcedureId(recommendation, included)

      return this.procedureId !== recommendationProcedureId
    },

    toggleInsert (recommendation) {
      this.$emit('recommendation:insert', recommendation)
      this.updateSegment(recommendation)
      this.toggleModal()
    },

    toggleModal () {
      if (!this.similarRecommendations) {
        this.fetchSimilarRecommendations()
      }
    },

    updateSegment (recommendation) {
      const payload = JSON.parse(JSON.stringify(this.segment))
      payload.attributes.recommendation = recommendation
      this.setItem({ ...payload, id: payload.id, group: null })
    },

    fetchSimilarRecommendations () {
      if (this.tagTitles.length <= 0) {
        return
      }

      this.isLoading = true

      const url = Routing.generate('api_resource_list', { resourceType: 'StatementSegment' })
      const params = {
        include: 'parentStatement,parentStatement.procedure',
        fields: {
          StatementSegment: [
            'id',
            'recommendation',
            'text',
            'externId',
            'internId',
            'orderInProcedure',
            'parentStatement'
          ].join(),
          Statement: [
            'procedure'
          ].join()
        },
        filter: {
          tags: {
            condition: {
              path: 'tags.title',
              value: this.tagTitles,
              operator: 'IN'
            }
          },
          notEmpty: {
            condition: {
              path: 'recommendation',
              value: '',
              operator: '<>'
            }
          },
          notSelf: {
            condition: {
              path: 'id',
              value: this.segmentId,
              operator: '<>'
            }
          },
          anyOfProcedures: {
            condition: {
              path: 'parentStatement.procedure.id',
              value: this.recommendationProcedureIds,
              operator: 'IN'
            }
          }
        }
      }

      return dpApi.get(url, params, { serialize: true })
        .then(({ data }) => {
          this.similarRecommendations = data.data.map(recommendation => {
            return {
              ...recommendation,
              fromOtherProcedure: this.isRecommendationFromOtherProcedure(recommendation, data.included),
              procedureName: this.getRecommendationProcedureName(recommendation, data.included)
            }
          })

          /*
           * Recommendations from the current procedure are more relevant to the user than recommendations from another procedure.
           * Therefore, we put all recommendations from the current procedure on top.
           */
          this.similarRecommendations.sort((a, b) => {
            if (a.fromOtherProcedure && b.fromOtherProcedure === false) {
              return 1
            }
            if (a.fromOtherProcedure === false && b.fromOtherProcedure) {
              return -1
            }

            return 0
          })

          const uniqueRecommendationsText = []
          const uniqueRecommendations = []

          this.similarRecommendations.forEach((obj) => {
            if (uniqueRecommendationsText.includes(obj.attributes.recommendation) === false) {
              uniqueRecommendations.push(obj)
              uniqueRecommendationsText.push(obj.attributes.recommendation)
            }
          })

          this.similarRecommendations = uniqueRecommendations
        })

        .catch((err) => {
          console.error(err)
        })

        .finally(() => {
          this.isLoading = false
        })
    },

    setSearchTerm (term) {
      this.searchTerm = term
    }
  },

  mounted () {
    this.fetchSimilarRecommendations()
  }
}
</script>
