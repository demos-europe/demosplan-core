<license>
  (c) 2010-present DEMOS E-Partizipation GmbH.

  This file is part of the package demosplan,
  for more information see the license file.

  All rights reserved
</license>

<template>
  <div class="segmentation-editor">
    <div id="editor" />
  </div>
</template>

<script>
import { DOMParser, DOMSerializer, Schema } from 'prosemirror-model'
import { addListNodes } from 'prosemirror-schema-list'
import { EditorState } from 'prosemirror-state'
import { EditorView } from 'prosemirror-view'
import { initRangePlugin } from '../../js/plugins'
import { schema } from 'prosemirror-schema-basic'
import { setRange } from '../../js/commands'
import { v4 as uuid } from 'uuid'

export default {
  name: 'SegmentationEditor',

  props: {
    editToggleCallback: {
      type: Function,
      required: false,
      default: () => ({})
    },

    initStatementText: {
      type: String,
      required: true
    },

    segments: {
      type: Array,
      required: true
    },

    rangeChangeCallback: {
      type: Function,
      required: false,
      default: () => ({})
    }
  },

  methods: {
    initialize () {
      const proseSchema = new Schema({
        nodes: addListNodes(schema.spec.nodes, 'paragraph block*', 'block'),
        marks: schema.spec.marks
      })
      const wrapper = document.createElement('div')
      wrapper.innerHTML = this.initStatementText
      const rangePlugin = initRangePlugin(proseSchema, this.rangeChangeCallback, this.editToggleCallback)
      const view = new EditorView(document.querySelector('#editor'), {
        editable: () => false,
        state: EditorState.create({
          doc: DOMParser.fromSchema(rangePlugin.schema).parse(wrapper),
          plugins: rangePlugin.plugins
        })
      })

      const transformedSegments = this.transformSegments(this.segments)
      transformedSegments.forEach(segment => setRange(view)(segment.from, segment.to, segment.attributes))

      const getContent = (schema) => (state) => {
        const container = document.createElement('div')
        const serialized = DOMSerializer.fromSchema(schema).serializeFragment(state.doc.content, { document: window.document }, container)
        return serialized.innerHTML
      }

      let prosemirrorStateWrapper = {
        view: view,
        keyAccess: rangePlugin.keys,
        getContent: getContent(proseSchema)
      }

      /**
       * We've put a wrapper around our prosemirror instance and freeze it afterwards to prevent Vue from watching
       * prosemirror internals. This would lead to a huge performance hit otherwise.
       */
      prosemirrorStateWrapper = Object.freeze(prosemirrorStateWrapper)

      this.$emit('prosemirror-initialized', prosemirrorStateWrapper)
    },

    transformSegments (segments) {
      const segmentsCpy = JSON.parse(JSON.stringify(segments))
      return segmentsCpy.map(segment => {
        return {
          attributes: {
            rangeId: segment.id,
            isConfirmed: segment.status === 'confirmed',
            pmId: uuid()
          },
          from: segment.charStart,
          to: segment.charEnd
        }
      })
    }
  },

  mounted () {
    this.initialize()
  }
}
</script>
