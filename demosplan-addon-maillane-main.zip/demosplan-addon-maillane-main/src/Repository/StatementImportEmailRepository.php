<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Repository;

use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class StatementImportEmailRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry, string $entityClass)
    {
        parent::__construct($registry, $entityClass);
    }

    /**
     * @param array<int, object> $entities
     *
     * @throws ORMException
     */
    public function persistEntities(array $entities): void
    {
        foreach ($entities as $entity) {
            $this->getEntityManager()->persist($entity);
        }
    }

    /**
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function flushEverything(): void
    {
        $this->getEntityManager()->flush();
    }

}
