<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Repository;

use DemosEurope\DemosplanAddon\Contracts\Entities\ProcedureInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Entity\MaillaneConnection;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\NoResultException;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Doctrine\Persistence\ManagerRegistry;
use InvalidArgumentException;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class MaillaneConnectionRepository extends ServiceEntityRepository
{
    private EntityManagerInterface $entityManager;

    private ValidatorInterface $validator;

    public function __construct(
        EntityManagerInterface $entityManager,
        ManagerRegistry $registry,
        string $entityClass,
        ValidatorInterface $validator
    ){
        $this->entityManager = $entityManager;
        $this->validator = $validator;
        parent::__construct($registry, $entityClass);
    }

    /**
     * Fetch procedure by Maillane account ID.
     *
     * @throws NoResultException
     */
    public function getProcedureByMaillaneAccountId(string $accountId): ProcedureInterface
    {
        $maillaneConnection = $this->findOneBy([
            'maillaneAccountId' => $accountId,
        ]);

        if (!$maillaneConnection instanceof MaillaneConnection) {
            throw new NoResultException();
        }

        return $maillaneConnection->getProcedure();
    }

    public function getMaillaneConnectionByProcedureId(string $procedureId): ?MaillaneConnection
    {
        return $this->findOneBy([
            'procedure' => $procedureId,
        ]);
    }

    /**
     * Create a MaillaneConnection with necessary properties
     * and validate it.
     *
     * @throws InvalidArgumentException
     */
    public function createMaillaneConnection(
        ?string $maillaneAccountId,
        string $recipientMailAddress,
        ProcedureInterface $procedure
    ): MaillaneConnection {
        $maillaneConnection = new MaillaneConnection($procedure);
        $maillaneConnection->setMaillaneAccountId($maillaneAccountId);
        $maillaneConnection->setRecipientEmailAddress($recipientMailAddress);

        $this->validator->validate($maillaneConnection);

        return $maillaneConnection;
    }

    public function persist(MaillaneConnection $maillaneConnection)
    {
        $this->entityManager->persist($maillaneConnection);
    }

    /**
     * @param array<int, object> $entities
     *
     * @throws ORMException
     */
    public function persistEntities(array $entities): void
    {
        foreach ($entities as $entity) {
            $this->getEntityManager()->persist($entity);
        }
    }

    /**
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function flushEverything(): void
    {
        $this->getEntityManager()->flush();
    }
}
