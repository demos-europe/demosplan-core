<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\ResourceType;

use Carbon\Carbon;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\UserResourceTypeInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\OriginalStatementResourceTypeInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\AddonResourceType;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\ProcedureResourceTypeInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Configuration\Permissions\Features;
use EDT\PathBuilding\End;
use EDT\Querying\Contracts\FunctionInterface;
use Parsedown;
use DemosEurope\DemosplanAddon\DemosMaillane\Entity\StatementImportEmail;

/**
 * @property-read End                                       $creationDate
 * @property-read ProcedureResourceTypeInterface            $procedure
 * @property-read UserResourceTypeInterface                 $forwardingUser
 * @property-read End                                       $forwarderEmailAddress
 * @property-read End                                       $from
 * @property-read End                                       $subject
 * @property-read End                                       $plainTextContent
 * @property-read End                                       $htmlTextContent
 * @property-read End                                       $rawEmailText
 * @property-read OriginalStatementResourceTypeInterface    $createdStatements
 */
class StatementImportEmailResourceType extends AddonResourceType
{
    public static function getName(): string
    {
        return 'StatementImportEmail';
    }

    public function getEntityClass(): string
    {
        return StatementImportEmail::class;
    }

    public function isAvailable(): bool
    {
        return $this->permissionEvaluator->isPermissionEnabled('area_admin_import')
            || $this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_via_email());
    }

    public function isReferencable(): bool
    {
        return false;
    }

    public function isDirectlyAccessible(): bool
    {
        return true;
    }

    public function getAccessCondition(): FunctionInterface
    {
        $procedure = $this->currentContextProvider->getCurrentProcedure();
        if (null === $procedure) {
            return $this->conditionFactory->false();
        }

        return $this->conditionFactory->propertyHasValue(
            $procedure->getId(),
            $this->procedure->id
        );
    }

    protected function getProperties(): array
    {
        return [
            $this->createAttribute($this->id)->readable(true)->filterable(),
            $this->createAttribute($this->creationDate)->readable(
                false,
                function (StatementImportEmail $email): ?string {
                    return $email->getCreationDate() !== null ? Carbon::instance($email->getCreationDate())->toIso8601String() : null;
                }
            ),
            $this->createToOneRelationship($this->forwardingUser)->readable(),
            $this->createAttribute($this->subject)->readable(),
            $this->createAttribute($this->from)->readable(),
            $this->createAttribute($this->plainTextContent)->readable(false, static function(StatementImportEmail $statementImportEmail): string {
                return (new Parsedown())->text($statementImportEmail->getPlainTextContent());
            }),
            $this->createAttribute($this->htmlTextContent)->readable(),
            $this->createToManyRelationship($this->createdStatements)->readable(),
            $this->createAttribute($this->forwarderEmailAddress),
            $this->createAttribute($this->rawEmailText),
        ];
    }

    public function isExposedAsPrimaryResource(): bool
    {
        return $this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_via_email())
            || $this->permissionEvaluator->isPermissionEnabled('area_admin_import');
    }
}
