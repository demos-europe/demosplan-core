<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\ResourceType;

use DemosEurope\DemosplanAddon\Contracts\Config\GlobalConfigInterface;
use DemosEurope\DemosplanAddon\Contracts\CurrentContextProviderInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\EmailAddressInterface;
use DemosEurope\DemosplanAddon\Contracts\MessageBagInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\AddonResourceType;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\CreatableDqlResourceTypeInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\ProcedureResourceTypeInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\ResourceTypeServiceInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\UpdatableDqlResourceTypeInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosMaillane\Entity\MaillaneConnection;
use DemosEurope\DemosplanAddon\DemosMaillane\Logic\MaillaneSynchronizer;
use DemosEurope\DemosplanAddon\Logic\ResourceChange;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use EDT\ConditionFactory\ConditionFactoryInterface;
use EDT\PathBuilding\End;
use EDT\Querying\Contracts\PathsBasedInterface;
use EDT\Wrapping\Contracts\TypeProviderInterface;
use EDT\Wrapping\WrapperFactories\WrapperObjectFactory;
use Exception;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @property-read End                               $recipientEmailAddress
 * @property-read End                               $allowedSenderEmailAddresses
 * @property-read ProcedureResourceTypeInterface    $procedure
 */
class MaillaneConnectionResourceType extends AddonResourceType implements UpdatableDqlResourceTypeInterface, CreatableDqlResourceTypeInterface
{
    /**
     * @var MaillaneSynchronizer
     */
    private $maillaneSynchronizer;

    public function __construct(
        MaillaneSynchronizer $maillaneSynchronizer,
        PermissionEvaluatorInterface    $permissionEvaluator,
        TypeProviderInterface           $typeProvider,
        CurrentContextProviderInterface $currentContextProvider,
        GlobalConfigInterface           $globalConfig,
        LoggerInterface                 $logger,
        MessageBagInterface             $messageBag,
        ResourceTypeServiceInterface    $resourceTypeService,
        TranslatorInterface             $translator,
        ConditionFactoryInterface       $conditionFactory,
        WrapperObjectFactory            $wrapperFactory,
        ContainerInterface              $container
    ) {
        parent::__construct(
            $permissionEvaluator,
            $typeProvider,
            $currentContextProvider,
            $globalConfig,
            $logger,
            $messageBag,
            $resourceTypeService,
            $translator,
            $conditionFactory,
            $wrapperFactory,
            $container
        );
        $this->maillaneSynchronizer = $maillaneSynchronizer;
    }

    protected function getProperties(): array
    {
        $procedure = $this->createToOneRelationship($this->procedure);
        $allowedSenderEmailAddresses = $this->createAttribute($this->allowedSenderEmailAddresses)
            ->readable(false, function (MaillaneConnection $connection): ?array {
                return $connection->getAllowedSenderEmailAddresses()
                    ->map(static function (EmailAddressInterface $address): string {
                        return $address->getFullAddress();
                    })
                    ->toArray();
            });

        if ($this->permissionEvaluator->isPermissionEnabled(Features::field_import_statement_email_addresses())) {
            $allowedSenderEmailAddresses->initializable(true);
            $procedure->filterable();
        }

        return [
            $this->createAttribute($this->id)->readable(true),
            $this->createAttribute($this->recipientEmailAddress)->readable(),
            $allowedSenderEmailAddresses,
            $procedure,
        ];
    }

    public static function getName(): string
    {
        return 'MaillaneConnection';
    }

    public function getEntityClass(): string
    {
        return MaillaneConnection::class;
    }

    public function isAvailable(): bool
    {
        return $this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_via_email())
            || $this->permissionEvaluator->isPermissionEnabled('area_admin_import');
    }

    public function isDirectlyAccessible(): bool
    {
        return $this->isAvailable();
    }

    public function isExposedAsPrimaryResource(): bool
    {
        return $this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_via_email())
            || $this->permissionEvaluator->isPermissionEnabled('area_admin_import');
    }

    public function getAccessCondition(): PathsBasedInterface
    {
        $currentProcedure = $this->currentContextProvider->getCurrentProcedure();
        if (null === $currentProcedure) {
            return $this->conditionFactory->false();
        }

        return $this->conditionFactory->propertyHasValue(
            $currentProcedure->getId(),
            ['procedure', 'id']
        );
    }

    /**
     * @param MaillaneConnection $object
     */
    public function updateObject(object $object, array $properties): ResourceChange
    {
        $pathString = $this->allowedSenderEmailAddresses->getAsNamesInDotNotation();
        if (array_key_exists($pathString, $properties)) {
            $newAllowedSenderEmailAddresses = $properties[$pathString];
            $this->maillaneSynchronizer->editAccount($object, $newAllowedSenderEmailAddresses);
        }
        return new ResourceChange($object, $this, $properties);
    }


    public function getUpdatableProperties(object $updateTarget): array
    {
        $properties = [];

        if ($this->permissionEvaluator->isPermissionEnabled(Features::field_import_statement_email_addresses())) {
            $properties[] = $this->allowedSenderEmailAddresses;
        }

        return $this->toProperties(...$properties);
    }

    public function isCreatable(): bool
    {
        return null !== $this->currentContextProvider->getCurrentProcedure();
    }

    /**
     * @throws Exception
     */
    public function createObject(array $properties): ResourceChange
    {
        $procedure = $this->currentContextProvider->getCurrentProcedure();
        if (null === $procedure) {
            throw new Exception("Procedure was not found.");
        }

        $accountEmail = $this->maillaneSynchronizer->generateRecipientMailAddress(
            $procedure->getName()
        );
        $connection = $this->maillaneSynchronizer->createAccount($accountEmail, $procedure);

        $pathString = $this->allowedSenderEmailAddresses->getAsNamesInDotNotation();
        if (array_key_exists($pathString, $properties)) {
            $newAllowedSenderEmailAddresses = $properties[$pathString];
            $this->maillaneSynchronizer->editAccount($connection, $newAllowedSenderEmailAddresses);
        }

        $change = new ResourceChange($connection, $this, $properties);
        $change->addEntityToPersist($connection);
        $change->setUnrequestedChangesToTargetResource();

        return $change;
    }
}
