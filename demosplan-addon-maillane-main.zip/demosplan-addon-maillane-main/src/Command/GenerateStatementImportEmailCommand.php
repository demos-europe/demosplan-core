<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Command;

use DemosEurope\DemosplanAddon\Contracts\Entities\ProcedureInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Entity\StatementImportEmail;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ManagerRegistry;
use Doctrine\Persistence\ObjectManager;
use Exception;
use Faker\Factory;
use Faker\Generator;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

class GenerateStatementImportEmailCommand extends Command
{
    protected static $defaultName = 'dplan:data:generate:statement-import-email';

    protected static $defaultDescription = 'Generate a (number of) Statement-Import-Email(s)';

    protected Generator $faker;

    protected ObjectManager $em;

    private \Parsedown $parsedown;

    private EntityManagerInterface $entityManager;

    protected InputInterface $input;

    protected SymfonyStyle $output;

    private ?string $name;

    public function __construct(
        EntityManagerInterface  $entityManager,
        ManagerRegistry         $registry,
        string                  $name = null
    )
    {
        parent::__construct($name);

        $this->em               = $registry->getManager();
        $this->faker            = Factory::create('de_DE');
        $this->parsedown        = new \Parsedown();
        $this->entityManager    = $entityManager;
        $this->name             = $name;
    }

    protected function configure(): void
    {
        $this->addArgument(
            'procedure',
            InputArgument::REQUIRED,
            'The ID of the procedure into which to generate the e-mails.'
        );

        $this->addArgument(
            'senderEmailAddress',
            InputArgument::OPTIONAL,
            'The email address of the sender.',
            'testing@demos-plan.de'
        );

        $this->addArgument(
            'amount',
            InputArgument::OPTIONAL,
            'The amount of e-mails to be generated.',
            1
        );
    }

    protected function handle(InputInterface $input,SymfonyStyle $output): int
    {
        $amount = $input->getArgument('amount');

        $procedureId = $input->getArgument($this->name);
        $procedureRepository = $this->em->getRepository(ProcedureInterface::class);
        $procedure = $procedureRepository->find($procedureId);

        $senderEmailAddress = $input->getArgument('senderEmailAddress');

        try {
            $progressBar = $this->createGeneratorProgressBar($amount);
            $progressBar->setMessage('Generating statement-import e-mails...');

            for ($i = 0; $i < $amount; ++$i) {
                $this->createStatementImportEmailData($senderEmailAddress, $procedure);
                $progressBar->advance();
            }
            $this->entityManager->flush();
            $progressBar->finish();
        } catch (Exception $e) {
            $output->writeln(sprintf("<error>{$e}</error>"));

            return 2;
        }

        return 0;
    }

    /**
     * Creates and persists a single statementImportEmail with random content
     */
    private function createStatementImportEmailData(string $senderEmailAddress, ProcedureInterface $procedure): void
    {
        $subject = $this->faker->sentence();
        $text = $this->faker->text();

        $statementImportEmail = new StatementImportEmail();
        $statementImportEmail->setProcedure($procedure);
        $statementImportEmail->setSubject($subject);
        $statementImportEmail->setHtmlTextContent($this->parsedown->parse($text));
        $statementImportEmail->setPlainTextContent($text);
        $statementImportEmail->setRawEmailText($text);
        $statementImportEmail->setFrom($senderEmailAddress);

        $this->entityManager->persist($statementImportEmail);
    }

    /**
     * @param int $amount
     */
    protected function createGeneratorProgressBar($amount, SymfonyStyle $output): ProgressBar
    {
        $progressBar = new ProgressBar($output, $amount);

        $format = '[#%current%/%max%] %bar% (Elapsed: %elapsed%, Estimated: %estimated%)';
        if ($amount > 1) {
            $format = "%message%\n".$format;
        }

        $progressBar->setFormat($format);

        return $progressBar;
    }
}
