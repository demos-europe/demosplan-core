<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Logic;

use DemosEurope\DemosplanAddon\Contracts\Entities\FileInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\ProcedureInterface;
use DemosEurope\DemosplanAddon\Contracts\FileServiceInterface;
use DemosEurope\DemosplanAddon\Contracts\Services\UserServiceInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Entity\StatementImportEmail;
use DemosEurope\DemosplanAddon\DemosMaillane\Repository\MaillaneConnectionRepository;
use DemosEurope\DemosplanAddon\Exception\JsonException;
use DemosEurope\DemosplanAddon\DemosMaillane\Logic\Http\JsonApiClient;
use DemosEurope\DemosplanAddon\Utilities\Json;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\ORMException;
use Doctrine\ORM\OptimisticLockException;
use EDT\JsonApi\Schema\ContentField;
use Psr\Log\LoggerInterface;
use RuntimeException;
use Symfony\Component\Filesystem\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Mime\Address;
use Symfony\Component\Mime\MimeTypes;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\HttpExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;
use Throwable;

/**
 * Handles everything related to fetching mails from Maillane.
 */
class MailFetcher
{
    /**
     * @var FileServiceInterface
     */
    private $fileService;

    /**
     * @var MaillaneConnectionRepository
     */
    private $maillaneConnectionRepository;

    /**
     * @var UserServiceInterface
     */
    private $userService;

    /**
     * @var UrlGeneratorInterface
     */
    private $router;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var JsonApiClient
     */
    private $jsonApiClient;



    public function __construct(
        FileServiceInterface         $fileService,
        LoggerInterface              $logger,
        MaillaneConnectionRepository $maillaneConnectionRepository,
        UrlGeneratorInterface        $router,
        UserServiceInterface         $userService,
        JsonApiClient                $jsonApiClient
    )
    {
        $this->fileService                  = $fileService;
        $this->maillaneConnectionRepository = $maillaneConnectionRepository;
        $this->userService                  = $userService;
        $this->router                       = $router;
        $this->logger                       = $logger;
        $this->jsonApiClient                = $jsonApiClient;
    }

    /**
     * Tries to fetch the individual emails from Maillane based on the urls sent by Maillane.
     *
     * @param array<int, string[]> $availableMails
     * @throws ORMException
     * @throws OptimisticLockException
     * @throws HttpExceptionInterface
     * @throws TransportExceptionInterface
     * @throws JsonException|Throwable
     */
    public function fetchMailsForAccount(array $availableMails, ProcedureInterface $procedure): void
    {
        foreach ($availableMails as $mailInfo) {
            $url = $mailInfo[ContentField::ATTRIBUTES]['url'];
            $mailResponse = $this->jsonApiClient->apiRequest(Request::METHOD_GET, $url, []);
            $decodedBody = Json::decodeToArray($mailResponse->getContent());
            $content = $decodedBody[ContentField::DATA][ContentField::ATTRIBUTES];

            // save mail as StatementImportEmail
            $statementImportEmail = $this->createStatementImportEmail($content, $procedure, $url);
            $this->maillaneConnectionRepository->persistEntities([$statementImportEmail]);
            $this->maillaneConnectionRepository->flushEverything();
            // delete fetched mails to keep Maillane clean
            $this->jsonApiClient->apiRequest(Request::METHOD_DELETE, $url, []);
        }
    }

    /**
     * Creates a StatementImportEmail with the data from Maillane.
     *
     * @param array<int, mixed> $content
     * @throws JsonException
     * @throws TransportExceptionInterface
     * @throws HttpExceptionInterface
     * @throws Throwable
     * @throws FileNotFoundException
     */
    private function createStatementImportEmail(
        array              $content,
        ProcedureInterface $procedure,
        string             $url
    ): StatementImportEmail
    {
        $statementImportEmail = new StatementImportEmail();
        $statementImportEmail->setProcedure($procedure);
        $statementImportEmail->setSubject($content['headers']['Subject']);
        $statementImportEmail->setHtmlTextContent($content['html_content'] ?? '');
        $statementImportEmail->setPlainTextContent($content['text_content'] ?? '');
        $statementImportEmail->setRawEmailText($content['raw'] ?? '');

        $statementImportEmail->setFrom('-');
        if (array_key_exists('From', $content['headers'])) {
            $from = $content['headers']['From'];
            $statementImportEmail->setFrom($from);

            // Check if we can match a user based on the sender mail address
            $mimeAddress = Address::create($from);
            $user = $this->userService->findDistinctUserByEmailOrLogin($mimeAddress->getAddress());
            if ($user instanceof UserInterface) {
                $statementImportEmail->setForwardingUser($user);
            }
        }

        // Fetch all attachments, save them and add them to the statementImportEmail
        $attachmentFiles = $this->collectAttachments($content['attachment_urls'], basename($url), $procedure);
        $statementImportEmail->setAttachments(new ArrayCollection($attachmentFiles));
        $this->removeImgTagsFromHtmlContent($statementImportEmail);

        return $statementImportEmail;
    }

    /**
     * Download and save attachments as temporary files
     *
     * @param array<int, string> $attachmentUrls
     * @return FileInterface[]
     * @throws JsonException
     * @throws Throwable
     * @throws TransportExceptionInterface
     * @throws ClientExceptionInterface
     * @throws RedirectionExceptionInterface
     * @throws ServerExceptionInterface
     * @see FileInterface.
     *
     */
    private function collectAttachments(array $attachmentUrls, string $mailId, ProcedureInterface $procedure): array
    {
        $attachmentFiles = [];
        foreach ($attachmentUrls as $attachmentUrl) {
            $attachmentResponse = $this->jsonApiClient->apiRequest(
                Request::METHOD_GET,
                $attachmentUrl,
                []
            );
            $this->jsonApiClient->verifyApiResponse($attachmentResponse, [Response::HTTP_OK]);
            $attachmentHeaders = $attachmentResponse->getHeaders();

            $mimeTypes = new MimeTypes();
            $fileExtension = $mimeTypes->getExtensions(
                $attachmentHeaders['content-type'][0]
            );
            $basename = uniqid($mailId, true) . '.' . $fileExtension[0];
            $tempDir = sys_get_temp_dir();
            if (!is_dir($tempDir)) {
                throw new RuntimeException('Could not determine temporary directory');
            }
            $path = $tempDir . DIRECTORY_SEPARATOR . $basename;

            file_put_contents($path, $attachmentResponse->getContent());
            $data = $this->fileService->saveTemporaryFile(
                $path,
                $basename,
                null,
                $procedure->getId(),
            );

            $newFile = $this->fileService->getFileById($data->getId());
            if (null === $newFile) {
                throw new FileNotFoundException('Attachment from Maillane could not be saved.');
            }

            $attachmentFiles[] = $newFile;
        }

        return $attachmentFiles;
    }

    /**
     * This method removes img tags from the html content of a mail
     */
    private function removeImgTagsFromHtmlContent(StatementImportEmail $statementImportEmail): void
    {
        $htmlContent = $statementImportEmail->getHtmlTextContent();
        if ('' === $htmlContent) {
            return;
        }

        $htmlContent = preg_replace('/<img[^>]+>/', '', $htmlContent);

        $statementImportEmail->setHtmlTextContent($htmlContent);
    }
}
