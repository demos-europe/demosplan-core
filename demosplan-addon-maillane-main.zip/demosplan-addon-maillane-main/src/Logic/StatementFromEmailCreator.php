<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Logic;

use DemosEurope\DemosplanAddon\Contracts\StatementCreatorInterface;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosMaillane\ResourceType\StatementImportEmailResourceType;
use Exception;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\RouterInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\StatementInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Entity\StatementImportEmail;
use EDT\JsonApi\RequestHandling\EntityFetcherInterface;
use DemosEurope\DemosplanAddon\Contracts\FileUploadServiceInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Repository\StatementImportEmailRepository;
use DemosEurope\DemosplanAddon\Contracts\Handler\StatementHandlerInterface;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class StatementFromEmailCreator implements StatementCreatorInterface
{
    protected const PARAM_PROCEDURE_ID = 'procedureId';
    protected const PARAM_STATEMENT = 'statement';
    private const STATEMENT_IMPORT_EMAIL_ID_URL_PARAM = 'StatementImportEmailId';
    private const STATEMENT_IMPORT_EMAIL_ID_POST = 'r_statement_import_email_id';

    private EntityFetcherInterface $entityFetcher;

    private StatementImportEmailResourceType $statementImportEmailResourceType;

    private StatementImportEmailRepository $emailRepository;

    private FileUploadServiceInterface $fileUploadService;

    private StatementHandlerInterface $statementHandler;

    private RouterInterface $router;

    private PermissionEvaluatorInterface $permissionEvaluator;

    public function __construct(
        EntityFetcherInterface              $entityFetcher,
        FileUploadServiceInterface          $fileUploadService,
        RouterInterface                     $router,
        StatementHandlerInterface           $statementHandler,
        StatementImportEmailRepository      $emailRepository,
        StatementImportEmailResourceType    $statementImportEmailResourceType,
        PermissionEvaluatorInterface        $permissionEvaluator
    ) {
        $this->entityFetcher                    = $entityFetcher;
        $this->statementImportEmailResourceType = $statementImportEmailResourceType;
        $this->emailRepository                  = $emailRepository;
        $this->fileUploadService                = $fileUploadService;
        $this->statementHandler                 = $statementHandler;
        $this->router                           = $router;
        $this->permissionEvaluator              = $permissionEvaluator;
    }

    /**
     * Starts statement creation
     */
    public function __invoke(
        Request $request,
        string $procedureId
    ): Response {
        $rParams = $request->request->all();
        $fileUpload = $this->getFileUpload($request);
        if (null !== $fileUpload) {
            $rParams['fileupload'] = $fileUpload;
        }
        $originalFileUpload = $this->getOriginalFileUpload($request);
        if (null !== $originalFileUpload) {
            $rParams['originalAttachments'] = [$originalFileUpload];
        }
        if (array_key_exists('r_tags', $rParams) && is_array($rParams['r_tags'])) {
            $rParams['r_recommendation'] = $this->statementHandler->addBoilerplatesOfTags(
                $rParams['r_tags']
            );
        }
        $statement = $this->statementHandler->newStatement(
            $rParams,
            $this->permissionEvaluator->isPermissionEnabled('feature_statement_data_input_orga')
        );
        $this->handleCreatedStatement($request, $statement);

        return $this->redirectResponse(
            $request,
            [
                self::PARAM_PROCEDURE_ID => $procedureId,
                self::PARAM_STATEMENT    => $statement,
            ]
        );
    }

    /**
     * @return mixed|null
     *
     * @throws Exception
     */
    protected function getOriginalFileUpload(Request $request)
    {
        $fParams = $this
            ->fileUploadService
            ->prepareFilesUpload($request, 'r_attachment_original');
        if (null !== $fParams && '' !== $fParams) {
            return $fParams;
        }

        return null;
    }

    /**.
     *
     * @return mixed
     *
     * @throws Exception
     */
    protected function getFileUpload(Request $request)
    {
        $fParams = $this->fileUploadService->prepareFilesUpload($request, 'r_upload');
        if (null !== $fParams && '' !== $fParams) {
            return $fParams;
        }

        return null;
    }

    /**
     * @throws AccessDeniedException if the method would return true but permissions are missing
     */
    public function isImportingStatementViaEmail(Request $request): bool
    {
        if ($request->query->has(self::STATEMENT_IMPORT_EMAIL_ID_URL_PARAM) ||
            $request->request->has(self::STATEMENT_IMPORT_EMAIL_ID_POST)) {
            if (!$this->permissionEvaluator->isPermissionEnabled('area_admin_import')
                && !$this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_via_email())
            ) {
                throw new AccessDeniedException('Der Zugriff ist nicht gestattet');
            }

            return true;
        }

        return false;
    }

    public function getStatementImportEmail(Request $request): StatementImportEmail
    {
        $emailId = $request->query->get(self::STATEMENT_IMPORT_EMAIL_ID_URL_PARAM);
        if (null === $emailId) {
            $emailId = $request->request->get(self::STATEMENT_IMPORT_EMAIL_ID_POST);
        }

        return $this->entityFetcher->getEntityAsReadTarget(
            $this->statementImportEmailResourceType,
            $emailId
        );
    }

    protected function handleCreatedStatement(Request $request, StatementInterface $originalStatement): void
    {
        $email = $this->getStatementImportEmail($request);
        $email->getCreatedStatements()->add($originalStatement);

        $this->emailRepository->persistEntities([$email]);
        $this->emailRepository->flushEverything();
    }

    protected function redirectResponse(Request $request, array $params): RedirectResponse
    {
        return new RedirectResponse(
            $this->router->generate(
                'DemosPlan_procedure_import',
                ['procedureId' => $params[self::PARAM_PROCEDURE_ID]]
            )
        );
    }
}
