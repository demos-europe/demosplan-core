<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\EventSubscriber;

use DemosEurope\DemosplanAddon\Contracts\Events\IsOriginalStatementAvailableEventInterface;
use DemosEurope\DemosplanAddon\Contracts\Services\CurrentUserProviderInterface;
use EDT\JsonApi\ResourceTypes\RelationshipBuilder;
use EDT\Querying\Contracts\PathException;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\GetPropertiesEventInterface;
use DemosEurope\DemosplanAddon\Contracts\ResourceType\OriginalStatementResourceTypeInterface;
use Symfony\Component\Security\Core\Exception\UserNotFoundException;

class OriginalStatementResourceTypeSubscriber implements EventSubscriberInterface
{
    private CurrentUserProviderInterface $currentUser;

    public function __construct(CurrentUserProviderInterface $currentUser)
    {
        $this->currentUser = $currentUser;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            IsOriginalStatementAvailableEventInterface::class   => 'isOriginalStatementAvailable',
            GetPropertiesEventInterface::class                  => 'getOriginalStatementProperties',
        ];
    }

    public function isOriginalStatementAvailable(IsOriginalStatementAvailableEventInterface $event)
    {
        if ($this->currentUser->hasPermission('feature_import_statement_via_email')) {
            $event->setIsOriginalStatementAvailable(true);
        }
    }

    /**
     * @throws PathException
     * @throws UserNotFoundException
     */
    public function getOriginalStatementProperties(GetPropertiesEventInterface $event): void
    {
        $resourceType = $event->getType();
        if (!$resourceType instanceof OriginalStatementResourceTypeInterface) {
            return;
        }

        if ($this->currentUser->hasPermission('feature_import_statement_via_email')) {
            $property = (new RelationshipBuilder(
                $resourceType->statements,
                $resourceType->getEntityClass(),
                false
            ))->readable()->aliasedPath($resourceType->statementsCreatedFromOriginal);
            $event->addProperty($property);
        }
    }
}
