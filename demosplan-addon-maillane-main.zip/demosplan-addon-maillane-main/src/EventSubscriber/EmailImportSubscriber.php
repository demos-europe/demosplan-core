<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\EventSubscriber;

use DemosEurope\DemosplanAddon\Contracts\Events\CreateSimplifiedStatementEventInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Logic\StatementFromEmailCreator;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class EmailImportSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private readonly StatementFromEmailCreator $statementFromEmailCreator
    ) {}

    public static function getSubscribedEvents(): array
    {
        return [
            CreateSimplifiedStatementEventInterface::class => 'importingStatementViaEmail',
        ];
    }

    public function importingStatementViaEmail(CreateSimplifiedStatementEventInterface $event)
    {
        $request = $event->getRequest();
        if ($this->statementFromEmailCreator->isImportingStatementViaEmail($request)) {
            $event->setStatementFromEmailCreator($this->statementFromEmailCreator);
        }
    }
}
