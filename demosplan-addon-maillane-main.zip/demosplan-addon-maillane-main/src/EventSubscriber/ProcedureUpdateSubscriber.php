<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\EventSubscriber;

use DemosEurope\DemosplanAddon\Contracts\Entities\ProcedureInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\PostNewProcedureCreatedEventInterface;
use DemosEurope\DemosplanAddon\Contracts\Events\PostProcedureDeletedEventInterface;
use DemosEurope\DemosplanAddon\Contracts\MessageBagInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Configuration\Permissions\Features;
use DemosEurope\DemosplanAddon\DemosMaillane\Exception\MaillaneApiException;
use DemosEurope\DemosplanAddon\DemosMaillane\Logic\MaillaneSynchronizer;
use DemosEurope\DemosplanAddon\DemosMaillane\Repository\MaillaneConnectionRepository;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use Doctrine\ORM\EntityManagerInterface;
use InvalidArgumentException;
use Psr\Log\LoggerInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Throwable;

class ProcedureUpdateSubscriber implements EventSubscriberInterface
{
    /**
     * @var PermissionEvaluatorInterface
     */
    private $permissionEvaluator;

    /**
     * @var MaillaneSynchronizer
     */
    private $maillaneSynchronizer;

    /**
     * @var MessageBagInterface
     */
    private $messageBag;

    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * @var MaillaneConnectionRepository
     */
    private $maillaneConnectionRepository;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    public function __construct(
        EntityManagerInterface          $entityManager,
        MaillaneConnectionRepository    $maillaneConnectionRepository,
        MaillaneSynchronizer            $maillaneSynchronizer,
        MessageBagInterface             $messageBag,
        PermissionEvaluatorInterface    $permissionEvaluator,
        LoggerInterface                 $logger
    ) {
        $this->maillaneSynchronizer         = $maillaneSynchronizer;
        $this->messageBag                   = $messageBag;
        $this->permissionEvaluator          = $permissionEvaluator;
        $this->entityManager                = $entityManager;
        $this->maillaneConnectionRepository = $maillaneConnectionRepository;
        $this->logger                       = $logger;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            PostNewProcedureCreatedEventInterface::class => 'prepareAccountCreation',
            PostProcedureDeletedEventInterface::class    => 'deleteAccount',
        ];
    }

    public function prepareAccountCreation(PostNewProcedureCreatedEventInterface $event): void
    {
        if ($this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_via_email())) {
            try {
                $procedure = $event->getProcedure();
                if (!$procedure->getMaster()) {
                    $this->createAccount($procedure);
                }
            } catch (Throwable $e) {
                $this->logger->error('Could not create Maillane account', [
                    'exception' => $e->getMessage(),
                ]);

                $this->messageBag->add(
                    'error',
                    'error.statement.import.mail.maillane.account.creation.failed'
                );
            }
        }
    }

    public function deleteAccount(PostProcedureDeletedEventInterface $event): void
    {
        if ($this->permissionEvaluator->isPermissionEnabled(Features::feature_import_statement_via_email())) {
            $procedureData = $event->getProcedureData();
            $procedureId = $procedureData['id'];
            $maillaneConnection = $this->maillaneConnectionRepository->getMaillaneConnectionByProcedureId($procedureId);
            if (null !== $maillaneConnection) {
                $this->maillaneSynchronizer->deleteAccount($maillaneConnection->getMaillaneAccountId());
            }
        }
    }

    /**
     * @throws MaillaneApiException
     * @throws InvalidArgumentException
     */
    private function createAccount(ProcedureInterface $procedure): void
    {
        $accountEmail = $this->maillaneSynchronizer->generateRecipientMailAddress(
            $procedure->getName()
        );

        $this->maillaneSynchronizer->createAccount($accountEmail, $procedure);

        $this->entityManager->flush();
    }
}
