<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Controller;

use DemosEurope\DemosplanAddon\Contracts\Config\GlobalConfigInterface;
use DemosEurope\DemosplanAddon\Contracts\MessageBagInterface;
use DemosEurope\DemosplanAddon\DemosMaillane\Logic\MailFetcher;
use DemosEurope\DemosplanAddon\DemosMaillane\Logic\MaillaneSynchronizer;
use DemosEurope\DemosplanAddon\DemosMaillane\Repository\MaillaneConnectionRepository;
use Doctrine\ORM\NoResultException;
use Doctrine\ORM\NonUniqueResultException;
use EDT\JsonApi\Schema\ContentField;
use EDT\JsonApi\Validation\FieldsValidator;
use EDT\Wrapping\TypeProviders\PrefilledTypeProvider;
use EDT\Wrapping\Utilities\SchemaPathProcessor;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;
use Throwable;
use DemosEurope\DemosplanAddon\Controller\APIController;
use DemosEurope\DemosplanAddon\Response\APIResponse;
use DemosEurope\DemosplanAddon\Utilities\Json;

class MaillaneApiController extends APIController
{
    /**
     * @var MaillaneConnectionRepository
     */
    private $maillaneConnectionRepository;

    /**
     * @var MailFetcher
     */
    private $mailFetcher;
    public function __construct(
        LoggerInterface $apiLogger,
        FieldsValidator $fieldsValidator,
        PrefilledTypeProvider $resourceTypeProvider,
        TranslatorInterface $translator,
        LoggerInterface $logger,
        GlobalConfigInterface $globalConfig,
        MessageBagInterface $messageBag,
        SchemaPathProcessor $schemaPathProcessor,
        MaillaneConnectionRepository $maillaneConnectionRepository,
        MailFetcher $mailFetcher
    ) {
        parent::__construct(
            $apiLogger,
            $resourceTypeProvider,
            $fieldsValidator,
            $translator,
            $logger,
            $globalConfig,
            $messageBag,
            $schemaPathProcessor
        );
        $this->maillaneConnectionRepository = $maillaneConnectionRepository;
        $this->mailFetcher = $mailFetcher;
    }

    /**
     * Triggers a fetch for all given mail-urls to retrieve new mails from Maillane
     * and saves them as new StatementImportMails.
     *
     * @Route(
     *        path="/api/plugins/maillane-connector/account/{accountId}/mail/{authToken}",
     *        methods={"POST"},
     *        name="dplan_api_maillane_connector_account_mail"
     *     )
     *
     * **PLEASE NOTE**: We technically want feature_import_statement_via_email as access
     * permission here. Due to current time constraints, this is not possible as we
     * do not want to give the guest user that permission. Authenticating from maillane
     * with any other user would require implementing JWT support which will happen
     * in the near future. Until then, access is limited with a purpose-generated
     * token stored in `maillane_api_token`.
     *
     * @return APIResponse
     */
    public function importNewImportableMailAction(MaillaneSynchronizer $synchronizer, Request $request, string $authToken, string $accountId): Response
    {
        if ($authToken !== $this->getParameter('maillane_api_token')) {
            return new Response(null, Response::HTTP_NO_CONTENT, []);
        }

        // We get mail links from Maillane
        $requestBody = Json::decodeToArray($request->getContent());
        $availableMails = $requestBody[ContentField::DATA];

        // we have to check if a corresponding procedure exists and get it if so
        try {
            $procedure = $this->maillaneConnectionRepository->getProcedureByMaillaneAccountId($accountId);
            $this->mailFetcher->fetchMailsForAccount($availableMails, $procedure);
        } catch (NoResultException|NonUniqueResultException $e) {
            $this->logger->warning('No unique procedure found for given account ID, deleting account.', [
                'accountId' => $accountId,
                'exception' => $e->getMessage()
            ]);

            $synchronizer->deleteAccount($accountId);
        } catch (Throwable $e) {
            $this->logger->error('Could not fetch all mails for given account ID', [
                'accountId' => $accountId,
                'exception' => $e->getMessage()
            ]);
        }

        return new Response(null, Response::HTTP_NO_CONTENT, []);
    }
}
