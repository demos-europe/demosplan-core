<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Configuration\Permissions;

use DemosEurope\DemosplanAddon\Permission\AbstractPermissionMeta;
use DemosEurope\DemosplanAddon\DemosMaillane\DemosMaillaneAddon;

class Features extends AbstractPermissionMeta
{
    /**
     * Allow the statement import via e-mails.
     *
     * Planners may receive e-mails containing statements and want to forward them into the application into a
     * specific procedure. This permission will enable the general functionality and adds a section to the
     * procedure settings where allowed email addresses can be configured as well as enabling a tab in the
     * import center to view and further process incoming emails. A list of these forwarded
     * e-mails will be shown in the import area in the target procedure. From there statements can be
     * created from the e-mail. Both the list as well as the creation from e-mail items are only
     * possible if this permission is enabled.
     */
    // #[Exposed(true)]
    // #[Parent('area_admin_import')]
    public static function feature_import_statement_via_email(): self
    {
        return new self('feature_import_statement_via_email');
    }

    /**
     *  In the settings for each procedure an individual list of email addresses can be set.
     * Only addresses in that list are allowed to send statements via email into the procedure.
     */
    public static function field_import_statement_email_addresses(): self
    {
        return new self('field_import_statement_email_addresses');
    }

    public function getAddonIdentifier(): ?string
    {
        return DemosMaillaneAddon::ADDON_NAME;
    }
}
