<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Configuration\Permissions;

use DemosEurope\DemosplanAddon\Contracts\Config\GlobalConfigInterface;
use DemosEurope\DemosplanAddon\Permission\PermissionConditionBuilder;
use DemosEurope\DemosplanAddon\Permission\PermissionInitializerInterface;
use DemosEurope\DemosplanAddon\Permission\ResolvablePermissionCollectionInterface;

class PermissionInitializer implements PermissionInitializerInterface
{
    private bool $restrictedAccess;

    public function __construct(GlobalConfigInterface $globalConfig)
    {
        $this->restrictedAccess = $globalConfig->hasProcedureUserRestrictedAccess();
    }

    public function configurePermissions(ResolvablePermissionCollectionInterface $permissionCollection): void
    {
        $permissionCollection->configurePermissionInstance(
            Features::feature_import_statement_via_email(),
            PermissionConditionBuilder::start()
                ->enableIfProcedureOwnedViaOrganisation(['RMOPSA', 'RMOPSD', 'RMOPHA'], $this->restrictedAccess)
                ->enableIfProcedureOwnedViaPlanningAgency(['RMOPSA', 'RMOPSD', 'RMOPHA'])
        );
        //FIXME
        $permissionCollection->configurePermissionInstance(
            Features::field_import_statement_email_addresses(),
            PermissionConditionBuilder::start()
                ->enableIfProcedureOwnedViaOrganisation(['RMOPSA', 'RMOPSD', 'RMOPHA'], $this->restrictedAccess)
                ->enableIfProcedureOwnedViaPlanningAgency(['RMOPSA', 'RMOPSD', 'RMOPHA'])
        );
    }
}



