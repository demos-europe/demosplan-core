<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane;

use DemosEurope\DemosplanAddon\Addon;

class DemosMaillaneAddon extends Addon
{
    public const ADDON_NAME = 'demos-europe/demosplan-addon-maillane';
}

