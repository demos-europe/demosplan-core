<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Exception;


use LogicException;

class MaillaneConfigurationException extends LogicException
{
    public static function missingParameter(string $string): self
    {
        return new self(sprintf('Missing configuration parameter `%s`', $string));
    }
}
