<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Test;

use DemosEurope\DemosplanAddon\DemosMaillane\Logic\MaillaneRouter;
use PHPUnit\Framework\TestCase;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBag;

class MaillaneRouterTest extends TestCase
{
    /**
     * @var MaillaneRouter
     */
    protected $sut;

    public function setUp(): void
    {
        parent::setUp();

        $parameterBag = new ParameterBag([
            'maillane_api_baseurl' => 'https://maillane/',
        ]);

        $this->sut = new MaillaneRouter($parameterBag);
    }

    public function testRoutes(): void
    {
        $routes = [
            ['https://maillane/api/account/', $this->sut->accountList()],
            ['https://maillane/api/account/1234/', $this->sut->accountDetail('1234')],
            ['https://maillane/api/account/1234/user/', $this->sut->userList('1234')],
            [
                'https://maillane/api/account/1234/user/5678/',
                $this->sut->userDetail('1234', '5678'),
            ],
        ];

        foreach ($routes as $route) {
            [$expected, $actual] = $route;
            self::assertEquals($expected, $actual);
        }
    }
}
