<?php

declare(strict_types=1);

namespace DemosEurope\DemosplanAddon\DemosMaillane\Validator;

use DemosEurope\DemosplanAddon\DemosMaillane\Constraint\MaillaneConnectionProcedureTemplateConstraint;
use DemosEurope\DemosplanAddon\DemosMaillane\Entity\MaillaneConnection;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

class MaillaneConnectionProcedureTemplateConstraintValidator extends ConstraintValidator
{
    public function validate($value, Constraint $constraint): void
    {
        $this->validateTyped($value, $constraint);
    }

    private function validateTyped(MaillaneConnection $maillaneConnection, MaillaneConnectionProcedureTemplateConstraint $constraint): void
    {
        if ($maillaneConnection->getProcedure()->getMaster()) {
            $this->context->buildViolation($constraint->message)->addViolation();
        }
    }
}
