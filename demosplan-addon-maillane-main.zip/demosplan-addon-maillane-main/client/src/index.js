/**
 * (c) 2010-present DEMOS plan GmbH.
 *
 * This file is part of the package demosplan,
 * for more information see the license file.
 *
 * All rights reserved
 */

import EmailImport from './addons/EmailImport/EmailImport'
import SplitStatementView from './addons/SplitStatementView/SplitStatementView'
import StatementPdfImport from './addons/StatementPdfImport/StatementPdfImport'
import StatementPdfImportStatusChart from "./addons/StatementPdfImportStatusChart/StatementPdfImportStatusChart"

export default {
  EmailImport,
  SplitStatementView,
  StatementPdfImport,
  StatementPdfImportStatusChart
}
