/**
 * (c) 2010-present DEMOS plan GmbH.
 *
 * This file is part of the package demosplan,
 * for more information see the license file.
 *
 * All rights reserved
 */

const DemosPlanAddon = require('@demos-europe/demosplan-addon')

const config = DemosPlanAddon.build(
    'demosplan-addon-maillane',
    {
      'EmailImport': DemosPlanAddon.resolve(
          'client/src/addons/EmailImport/EmailImport.vue'
      ),
      'DpAllowedSenderEmailList': DemosPlanAddon.resolve(
        'client/src/addons/DpAllowedSenderEmailList/DpAllowedSenderEmailList.vue'
      )
    }
)

module.exports = config
