---
sidebarTitle: Statement Import via Maillane
---

::: warning
This is unfinished. A couple of areas are still missing.
:::

# Statement Import via Maillane

## Goal

We want to allow users to send/redirect a mail representing a statement directly to an email address
to then have it ready for import into <demosplan />. To achieve this, we use a service called Maillane which
handles managing the emails coming from the mailserver and supplies an API to interact with those mails.

For a detailed explanation of the architectural interactions of the different parts,
see [the original concept](./concept-statement-pdf-import-via-redirected-email)

## Implementation

### Structure & Terminology

At the moment, we relate everything in regards to Maillane to a procedure in <demosplan />. 
That means that we add a `MaillaneConnection` to a procedure that contains all necessary
data for the relationship between <demosplan /> and Maillane to work properly. When we fetch
mails, we also save them as `StatementImportEmail`, again with a reference to the procedure.

| <demosplan /> | Maillane |
|:--|:--|
| MaillaneConnection | Account |
| RecipientMailAddress | Account name |
| AllowedSenderEmailAddress | User |

### Maillane

Maillane is an external service written in Python managing the mailserver interaction. 
It can be found with all its documentation here: [Maillane Repo](https://github.com/demos-europe/maillane)

### Backend

The backend implementation uses 2 entry points into this feature:

1. **ProcedureUpdateSubscriber**: To catch changes on a procedure triggering the necessary
Maillane interactions (CRUD accounts and users) in the `MaillaneSynchronizer`.
2. **MaillaneApiController**: To provide the route for Maillane to inform <demosplan /> of
new available mails. Fetching and processing the mails is handled in the `MailFetcher`.

All relevant files can be found in either the `StatementImportEmail` or `MaillaneConnector` namespaces.

| Class | Description |
|:--|:--|
| `MaillaneSynchronizer` | Handles any synchronization between <demosplan /> and Maillane. Creating and deleting accounts as well as creating and deleting users for those accounts. |
| `MailFetcher` | This service is responsible to retrieve email related data from Maillane including the mails themselves and attachments. It's also responsible for deleting mails. |
| `MaillaneRouter` | Adds Maillane related routes to Symfonys router and handles generating them. |
| `StatementImportEmail` | Entity to store received email ready to be imported. |
| `MaillaneConnection` | Entity to store a procedures Maillane connection details. |

### Frontend

::: warning
Frontend implementation details missing
:::

## Phabricator Board

[Maillane Phabricator board](https://yaits.demos-deutschland.de/tag/maillane/)

## History

| Date | Ticket | Details |
|:--|:--|:--|
| Jul 2022 | <Ticket>T27226</Ticket> | Implementation Part 3 |
| Jun 2022 | <Ticket>T26840</Ticket> | Implementation Part 2 |
| May 2022 | <Ticket>T18178</Ticket> | Implementation Part 1 |
| Jan 2022 | <Ticket>T24939</Ticket> | Discovery Part 2 |
| Jun 2020 | <Ticket>T17803</Ticket> | Discovery Part 1 |
