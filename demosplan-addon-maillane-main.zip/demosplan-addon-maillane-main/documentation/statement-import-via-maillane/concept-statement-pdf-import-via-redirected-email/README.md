---
sidebarTitle: Original concept for statement PDF import
---

# Statement PDF file import via redirected email

Epic: [T24877](https://yaits.demos-deutschland.de/T24877)

## Use case

Some planners get a lot of emails containing statements. The statements are mostly present as PDF file attachment
in the email. Other attachments may be present as well, some of them irrelevant and some to be used as attachment
to the statement.

To avoid the need for the planner to upload these PDF file attachments manually into <demosplan />, we provide a functionality
allowing them to simply redirect the email to a specific email-address, that is bound to a specific procedure. Within
the procedure in <demosplan /> a list of the emails sent to that email-address will be shown to allowed users.

We assume that the planners will want to use that feature quickly with individual statements as well as successively
with a lot of statements.

Within the list of received emails the planner is able to start the PDF import, to create corresponding statement
entries in <demosplan />.

In the primary use case a single email corresponds to a single statement. However, the following two edge cases should
be considered.

### Multiple statements within a PDF file attachment

Handling the existence of multiple statements in one of the PDF file attachments is the responsibility of the PDF
importer and independent of the PDF file being received as email attachment.

It could either allow to create multiple statements in the "Import bestätigen" view (e.g. via markers) or to define
the statement ranges previously in the "(Boxen) Überprüfen" view. This functionality should be easy to use even 
if the work is interrupted, like it is already handled in the "(Boxen) Überprüfen" view.

### Multiple PDF file attachments, each containing a single statement

If multiple PDF file attachments exist and not only one but multiple of those contain a statement, then planners are
able to repeatably process this email via the PDF importer until all statements are done.

## Authorizations

Which email addresses are allowed to redirect emails to the procedure email-address is determined by the logic of one
of the `ownsProcedure` methods (which does not necessarily means that their actual implementations are used for this specific check;
it is also unclear which of the two is the relevant one). The email addresses of the users allowed by this method are
allowed to be used to send emails. Additionally, the following email addresses are to be supported in further implementations:

* [ ] email addresses of users with the role `PROCEDURE_DATA_INPUT` ("Datenerfasser") whose organisation was set in the procedure settings as "Datenerfassende Organisation"
* [ ] email addresses of organisations that are granted access to the procedure
* [ ] email addresses that are manually defined via the procedure settings

(Note: `PLANNING_SUPPORTING_DEPARTMENT` and departments in general are not authorized/relevant for the authorization)

A list showing
the allowed users/email-addresses was rejected, as most probably only users that are already allowed to use the
redirect feature would be allowed to see that list anyway.

In the list of redirected emails in <demosplan /> an inline notification is shown informing the user to
which address an email must be sent to reach the current procedure and which email address to use, depending on the
currently logged-in user. A convenience "E-Mail-Adresse kopieren" function should be considered.

## Email send/receive architecture

1. Email server
2. separate service
3. separate service database
4. <demosplan />
5. <demosplan /> database

<demosplan /> will not communicate with the email server directly. Instead, a decoupled service is used, which provides
data to the email server by placing it in a database and retrieves emails from it via IMAP.

![high level architecture overview](./assets/backend-architecture.svg)

The email server will only accept incoming emails if they are directed to one of the allowed procedure email addresses
**and** if they were sent from one of the allowed user email addresses. The addresses are read
from a separate database, in which they were previously placed (see sequence diagram below).
The procedure email address being present in that database is sufficient for it being available
as recipient to the outside world, additional email server configurations are not necessary.

![sequence diagram to send emails](./assets/email-send-sequence.svg)

If a new procedure is created the service must be informed not only about the new procedure ID, but also about the
new user email addresses that are allowed to sent email into that procedure.
The procedure email address is stored in the <demosplan /> database, as otherwise it would need to be fetched
from the service everytime it is shown in the UI (see sequence diagram below). 

![sequence diagram to update allowed procedure email addresses](./assets/email-procedure-update-sequence.svg)

Additionally, the list of allowed user email addresses
must be updated every time the authorizations are affected by actions in <demosplan /> in any way, e.g. via customer
settings, procedure settings or role settings (see sequence diagram below).

![sequence diagram to update allowed user email addresses](./assets/email-user-update-sequence.svg)

The emails are fetched via the service from the email server and must be stored as entities in the <demosplan />
database, otherwise it would be really hard to
implement filter/sorting access via relationships, as the relationships would still be stored
in the <demosplan /> database (see sequence diagram below).

![sequence diagram to fetch emails](./assets/email-fetch-sequence.svg)

### Implementation concept within demosplan

* listeners/subscribers everywhere possible

TODO

### Implementation concept within the separate process

* doctrine or not? seems unnecessary

TODO

## Task flow concept

### 1. Redirect of an email with attachment to [procedureId]@[domain].de (tbd).

TODO
* salted hash cuttet to length

### 2. Selection of the relevant PDF files to be imported in the `StatementImportEmail` list.

In the `StatementImportEmail` list items representing the redirected emails will be shown. The list will be kept
separate from the list of imported PDF files, as mixing them would result in convolution and problems, especially
for a filtering functionality.

For each item various information considered relevant will be shown to help users to orientate:

* Subject: the subject before the email was redirected. Needs to be parsed from the email body. 
* Sender: the sender who sent the email to the planner. Needs to be parsed from the email body.
* Send date: the date the email was sent to the planner. Needs to be parsed from the email body.
* Redirecting user: the name of the user that redirected the email into <demposplan /> (shown in a tooltip, as not as relevant as the sender mentioned above).
* Date the redirect was received (e.g. entity creation).
* Date the redirect was sent
* Email body preview: full text shown when extended.
* Attachments: Anhänge der E-Mail, including the status in the PDF importer
* Status: showing if a statement was already created in <demosplan /> for this email
  
The default sorting uses the date of the redirect. Otherwise, when using the original send date, later redirected emails may be shown way below emails that
were already imported some time ago, which may be confusing.

Possible improvements:

* [ ] enable the user to distinguish between new and already seen items
* [ ] list pagination, as it may grow large
* [ ] search, facet filtering and sort options
* [ ] when the rework of the list of imported PDF files is done, email attachments shown there could provide a link to
  their representation in the `StatementImportEmail` list

### Import of PDF document with existing [PDF importer Task Flow](../pdf-importer-workflow)

For the new email-redirecting use it is important for the PDF importer to allow the handling of statement attachments
in the "Import bestätigen" step. The user must be able to select from a list of shown attachments and add additional
ones to it. To give the users more information about an attachment than just its file name, they are able to open a modal
showing a preview for at least the most common file formats (PDF and common image formats) as well as being able to
download the file and view it locally, e.g. in the case of DOCX files.

That initial list of attachments in the "Import bestätigen" view can be either be prefilled from the email entity in the `AnnotatedStatementPdf` entity
when starting the import, or the email entity could be accessed directly by the code for that view.

The statement data in the "Import bestätigen" view will not automatically be filled from the email (e.g. sender). Instead
the PDF data remains the only source.

After the import of a PDF was completed the corresponding email entity will be automatically marked as completed.

A rough sketch of the task flow is visualized in [T24939#587538](https://yaits.demos-deutschland.de/T24939#587538).

## Parsing data from the email

Most of the non-attachment data needs to be parsed from the email body, because no dedicated email header field or is reliably present.
This includes the subject, sender and sent date. How this information is presented in the body may depend on the email client used.
An example for Thunderbird (91.4.1) after which the original body would follow is shown below.

```
-------- Forwarded Message --------
Subject:     Diwias mailtest
Date:     Mon, 05 Nov 2018 11:33:04 -0000
From:     noreply@diwias.invalid
To:     bobsh-info-test@berlin.demos-europe.eu
```

## Frontend integration - first thoughts

A **PDF-Viewer** may be implemented by using the `<object>` tag:

```html
<object
    data="https://example.com/some.pdf"
    type="application/pdf"
    width="100%"
    height="700px">
</object>
```

When implementing the **copy to clipboard** button, the implementation in `AuthorizedUsersList.vue`
and its method `copyTokenToClipboard` may be reused by crafting a distinct component.
