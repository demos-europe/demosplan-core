const DemosPlanAddon = require('@demos-europe/demosplan-addon')

const config = DemosPlanAddon.build(
    'demosplan-addon-segment-oracle',
    {
        'OracleRecommendationTab': DemosPlanAddon.resolve(
            'client/addons/OracleRecommendationTab/OracleRecommendationTab.vue'
        )
    }
)

module.exports = config