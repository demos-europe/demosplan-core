<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS plan GmbH, for more information see the license file.
 *
 * All rights reserved
 */

use DemosEurope\DemosplanAddon\SegmentOracle\Entity\SegmentChangeNotification;
use DemosEurope\DemosplanAddon\SegmentOracle\Exception\SegmentChangeNotificationNotSentException;
use DemosEurope\DemosplanAddon\SegmentOracle\Logic\SegmentOracleService;
use DemosEurope\DemosplanAddon\SegmentOracle\Repository\SegmentChangeNotificationRepository;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Symfony\Component\DependencyInjection\Exception\ParameterNotFoundException;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Symfony\Component\HttpClient\Exception\TransportException;
use Symfony\Component\HttpClient\HttpClient;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class SegmentOracleServiceTest extends TestCase
{
    private const TEST_COLLECTION_NAME = 'answered_segments_test';
    private const SEMQUERY_URL = 'http://semquery.pi.berlin.demos-europe.eu';
    private const SEMQUERY_PORT = '8091';
    private const SEMQUERY_AUTHORIZATION = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2OTQ3NzU2MzksIndyaXRlX3Blcm1pc3Npb24iOnRydWV9._07gE39K40mU6znJqKwfShH8sTJlVb5D7rqCizSDCyc';

    private const FIXTURE_PROCEDURE_ID_I = '00250f93-aaaa-aaaa-aaaa-782bcb0d78b1';
    private const FIXTURE_PROCEDURE_ID_II = '00250f94-aaaa-aaaa-aaaa-782bcb0d78b1';
    private const FIXTURE_PARENT_STATEMENT_ID_I = 'cf9576da-aaaa-aaaa-aaaa-782bcb0d78b1';
    private const FIXTURE_PARENT_STATEMENT_ID_II = 'df5356da-aaaa-aaaa-aaaa-702bcb0d79b1';
    private const FIXTURE_SEGMENT_ID_I = 'e843c993-aaaa-aaaa-aaaa-782bcb0d78b1';
    private const FIXTURE_SEGMENT_ID_II = 'e843c99e-aaaa-aaaa-aaaa-783bcb0d78b1';
    private const FIXTURE_SEGMENT_ID_III = 'e843c900-aaaa-aaaa-aaaa-783bcb0d78b1';


    private HttpClientInterface $httpClient;
    private MockObject $logger;
    private MockObject $parameterBag;
    private MockObject $segmentChangeNotificationRepository;

    protected function setUp(): void
    {
        $this->markTestSkipped('For local development only');
        parent::setUp();

        $this->httpClient = HttpClient::create();
        $this->logger = $this->createMock(\Psr\Log\LoggerInterface::class);
        $this->parameterBag = $this->createMock(ParameterBagInterface::class);
        $this->segmentChangeNotificationRepository = $this->createMock(SegmentChangeNotificationRepository::class);

        $this->sut = new SegmentOracleService(
            $this->httpClient,
            $this->logger,
            $this->parameterBag,
            $this->segmentChangeNotificationRepository
        );

        // create the test collection on remote
        $this->createTestCollection();
    }

    protected function tearDown(): void
    {
        parent::tearDown();
        // delete the test collection on remote side
        $this->deleteCollection();
    }

    public function testCreateUpdateDelete()
    {
        $this->configureParameterMock();

        $this->configureLoggerMockFailIndicators();
        // configure loggerMock success indicator
        // if the logger->info gets called with the success-message as parameter - a successful transfer has happened
        $countSuccessMessages = 0;
        $this->logger->method('info')
            ->willReturnCallback(static function (string $parameter) use (&$countSuccessMessages): string {
                if ('SegmentChangeNotification(s) could be sent successfully.' === $parameter) {
                    $countSuccessMessages++;
                }
                return '';
            });

        // test create
        $testNotificationType = 'createTestEntries';
        // configure Repository mock to return different SegmentNotificationChange Mock entity properties depending
        // on the current value of $testNotificationType in order to create then update, delete the same mocked segment.
        $this->segmentChangeNotificationRepository->method('getAllNewSortedByCreateDate')
            ->willReturnCallback(function () use (&$testNotificationType): array {
                return $this->getMockedSegmentChangeNotifications($testNotificationType);
            });
        $this->segmentChangeNotificationRepository->method('getAllFaultySortedByCreateDate')
            ->willReturn([]);

        $this->sut->sentSegmentChangeNotifications();
        echo("\nsent create Segment message");
        // assert the success indicator was triggered and incremented
        $this->assertEquals(1, $countSuccessMessages, 'create segment(s) message transfered successfully');

        // test query
        $procedureIds = [self::FIXTURE_PROCEDURE_ID_I, self::FIXTURE_PROCEDURE_ID_II];
        $segmentId = self::FIXTURE_SEGMENT_ID_I;
        $result = $this->sut->querySegmentRecommendations($segmentId, $procedureIds, 2);
        $this->assertArrayHasKey(self::FIXTURE_SEGMENT_ID_I, $result, 'check array has input segmentId as key');
        foreach ($result[self::FIXTURE_SEGMENT_ID_I] as $similarSegmentProposal) {
            $this->assertArrayHasKey('score', $similarSegmentProposal, 'check result has score key');
            $this->assertArrayHasKey('segment_id', $similarSegmentProposal, 'check result has segment_id key');
        }

        // test update
        // $testNotificationType value gets used as reference within the callback of
        // $this->segmentChangeNotificationRepository->method('getAllSortedByCreateDate')
        $testNotificationType = SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE;
        $this->sut->sentSegmentChangeNotifications();
        echo("\nsent update Segment message");
        // assert the success indicator was triggered and incremented
        $this->assertEquals(2, $countSuccessMessages, 'update segment(s) message transfered successfully');

        // test delete
        // $testNotificationType value gets used as reference within the callback of
        // $this->segmentChangeNotificationRepository->method('getAllSortedByCreateDate')
        $testNotificationType = SegmentChangeNotification::NOTIFICATION_TYPE_DELETE;
        $this->sut->sentSegmentChangeNotifications();
        echo("\nsent delete Segment message");
        // assert the success indicator was triggered and incremented
        $this->assertEquals(3, $countSuccessMessages, 'delete segment(s) message transfered successfully');
    }

    private function getMockedSegmentChangeNotifications(string $notificationType): array
    {
        $segmentChange1 = $this->createMock(SegmentChangeNotification::class);
        $segmentChange1->method('getSegmentId')->willReturn(self::FIXTURE_SEGMENT_ID_I);
        $segmentChange1->method('getProcedureId')->willReturn(self::FIXTURE_PROCEDURE_ID_I);
        $segmentChange1->method('getParentStatementId')->willReturn(self::FIXTURE_PARENT_STATEMENT_ID_I);
        $segmentChange1->method('getNotificationType')->willReturn(
            'createTestEntries' === $notificationType
                ? SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE : $notificationType
        );
        $segmentChange1->method('getSegmentText')
            ->willReturnCallback(static function () use ($notificationType): string {
                if (SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE === $notificationType) {

                    return 'Some updated Text to test';
                }
                return 'Some Text to test';
            });
        $segmentChange1->method('getSegmentRecommendation')->willReturn('fitting recommendation');
        $segmentChange1->method('getCreateDate')->willReturn(new DateTime());

        $segmentChange2 = $this->createMock(SegmentChangeNotification::class);
        $segmentChange2->method('getSegmentId')->willReturn(self::FIXTURE_SEGMENT_ID_II);
        $segmentChange2->method('getProcedureId')->willReturn(self::FIXTURE_PROCEDURE_ID_I);
        $segmentChange2->method('getParentStatementId')->willReturn(self::FIXTURE_PARENT_STATEMENT_ID_I);
        $segmentChange2->method('getNotificationType')->willReturn(
            'createTestEntries' === $notificationType
                ? SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE : $notificationType
        );
        $segmentChange2->method('getSegmentText')
            ->willReturnCallback(static function () use ($notificationType): string {
                if (SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE === $notificationType) {

                    return 'Some different updated Text to test';
                }
                return 'Some different Text to test';
            });
        $segmentChange2->method('getSegmentRecommendation')->willReturn('more fitting recommendation');
        $segmentChange2->method('getCreateDate')->willReturn(new DateTime());

        // segment with different procedrue context
        $segmentChange3 = $this->createMock(SegmentChangeNotification::class);
        $segmentChange3->method('getSegmentId')->willReturn(self::FIXTURE_SEGMENT_ID_III);
        $segmentChange3->method('getProcedureId')->willReturn(self::FIXTURE_PROCEDURE_ID_II);
        $segmentChange3->method('getParentStatementId')->willReturn(self::FIXTURE_PARENT_STATEMENT_ID_II);
        $segmentChange3->method('getNotificationType')->willReturn(
            'createTestEntries' === $notificationType
                ? SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE : $notificationType
        );
        $segmentChange3->method('getSegmentText')
            ->willReturnCallback(static function () use ($notificationType): string {
                if (SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE === $notificationType) {

                    return 'A stable coin death spiral';
                }
                return 'To the moon!';
            });
        $segmentChange3->method('getSegmentRecommendation')->willReturn('Whatever rows your boat.');
        $segmentChange3->method('getCreateDate')->willReturn(new DateTime());

        return [$segmentChange1, $segmentChange2, $segmentChange3];
    }

    private function configureParameterMock(): void
    {
        $this->parameterBag->method('get')
            ->willReturnCallback(static function (string $parameter): string {
                if ('semqueryUrl' === $parameter) {
                    return self::SEMQUERY_URL;
                }
                if ('semqueryPort' === $parameter) {
                    return self::SEMQUERY_PORT;
                }
                if ('semQueryAuthorization' === $parameter) {
                    return self::SEMQUERY_AUTHORIZATION;
                }
                if ('collectionName' === $parameter) {
                    return self::TEST_COLLECTION_NAME;
                }
                return '';
            });
    }

    public function configureLoggerMockFailIndicators(): void
    {
        // fail indicators
        $this->logger->method('error')->willReturnCallback(
            static function (string $parameter): void {
                if ('Failed to build prepare/send single request.' === $parameter) {
                    throw new TransportException();
                }
                if ('Could not find default-parameters' === $parameter) {
                    throw new ParameterNotFoundException('');
                }
                if ('Failed to build prepare/send bulk request.' === $parameter) {
                    throw new TransportException();
                }
                if ('failed to send SegmentChangeNotification(s)' === $parameter) {
                    throw new SegmentChangeNotificationNotSentException();
                }
            }
        );
    }

    private function createTestCollection(): void
    {
        $response = $this->httpClient->request(
            'POST',
            self::SEMQUERY_URL.':'.self::SEMQUERY_PORT.'/create_collection',
            [
                'query' => ['collection_name' => self::TEST_COLLECTION_NAME],
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                    'Authorization' => self::SEMQUERY_AUTHORIZATION
                ]
            ]
        );
        $statusCode = $response->getStatusCode();
        if ($statusCode !== 200 && $statusCode !== 201) {
            throw new Exception('creating test collection failed with status code: '. $statusCode);
        }
        echo("\ntest collection created successfully");
    }

    private function deleteCollection(): void
    {
        $response = $this->httpClient->request(
            'DELETE',
            self::SEMQUERY_URL.':'.self::SEMQUERY_PORT.'/delete_collection',
            [
                'query' => ['collection_name' => self::TEST_COLLECTION_NAME],
                'headers' => [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                    'Authorization' => self::SEMQUERY_AUTHORIZATION
                ]
            ]
        );
        $statusCode = $response->getStatusCode();
        if ($statusCode !== 200 && $statusCode !== 201 && $statusCode !== 202) {
            // if the testCollection can not be deleted - the create_collection method in setUp() needs to change
            throw new Exception('deleting test collection failed with status code: '. $statusCode);
        }
        echo("\ntest collection successfully deleted");
    }
}
