<?php declare(strict_types = 1);

namespace Application\Migrations;

use Doctrine\DBAL\Exception;
use Doctrine\DBAL\Platforms\MySQLPlatform;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

class Version20230802132537 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'refs T:33807 adds segmentChangeNotification table - used only for specific addon';
    }

    /**
     * @throws Exception
     */
    public function up(Schema $schema): void
    {
        $this->abortIfNotMysql();

        $this->addSql('CREATE TABLE segment_change_notification (id CHAR(36) NOT NULL, procedure_id VARCHAR(36) NOT NULL, parent_statement_id VARCHAR(36) NOT NULL, segment_id VARCHAR(36) NOT NULL, notification_type VARCHAR(36) NOT NULL, segment_text LONGTEXT DEFAULT NULL, segment_recommendation LONGTEXT DEFAULT NULL, created_date DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL, error_count INT DEFAULT 0, PRIMARY KEY(id)) DEFAULT CHARACTER SET UTF8 COLLATE `UTF8_unicode_ci` ENGINE = InnoDB');
    }

    /**
     * @throws Exception
     */
    public function down(Schema $schema): void
    {
        $this->abortIfNotMysql();

        $this->addSql('DROP TABLE segment_change_notification');
    }

    /**
     * @throws Exception
     */
    private function abortIfNotMysql(): void
    {
        $this->abortIf(
            !$this->connection->getDatabasePlatform() instanceof MySQLPlatform,
            "Migration can only be executed safely on 'mysql'."
        );
    }
}
