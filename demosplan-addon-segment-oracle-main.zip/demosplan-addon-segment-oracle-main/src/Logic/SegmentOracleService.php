<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS plan GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\SegmentOracle\Logic;

use cebe\openapi\json\MalformedJsonReferenceObjectException;
use DemosEurope\DemosplanAddon\Contracts\Entities\SegmentInterface;
use DemosEurope\DemosplanAddon\SegmentOracle\Entity\SegmentChangeNotification;
use DemosEurope\DemosplanAddon\SegmentOracle\Repository\SegmentChangeNotificationRepository;
use Exception;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Exception\ParameterNotFoundException;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Symfony\Component\HttpClient\Exception\ServerException;
use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Symfony\Contracts\HttpClient\ResponseInterface;

class SegmentOracleService
{
    public function __construct(
        private HttpClientInterface $client,
        private LoggerInterface $logger,
        private ParameterBagInterface $parameterBag,
        private SegmentChangeNotificationRepository $segmentChangeNotificationRepository
    ) {

    }

    /**
     * @param array<int, SegmentInterface> $segments
     * @param SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE|SegmentChangeNotification::NOTIFICATION_TYPE_DELETE $notificationType
     */
    public function createNewSegmentChangeNotification(array $segments, string $notificationType): void
    {
        try {
            foreach ($segments as $segment) {
                $this->logger->info(
                    'SegmentOracle creates a SegmentCreateNotification regarding a ' . $notificationType . 'message',
                    [$segment->getId()]
                );
                // The condition order matters here!
                // if no recommendation exists - semquery does not know about this segment and therefore cant delete it.
                if (SegmentChangeNotification::NOTIFICATION_TYPE_DELETE === $notificationType
                    && '' === $segment->getRecommendation()
                ) {
                    continue;
                }
                // The condition order matters here!
                // if the recommendation text was present before and now gets erased (an update on our side)
                // - for semquery this means they want to delete this entry.
                if (SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE === $notificationType
                    && $this->segmentChangeNotificationRepository->shouldDeleteDueToBlankedOutRecommendation($segment)
                ) {
                    $notificationType = SegmentChangeNotification::NOTIFICATION_TYPE_DELETE;
                }
                // The condition order matters here!
                // an update should only create a new SegmentChangeNotification if a relevant field changed
                if (SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE === $notificationType
                    && !$this->segmentChangeNotificationRepository->hasRelevantFieldChanged($segment)
                ) {

                    continue;
                }

                $this->segmentChangeNotificationRepository->createNew($segment, $notificationType);
            }
        } catch (Exception $e) {
                $this->logger->error('failed saving SegmentCreateNotification', [$e]);
        }
    }

    public function sentSegmentChangeNotifications(): void
    {
        /** @var array<int, SegmentChangeNotification> $notificationList */
        $notificationList = $this->segmentChangeNotificationRepository->getAllNewSortedByCreateDate();
        $this->sendUpdateNotifications($notificationList);
        $this->sendDeleteNotifications($notificationList);
        /** @var array<int, SegmentChangeNotification> $faultyNotificationList */
        // try to send previously failed messages again - one by one
        $faultyNotificationList = $this->segmentChangeNotificationRepository->getAllFaultySortedByCreateDate();
        foreach ($faultyNotificationList as $faultyNotification) {
            $this->logger->info('try to send a list containing a single previously failed notification Message');
            $this->sendAsBunch([$faultyNotification]);
        }
    }

    /**
     * @param array<int, string> $procedureIds
     * @param int $topN specifies how many recommendations should be queried
     * @return array<string, array> key: segmentId, Value: array<int, array<string, string|float>>
     * @throws MalformedJsonReferenceObjectException
     * @throws TransportExceptionInterface
     * @throws ClientExceptionInterface
     * @throws ServerExceptionInterface
     * @throws Exception
     */
    public function querySegmentRecommendations(string $segmentId, array $procedureIds, int $topN): array
    {
        $method = 'POST';
        $endPoint = 'query';
        $url = $this->getBaseSemQueryUrl().$endPoint;
        $json = [
            'procedure_ids' => $procedureIds,
            'segment_id' => $segmentId,
            'top_n' => $topN
        ];

        $response = $this->client->request($method, $url, [
            'query' => $this->getSemQueryParams(),
            'headers' => $this->getSemQueryHeader(),
            'json' => $json
        ]);

        $statusCode = $response->getStatusCode();
        if ($statusCode !== 200) {
            throw new ServerException($response);
        }

        $content = json_decode($response->getContent(), true);
        if (!isset($content['query_segment_id']) || !isset($content['similar_segments'])) {
            throw new MalformedJsonReferenceObjectException(
                'JSON Reference Object must contain the "query_segment_id" and "similar_segments" members.'
            );
        }

        return [$content['query_segment_id'] => $content['similar_segments']];
    }

    /**
     * @var array<int, SegmentChangeNotification> $allNotifications
     */
    private function sendUpdateNotifications(array $allNotifications): void
    {
        $updateNotifications = array_filter(
            $allNotifications,
            static fn(SegmentChangeNotification $segmentChangeNotification): bool
            => SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE === $segmentChangeNotification->getNotificationType()
        );

        if (0 < count($updateNotifications)) {
            $this->sendAsBunch($updateNotifications);
        }
    }

    /**
     * @var array<int, SegmentChangeNotification> $allNotifications
     */
    private function sendDeleteNotifications(array $allNotifications): void
    {
        $deleteNotifications = array_filter(
            $allNotifications,
            static fn(SegmentChangeNotification $segmentChangeNotification): bool
            => SegmentChangeNotification::NOTIFICATION_TYPE_DELETE === $segmentChangeNotification->getNotificationType()
        );

        if (0 < count($deleteNotifications)) {
            // only deletable as bunch
            $this->sendAsBunch($deleteNotifications);
        }
    }

    /**
     * @var non-empty-array<int, SegmentChangeNotification> $segmentChangeNotificationList
     */
    private function sendAsBunch(array $segmentChangeNotificationList): void
    {
        $this->logger->info(
            'preparing to send a list of SegmentChangeNotifications',
            [$segmentChangeNotificationList]
        );

        try {
            /** @var SegmentChangeNotification $firstSegmentChangeNotification */
            $firstSegmentChangeNotification = reset($segmentChangeNotificationList);
            $notificationType = $firstSegmentChangeNotification->getNotificationType();

            $json = [
                'points' => $this->getJsonPointsContentForUpdateNotifications($segmentChangeNotificationList)
            ];
            $method = 'PATCH';
            $endPoint = 'update_segments';
            if (SegmentChangeNotification::NOTIFICATION_TYPE_DELETE === $notificationType) {
                $method = 'DELETE';
                $endPoint = 'delete_segments';
                $segmentIds = [];
                foreach ($segmentChangeNotificationList as $segmentChangeNotification) {
                    $segmentIds[] = $segmentChangeNotification->getSegmentId();
                }
                $json = [
                    'segment_ids' => $segmentIds
                ];
            }

            $url = $this->getBaseSemQueryUrl().$endPoint;
            $response = $this->client->request($method, $url, [
                'query' => $this->getSemQueryParams(),
                'headers' => $this->getSemQueryHeader(),
                'json' => $json
            ]);

            $statusCode = $response->getStatusCode();
            if ($statusCode !== 200 && $statusCode !== 201 && $statusCode !== 202) {
                $this->handleErrorOnSend($response, $segmentChangeNotificationList);

                return;
            }
            $this->handleSuccessOnSend($response, $segmentChangeNotificationList);

        } catch (TransportExceptionInterface $exception) {
            $this->logger->error(
                'Failed to build prepare/send bulk request.',
                [
                    $method,
                    $url ?? 'No Url given!',
                    $this->getSemQueryParams(),
                    $this->getSemQueryHeader(),
                    $json,
                    $exception
                ]
            );
        } catch (ParameterNotFoundException $exception) {
            $this->logger->error('Could not find default-parameters', [$exception]);
        }
    }

    /**
     * @var array<int, SegmentChangeNotification> $segmentChangeNotificationList
     * @return array<int, array<string, string>>
     */
    private function getJsonPointsContentForUpdateNotifications(array $segmentChangeNotificationList): array
    {
        $points = [];
        foreach ($segmentChangeNotificationList as $segmentChangeNotification) {
            $points[] = [
                'segment_text' => $segmentChangeNotification->getSegmentText(),
                'answer_text' => $segmentChangeNotification->getSegmentRecommendation(),
                'procedure_id' => $segmentChangeNotification->getProcedureId(),
                'segment_id' => $segmentChangeNotification->getSegmentId(),
                'statement_id' => $segmentChangeNotification->getParentStatementId(),
                'last_update' => $segmentChangeNotification->getCreateDate()->format('Y-m-d H:i:s')
            ];
        }

        return $points;
    }

    /**
     * @throws ParameterNotFoundException
     */
    private function getBaseSemQueryUrl(): string
    {
        $baseUrl = $this->getParameter('semqueryUrl');
        $port = $this->getParameter('semqueryPort');
        return $baseUrl.':'.$port.'/';
    }

    /**
     * @throws ParameterNotFoundException
     */
    private function getSemQueryHeader(): array
    {
        return [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => $this->getParameter('semQueryAuthorization')
        ];
    }

    private function getSemQueryParams(): array
    {
        return ['collection_name' => $this->getParameter('collectionName')];
    }

    /**
     * Gets a parameter by its name.
     * @throws ParameterNotFoundException
     */
    private function getParameter(string $name): array|bool|string|int|float|\UnitEnum|null
    {
        return $this->parameterBag->get($name);
    }

    /**
     * @var array<int, SegmentChangeNotification> $segmentChangeNotificationList
     */
    private function handleSuccessOnSend(ResponseInterface $response, array $segmentChangeNotificationList): void
    {
        $this->logger->info('SegmentChangeNotification(s) could be sent successfully.', $response->getInfo());

        foreach ($segmentChangeNotificationList as $segmentChangeNotification) {
            $this->segmentChangeNotificationRepository->delete($segmentChangeNotification);
        }
        $this->segmentChangeNotificationRepository->flushEverything();
    }

    /**
     * @var array<int, SegmentChangeNotification> $segmentChangeNotificationList
     */
    private function handleErrorOnSend(ResponseInterface $response, array $segmentChangeNotificationList): void
    {
        $this->logger->error('failed to send SegmentChangeNotification(s)', $response->getInfo());
        $this->logger->error('Semquery Response: ', [$response->getContent(false) ?? $response->getStatusCode()]);

        foreach ($segmentChangeNotificationList as $segmentChangeNotification) {
            $segmentChangeNotification->setErrorCount($segmentChangeNotification->getErrorCount() + 1);
        }
        $this->segmentChangeNotificationRepository->flushEverything();
    }
}
