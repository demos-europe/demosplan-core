<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS plan GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\SegmentOracle\Logic;

use cebe\openapi\json\MalformedJsonReferenceObjectException;
use DemosEurope\DemosplanAddon\Contracts\CurrentContextProviderInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\ProcedureInterface;
use DemosEurope\DemosplanAddon\Contracts\Services\SegmentServiceInterface;
use DemosEurope\DemosplanAddon\Logic\Rpc\RpcErrorGeneratorInterface;
use DemosEurope\DemosplanAddon\Logic\Rpc\RpcMethodSolverInterface;
use DemosEurope\DemosplanAddon\Permission\PermissionEvaluatorInterface;
use DemosEurope\DemosplanAddon\SegmentOracle\Configuration\Permissions\Features;
use Doctrine\Common\Collections\ArrayCollection;
use Exception;
use InvalidArgumentException;
use Psr\Log\LoggerInterface;
use stdClass;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;

class RpcFittingSegmentRecommendations implements RpcMethodSolverInterface
{

    private const SEGMENT_ORACLE_RECOMMENDATIONS_NETHOD = 'segment.oracle.recommendations';

    public function __construct(
        private LoggerInterface $logger,
        private PermissionEvaluatorInterface $permissionEvaluator,
        private SegmentServiceInterface $segmentService,
        private readonly CurrentContextProviderInterface $contextProvider,
        private readonly SegmentOracleService $segmentOracleService,
        protected RpcErrorGeneratorInterface $errorGenerator
    )
    {
    }

    public function supports(string $method): bool
    {
        return self::SEGMENT_ORACLE_RECOMMENDATIONS_NETHOD  === $method;
    }

    /**
     * @param array|object $rpcRequests
     *
     * @return array<int|string,mixed>
     */
    public function execute(?ProcedureInterface $procedure, $rpcRequests): array
    {
        $rpcRequests = is_object($rpcRequests)
            ? [$rpcRequests]
            : $rpcRequests;

        $resultResponse = [];
        foreach ($rpcRequests as $rpcRequest) {
            try {
                $this->validateRpcRequest($rpcRequest);

                if ($this->contextProvider->getCurrentProcedure()?->getId() !== $procedure?->getId()) {
                    throw new InvalidArgumentException(
                        'only segments within the current procedure can be queried'
                    );
                }
                $allowedProceduresToUseInSearch =
                    $procedure?->getSettings()->getAllowedSegmentAccessProcedures() ?? new ArrayCollection();
                $allowedProceduresToUseInSearch->add($procedure);
                $allowedProcedureIdsToUseInSearch = [];
                foreach ($allowedProceduresToUseInSearch as $allowedProcedure) {
                    $allowedProcedureIdsToUseInSearch[] = $allowedProcedure->getId();
                }
                if (0 === count($allowedProcedureIdsToUseInSearch)) {
                    throw new InvalidArgumentException(
                        'allowed procedures to look up (has to be at least one) - found => "0"');
                }
                $segmentId = $rpcRequest->params->segmentId ?? '';
                if ('' === $segmentId) {
                    throw new InvalidArgumentException('a segmentId is necessary - found => ""');
                }
                $recommendationsCountForSegment = $rpcRequest->params->recommendationsCount ?? 0;
                if (0 === (int)$recommendationsCountForSegment) {
                    throw new InvalidArgumentException(
                        'requested amount of fitting recommendations (has to be at least one) - found => "0"'
                    );
                }

                /** @var array<string, array> $oracleResponse
                 * key: segmentId, Value: array<int, array<string, string|float>>
                 */
                $oracleResponse = $this->segmentOracleService->querySegmentRecommendations(
                    $segmentId,
                    $allowedProcedureIdsToUseInSearch,
                    $recommendationsCountForSegment
                );
                $segmentRecommendations = $oracleResponse[$segmentId];
                /** @var array<string, array<string, string|float>> $result */
                $result = $this->getSortedResult($segmentRecommendations);
                $resultResponse[] = $this->generateMethodResult($rpcRequest, $result);
            } catch (AccessDeniedException $e) {
                $this->logger->warning('user is missing permission to request segment recommendations', [$e]);
                $resultResponse[] = $this->errorGenerator->accessDenied($rpcRequest);

            } catch (ClientExceptionInterface|TransportExceptionInterface|ServerExceptionInterface $e) {
                $this->logger->error(
                    'failed to query segment recommendations',
                    [$e]
                );
                $resultResponse[] = $this->errorGenerator->serverError($rpcRequest);

            } catch (MalformedJsonReferenceObjectException $e) {
                $this->logger->error(
                    'failed to parse segmentRecommendation query response',
                    [$e]
                );
                $resultResponse[] = $this->errorGenerator->parseError($rpcRequest);

            } catch (InvalidArgumentException $e) {
                $this->logger->error(
                    'Invalid parameters within request',
                    [$e]
                );
                $resultResponse[] = $this->errorGenerator->invalidParams($rpcRequest);

            } catch (Exception $e) {
                $this->logger->error(
                    'unspecific exception occurred trying to query segment recommendations',
                    [$e]
                );
                $resultResponse[] = $this->errorGenerator->internalError($rpcRequest);
            }
        }
        return $resultResponse;
    }

    public function generateMethodResult(object $rpcRequest, array $segmentRecommendations): object
    {
        $result = new stdClass();
        $result->jsonrpc = '2.0';
        $result->result = $segmentRecommendations;
        $result->id = $rpcRequest->id;

        return $result;
    }

    /**
     * Returns true if given a request with an array of rpc methods supported by the same
     * solver, they must be executed in a transactional mode.
     */
    public function isTransactional(): bool
    {
        return false;
    }
    /**
     * @throws AccessDeniedException
     */
    public function validateRpcRequest(object $rpcRequest): void
    {
        if (! $this->permissionEvaluator->isPermissionEnabled(
            Features::feature_query_ai_generated_segments_recommendations()
        )) {
            throw new AccessDeniedException('user is missing permission to request segment recommendations');
        }
    }

    /**
     * @param array<int, array<string, string|float>> $segmentRecommendations
     * @return array<string, array<string, string|float>>
     */
    private function getSortedResult(array $segmentRecommendations): array
    {
        $result = [];
        foreach ($segmentRecommendations as $recommendation) {
            $result[$recommendation['segment_id']] =
                ['score' => $recommendation['score']];
        }
        // sort results by score desc get results from DB
        uasort(
            $result,
            static function (array $a, array $b): int {
                if ($a['score'] === $b['score']) {
                    return 0;
                }
                return $a['score'] > $b['score'] ? -1 : 1;
            }
        );
        $segments = $this->segmentService->findByIds(array_keys($result));
        foreach ($segments as $segment) {
            $result[$segment->getId()]['recommendation'] = $segment->getRecommendation();
        }

        return $result;
    }
}
