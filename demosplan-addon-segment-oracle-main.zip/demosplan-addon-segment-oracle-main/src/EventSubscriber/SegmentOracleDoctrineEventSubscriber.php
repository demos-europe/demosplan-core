<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS plan GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\SegmentOracle\EventSubscriber;

use DemosEurope\DemosplanAddon\Contracts\Entities\SegmentInterface;
use DemosEurope\DemosplanAddon\SegmentOracle\Entity\SegmentChangeNotification;
use DemosEurope\DemosplanAddon\SegmentOracle\Logic\SegmentOracleService;
use Doctrine\Bundle\DoctrineBundle\EventSubscriber\EventSubscriberInterface;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Events;

class SegmentOracleDoctrineEventSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private readonly SegmentOracleService $segmentOracleService
    ) {

    }

    public function getSubscribedEvents(): array
    {
        return [
            Events::onFlush
        ];
    }

    public function onFlush(OnFlushEventArgs $event): void
    {
        $unitOfWork = $event->getObjectManager()->getUnitOfWork();
        /** @var array<int, SegmentInterface> $segmentsScheduledForInsert */
        $segmentsScheduledForInsert = array_filter(
            $unitOfWork->getScheduledEntityInsertions(),
            static fn ($entity): bool => $entity instanceof SegmentInterface
        );
        /** @var array<int, SegmentInterface> $segmentsScheduledForUpdate */
        $segmentsScheduledForUpdate = array_filter(
            $unitOfWork->getScheduledEntityUpdates(),
            static fn ($entity): bool => $entity instanceof SegmentInterface
        );
        /** @var array<int, SegmentInterface> $segmentsScheduledForDelete */
        $segmentsScheduledForDelete = array_filter(
            $unitOfWork->getScheduledEntityDeletions(),
            static fn ($entity): bool => $entity instanceof SegmentInterface
        );

        if (0 !== count($segmentsScheduledForInsert)) {
            $this->segmentOracleService->createNewSegmentChangeNotification(
                $segmentsScheduledForInsert,
                SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE
            );
        }
        if (0 !== count($segmentsScheduledForUpdate)) {
            $this->segmentOracleService->createNewSegmentChangeNotification(
                $segmentsScheduledForUpdate,
                SegmentChangeNotification::NOTIFICATION_TYPE_UPDATE
            );
        }
        if (0 !== count($segmentsScheduledForDelete)) {
            $this->segmentOracleService->createNewSegmentChangeNotification(
                $segmentsScheduledForDelete,
                SegmentChangeNotification::NOTIFICATION_TYPE_DELETE
            );
        }
    }
}
