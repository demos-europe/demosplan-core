<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\SegmentOracle\EventSubscriber;

use DemosEurope\DemosplanAddon\Contracts\Events\AddonMaintenanceEventInterface;
use DemosEurope\DemosplanAddon\SegmentOracle\Logic\SegmentOracleService;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class SegmentOracleAddonMaintenanceEventSubscriber implements EventSubscriberInterface
{
    public function __construct(
        private readonly SegmentOracleService $segmentOracleService
    ) {

    }

    public static function getSubscribedEvents(): array
    {
        return [
            AddonMaintenanceEventInterface::class => 'triggerSendSegmentChangeNotifications',
        ];
    }

    public function triggerSendSegmentChangeNotifications(AddonMaintenanceEventInterface $event): void
    {
        $this->segmentOracleService->sentSegmentChangeNotifications();
    }
}