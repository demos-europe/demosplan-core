<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS plan GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\SegmentOracle\Entity;

use DateTime;
use DemosEurope\DemosplanAddon\Contracts\Entities\SegmentInterface;
use DemosEurope\DemosplanAddon\Contracts\Entities\UuidEntityInterface;
use DemosEurope\DemosplanAddon\SegmentOracle\Doctrine\Generator\UuidV4Generator;
use DemosEurope\DemosplanAddon\SegmentOracle\Repository\SegmentChangeNotificationRepository;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * SegmentChange - Stores a SegmentChange message to affect recommendation proposals
 * this change is stored in our DB and gets sent to PI within the AddonMaintenanceEvent
 */
#[ORM\Entity(repositoryClass: SegmentChangeNotificationRepository::class)]
class SegmentChangeNotification implements UuidEntityInterface
{
    public const NOTIFICATION_TYPE_UPDATE = 'update';
    public const NOTIFICATION_TYPE_DELETE = 'delete';

    #[ORM\Column(type: 'string', length: 36, nullable: false, options:['fixed' => true])]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'CUSTOM')]
    #[ORM\CustomIdGenerator(class: UuidV4Generator::class)]
    private ?string $id;

    #[ORM\Column(name: 'procedure_id', length: 36, type: 'string', nullable: false)]
    private string $procedureId;

    #[ORM\Column(name: 'parent_statement_id', length: 36, type: 'string', nullable: false)]
    private string $statementId;

    #[ORM\Column(name: 'segment_id', length: 36, type: 'string', nullable: false)]
    private string $segmentId;

    #[ORM\Column(name: 'notification_type', length: 36, type: 'string', nullable: false)]
    private string $notificationType = '';

    #[ORM\Column(name: 'segment_text', type: 'text', nullable: true)]
    private string $segmentText = '';

    #[ORM\Column(name: 'segment_recommendation', type: 'text', nullable: true)]
    private string $segmentRecommendation = '';

    #[Gedmo\Timestampable(on: 'create')]
    #[ORM\Column(type: 'datetime', nullable: false, options: ['default' => 'CURRENT_TIMESTAMP'])]
    private DateTime $createdDate;

    #[ORM\Column(name:'error_count', type: "integer", nullable: false, options: ['default' => 0])]
    private int $errorCount = 0;

    public function __construct(SegmentInterface $segment, string $notificationType)
    {
        $this->procedureId = $segment->getProcedureId();
        $this->statementId = $segment->getParentStatement()->getId();
        $this->segmentId = $segment->getId();
        $this->notificationType = $notificationType;
        $this->segmentText = $segment->getText();
        $this->segmentRecommendation = $segment->getRecommendation();
    }

    public function getId(): ?string
    {
        return $this->id;
    }

    public function getProcedureId(): string
    {
        return $this->procedureId;
    }

    public function getParentStatementId(): string
    {
        return $this->statementId;
    }

    public function getSegmentId(): string
    {
        return $this->segmentId;
    }

    public function getNotificationType(): string
    {
        return $this->notificationType;
    }

    public function getSegmentText(): string
    {
        return $this->segmentText;
    }

    public function getSegmentRecommendation(): string
    {
        return $this->segmentRecommendation;
    }

    public function getCreateDate(): DateTime
    {
        return $this->createdDate;
    }

    public function getErrorCount(): int
    {
        return $this->errorCount;
    }

    public function setErrorCount(int $errorCount): void
    {
        $this->errorCount = $errorCount;
    }
}
