<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS plan GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\SegmentOracle\Repository;

use DemosEurope\DemosplanAddon\Contracts\Entities\SegmentInterface;
use DemosEurope\DemosplanAddon\SegmentOracle\Entity\SegmentChangeNotification;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class SegmentChangeNotificationRepository extends ServiceEntityRepository
{
    private const SEGMENT_CHANGESETKEY_TEXT = 'text';
    private const SEGMENT_CHANGESETKEY_RECOMMENDATION = 'recommendation';

    public function __construct(
        ManagerRegistry $registry,
        string $entityClass,
    ){
        parent::__construct($registry, $entityClass);
    }

    /**
     * Used within the onFlush doctrine lifecycle event
     * No flush is necessary as a flush happens after this event
     * To write here newly persisted entities into the db - the changeSet has to be updated manually
     */
    public function createNew(SegmentInterface $segment, string $notificationType): void
    {
        $segmentChangeNotification = new SegmentChangeNotification(
            $segment,
            $notificationType
        );

        $classMeta = $this->getEntityManager()->getClassMetadata(SegmentChangeNotification::class);
        $this->getEntityManager()->persist($segmentChangeNotification);
        $this->getEntityManager()->getUnitOfWork()->computeChangeSet($classMeta, $segmentChangeNotification);
    }

    public function getAllNewSortedByCreateDate(): array
    {
        return $this->findBy(['errorCount' => 0], ['createdDate' => 'ASC']);
    }

    public function getAllFaultySortedByCreateDate(): array
    {
        $emtityManager = $this->getEntityManager();
        $querybuilder = $emtityManager->createQueryBuilder();

        $query  = $querybuilder->select('segmentChangeNotification')
            ->from(SegmentChangeNotification::class, 'segmentChangeNotification')
            ->where('segmentChangeNotification.errorCount > :errorCount')
            ->setParameter('errorCount', 0)
            ->orderBy('segmentChangeNotification.createdDate', 'ASC')
            ->getQuery();

        return $query->getResult();
    }

    /**
     * Do not call this method within a doctrine lifecycle event
     */
    public function flushEverything(): void
    {
        $this->getEntityManager()->flush();
    }

    public function delete(SegmentChangeNotification $segmentChangeNotification): void
    {
        $this->getEntityManager()->remove($segmentChangeNotification);
    }

    public function shouldDeleteDueToBlankedOutRecommendation(SegmentInterface $segment): bool
    {
        // if the recommendation text gets blanked out - this segment should be deleted by PI
        /** @var array<string, array<int, mixed>> $changeSet */ //0 -> old text ; 1 -> new text
        $changeSet = $this->getEntityManager()->getUnitOfWork()->getEntityChangeSet($segment);

        return '' === $segment->getRecommendation()
            && array_key_exists(self::SEGMENT_CHANGESETKEY_RECOMMENDATION, $changeSet)
            && $changeSet[self::SEGMENT_CHANGESETKEY_RECOMMENDATION][1] === '';
    }

    public function hasRelevantFieldChanged(SegmentInterface $segment): bool
    {
        /** @var array<string, array<int, mixed>> $changeSet */ //0 -> old text ; 1 -> new text
        $changeSet = $this->getEntityManager()->getUnitOfWork()->getEntityChangeSet($segment);
        if ('' !== $segment->getRecommendation()) {
            return array_key_exists(self::SEGMENT_CHANGESETKEY_TEXT, $changeSet)
                || array_key_exists(self::SEGMENT_CHANGESETKEY_RECOMMENDATION, $changeSet);
        }

        return false;
    }
}
