<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\SegmentOracle\Configuration\Permissions;

use DemosEurope\DemosplanAddon\Permission\AbstractPermissionMeta;
use DemosEurope\DemosplanAddon\SegmentOracle\SegmentOracleAddon;

class Features extends AbstractPermissionMeta
{
    /**
     * Allow querying artificial intelligence segment recommendation proposals.
     *
     * Used to gather recommendation proposals based upon already existing segments.
     */
    // #[Exposed(true)]
    public static function feature_query_ai_generated_segments_recommendations(): self
    {
        return new self('feature_query_ai_generated_segments_recommendations');
    }

    /**
     * @inheritDoc
     */
    public function getAddonIdentifier(): ?string
    {
        return SegmentOracleAddon::ADDON_NAME;
    }
}
