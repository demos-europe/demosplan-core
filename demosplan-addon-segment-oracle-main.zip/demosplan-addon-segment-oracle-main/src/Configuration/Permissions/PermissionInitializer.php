<?php

/**
 * This file is part of the package demosplan.
 *
 * (c) 2010-present DEMOS E-Partizipation GmbH, for more information see the license file.
 *
 * All rights reserved
 */

namespace DemosEurope\DemosplanAddon\SegmentOracle\Configuration\Permissions;

use DemosEurope\DemosplanAddon\Contracts\Config\GlobalConfigInterface;
use DemosEurope\DemosplanAddon\Permission\PermissionConditionBuilder;
use DemosEurope\DemosplanAddon\Permission\PermissionInitializerInterface;
use DemosEurope\DemosplanAddon\Permission\ResolvablePermissionCollectionInterface;
use DemosEurope\DemosplanAddon\SegmentOracle\Configuration\Permissions\Features;

class PermissionInitializer implements PermissionInitializerInterface
{
    private bool $restrictedAccess;

    public function __construct(GlobalConfigInterface $globalConfig)
    {
        $this->restrictedAccess = $globalConfig->hasProcedureUserRestrictedAccess();
    }

    /**
     * @inheritDoc
     */
    public function configurePermissions(ResolvablePermissionCollectionInterface $permissionCollection): void
    {
        $permissionCollection->configurePermissionInstance(
            Features::feature_query_ai_generated_segments_recommendations(),
            PermissionConditionBuilder::start()
                ->enableIfProcedureOwnedViaOrganisation(['RMOPSA', 'RMOPSD'], $this->restrictedAccess)
                ->enableIfProcedureOwnedViaPlanningAgency(['RMOPSA', 'RMOPSD'])
        );

    }
}
