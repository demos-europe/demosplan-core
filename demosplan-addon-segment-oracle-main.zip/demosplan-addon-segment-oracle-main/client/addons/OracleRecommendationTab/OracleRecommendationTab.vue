<template>
  <div>
    <div class="layout u-mb u-mt-0_5">
      <div class="layout__item u-1-of-3">
        <dp-label
          :text="Translator.trans('search.text')"
          for="searchField" />
        <dp-search-field
          @search="setSearchTerm"
          @reset="setSearchTerm('')"
          class="flex min-width-l"
          :placeholder="Translator.trans('search')" />
      </div>
    </div>

    <dp-loading v-if="isLoading" />

    <template v-else>
      <ul
        v-if="oracleRecommendations"
        class="o-list space-stack-m height-50vh overflow-auto">
        <dp-insertable-recommendation
          v-for="recommendation in oracleRecommendations"
          :key="recommendation.id"
          class="o-list__item"
          :from-other-procedure="false"
          is-content-rec
          :recommendation="recommendation.recommendation"
          :recommendation-score="recommendation.score"
          :search-term="searchTerm"
          @recommendation:insert="updateSegment(recommendation.recommendation)" />
      </ul>
      <div
        v-else
        class="u-pt-0_5 border--top">
        {{ Translator.trans('statement.list.empty') }}
      </div>
    </template>
  </div>
</template>

<script>
import { checkResponse, DpLabel, DpLoading, dpRpc, DpSearchField } from '@demos-europe/demosplan-ui'
import DpInsertableRecommendation from '../../components/DpInsertableRecommendation/DpInsertableRecommendation'
import { mapMutations, mapState } from 'vuex'

export default {
  name: "OracleRecommendationTab",

  components: {
    DpInsertableRecommendation,
    DpLabel,
    DpLoading,
    DpSearchField
  },

  props: {
    segmentId: {
      type: String,
      required: true
    }
  },

  data() {
    return {
      isLoading: false,
      oracleRecommendations: {},
      searchTerm: ''
    }
  },

  computed: {
    ...mapState('statementSegment', {
      segments: 'items'
    })
  },

  methods: {
    ...mapMutations('statementSegment', ['setItem']),

    fetchOracleRecommendations() {
      this.isLoading = true
      const params = {
        recommendationsCount: 10,
        segmentId: this.segmentId
      }
      dpRpc('segment.oracle.recommendations', params)
        .then(response => checkResponse(response))
        .then(response => {
          const recommendationsObj = response[0].result
          for (const id of Object.keys(recommendationsObj)) {
            this.oracleRecommendations[id] = {
              id: id,
              options: recommendationsObj[id].options,
              recommendation: recommendationsObj[id].recommendation,
              score: recommendationsObj[id].score
            }
          }
        })
        .catch((err) => {
          console.error(err)
        })
        .finally(() => {
          this.isLoading = false
        })
    },

    setSearchTerm (term) {
      this.searchTerm = term
    },

    updateSegment (recommendation) {
      const payload = JSON.parse(JSON.stringify(this.segments[this.segmentId]))
      payload.attributes.recommendation = recommendation

      this.setItem({ ...payload, id: payload.id, group: null })
      this.$emit('recommendation:insert', recommendation)
    },
  },

  mounted () {
    this.fetchOracleRecommendations()
  }
}
</script>

